/**
 * 🇺🇿 14-Maktab / Yangi Avlod Maktabi — Modern National School Landing JS
 * Interactive scroll animations, number counter, language switching, enrollment modal.
 */

(function () {
  'use strict';

  // ─── Dual-Language Localization Dictionary ───
  const i18n = {
    uz: {
      // Header
      navAbout: "Maktab haqida",
      navPrograms: "Yo'nalishlar",
      navTeachers: "Ustozlar",
      navAchievements: "Yutuqlar",
      navLife: "Maktab hayoti",
      navContact: "Bog'lanish",
      btnEnrollShort: "Ariza topshirish",
      btnPortal: "Elektron Jurnal ↗",

      // Hero
      heroBadge: "2026/2027 o'quv yili uchun qabul ochiq",
      heroTitle1: "Zamonaviy bilim va ",
      heroTitle2: "milliy qadriyatlar ",
      heroTitle3: "uyg'unligi",
      heroDesc: "O'zbekiston kelajagini bunyod etuvchi yoshlar maskani. Chuqurlashtirilgan IT, aniq fanlar, xorijiy tillar va sharqona odob-axloq tarbiyasi.",
      btnHeroApply: "O'qishga ariza berish",
      btnHeroTour: "Virtual sayohat",
      trustGov: "Davlat akkreditatsiyasi",
      trustStem: "Zamonaviy STEM laboratoriya",
      trustIelts: "IELTS & Milliy sertifikatlar",
      chipOlympiadTitle: "Olimpiada chempionlari",
      chipOlympiadSub: "12 ta xalqaro medal",
      chipStemTitle: "Robototexnika & AI",
      chipStemSub: "Eng so'nggi laboratoriya",

      // Stats
      statYears: "Yillik tajriba",
      statYearsSub: "Ahademik an'analar",
      statStudents: "O'quvchilar",
      statStudentsSub: "Iqtidorli yoshlar",
      statSuccess: "OTMga kirish",
      statSuccessSub: "Davlat va xorijiy grantlar",
      statTeachers: "Malakali ustozlar",
      statTeachersSub: "Oliy toifali mutaxassislar",

      // About
      aboutTag: "Biz haqimizda",
      aboutTitle: "Kelajak ta'limi — buyuk o'tmishimizdan kuch oladi",
      aboutDesc: "Biz nafaqat jahon standartidagi zamonaviy bilimlarni beramiz, balki Al-Xorazmiy, Ibn Sino va Beruniy kabi buyuk ajdodlarimizning ilmiy merosiga sodiq holda har bir o'quvchida mustaqil fikrlashni shakllantiramiz.",
      pillar1Title: "Shaxsiy yondashuv va qobiliyatni rivojlantirish",
      pillar1Desc: "Har bir sinfda 25 nafargacha o'quvchi, individual mentorlik tizimi va qobiliyat bo'yicha maxsus guruhlar.",
      pillar2Title: "Xalqaro standartdagi o'quv dasturlari",
      pillar2Desc: "Kembrij va Milliy dasturning integratsiyasi, amaliy laboratoriya darslari va loyiha asosida o'qitish.",
      pillar3Title: "Tarbiya va milliy qadriyatlar",
      pillar3Desc: "Ustozga hurmat, kitobxonlik madaniyati, sharqona mehmondo'stlik va milliy san'at to'garaklari.",

      // Programs / Subjects
      programsTag: "Ta'lim yo'nalishlari",
      programsTitle: "Har bir bolaning iqtidoriga mos yo'nalishlar",
      programsSub: "Aniq fanlardan tortib IT, xorijiy tillar va sportgacha bo'lgan chuqurlashtirilgan dasturlar.",
      mathTitle: "Prezident va Milliy Matematika",
      mathDesc: "Mantiqiy fikrlash, olimpiada masalalari, mental arifmetika va oliy matematikaga poydevor.",
      itTitle: "IT, Robototexnika va Dasturlash",
      itDesc: "Python, web-dasturlash, sun'iy intellekt asoslari, LEGO Education va elektronika konstruktorlari.",
      scienceTitle: "STEM va Tabiiy fanlar",
      scienceDesc: "Fizika, kimyo va biologiya bo'yicha eng zamonaviy jihozlangan tajriba xonalari.",
      langTitle: "Chet tillari (IELTS & Nemis)",
      langDesc: "Native speaker ustozlar bilan ingliz, nemis va arab tillarini chuqurlashtirilgan o'rganish.",
      artTitle: "Milliy San'at va Shaxmat",
      artDesc: "Kalligrafiya, xattotlik, milliy cholg'u asboblari, kulolchilik va professional shaxmat klubi.",
      sportTitle: "Sport va Salomatlik",
      sportDesc: "Futbol, taekvondo, stol tennisi va gimnastika seksiyalari, to'liq jihozlangan sport zali.",

      // Teachers
      teachersTag: "Bizning faxrimiz",
      teachersTitle: "O'z ishining ustasi bo'lgan murabbiylar",
      teachersSub: "Tajribali, xalqaro sertifikatlarga ega va o'z fani bilan o'quvchilarni ilhomlantiruvchi pedagoglar.",

      // Traditions
      traditionsTag: "Maktab hayoti",
      traditionsTitle: "Jonli an'analar va bayramlar",
      traditionsSub: "Bizning maktabda har bir kun qiziqarli voqealar, do'stlik va kashfiyotlarga boy.",
      navruzTitle: "Bahoriy Navro'z shodiyonalari",
      navruzDesc: "Sumalak sayli, milliy liboslar paradi va mehmondo'stlik darslari bilan uyg'unlashgan xalq sayli.",
      assemblyTitle: "Haftalik Davlat bayrog'i va Madhiya saflanishi",
      assemblyDesc: "Vatanga muhabbat va vatanparvarlik ruhi har dushanba ertalabki tantanali saflanishdan boshlanadi.",
      stemExpoTitle: "Yillik Yosh Ixtirochilar Ko'rgazmasi",
      stemExpoDesc: "O'quvchilar o'zlari yasagan robotlar, dasturlar va ilmiy loyihalarini namoyish etadilar.",

      // Form & Contact
      contactTag: "Qabul komissiyasi",
      contactTitle: "Farzandingiz kelajagini biz bilan birga quring",
      contactSub: "Qabul uchun arizangizni qoldiring, mutaxassisimiz 15 daqiqa ichida siz bilan bog'lanadi.",
      lblParentName: "Ota-ona F.I.SH:",
      lblPhone: "Telefon raqamingiz:",
      lblChildName: "Farzandingiz ismi va yoshi:",
      lblClass: "Qaysi sinfga kirmoqchisiz:",
      btnSubmitForm: "Arizani yuborish 🚀",
      addressText: "Surxondaryo viloyati, Termiz shahri, Al-Hakim At-Termiziy shoh ko'chasi, 14-bino",
      workHoursText: "Dushanba – Shanba: 08:00 – 18:00"
    },
    ru: {
      // Header
      navAbout: "О школе",
      navPrograms: "Направления",
      navTeachers: "Учителя",
      navAchievements: "Достижения",
      navLife: "Школьная жизнь",
      navContact: "Контакты",
      btnEnrollShort: "Подать заявку",
      btnPortal: "Электронный журнал ↗",

      // Hero
      heroBadge: "Приём на 2026/2027 учебный год открыт",
      heroTitle1: "Гармония современных знаний и ",
      heroTitle2: "национальных традиций ",
      heroTitle3: "Узбекистана",
      heroDesc: "Школа нового поколения для будущих лидеров страны. Углублённое изучение IT, точных наук, иностранных языков и воспитание в духе уважения к культуре.",
      btnHeroApply: "Подать заявку на поступление",
      btnHeroTour: "Виртуальный тур",
      trustGov: "Государственная аккредитация",
      trustStem: "Современная STEM-лаборатория",
      trustIelts: "IELTS & Национальные сертификаты",
      chipOlympiadTitle: "Чемпионы олимпиад",
      chipOlympiadSub: "12 международных медалей",
      chipStemTitle: "Робототехника и AI",
      chipStemSub: "Новейшая лаборатория",

      // Stats
      statYears: "Лет опыта",
      statYearsSub: "Академические традиции",
      statStudents: "Учеников",
      statStudentsSub: "Талантливые дети",
      statSuccess: "Поступление в ВУЗы",
      statSuccessSub: "Государственные и зарубежные гранты",
      statTeachers: "Опытных педагогов",
      statTeachersSub: "Специалисты высшей категории",

      // About
      aboutTag: "О нашей школе",
      aboutTitle: "Образование будущего, черпающее силу в великой истории",
      aboutDesc: "Мы даём знания мирового уровня, опираясь на научное наследие Аль-Хорезми, Авиценны и Беруни, формируя у каждого ученика критическое мышление и лидерские качества.",
      pillar1Title: "Индивидуальный подход к каждому",
      pillar1Desc: "До 25 учеников в классе, персональные наставники и распределение по углублённым профильным группам.",
      pillar2Title: "Программы международного уровня",
      pillar2Desc: "Синтез передовых методик и национального стандарта, практические опыты и проектное обучение.",
      pillar3Title: "Воспитание и культурный код",
      pillar3Desc: "Уважение к учителю и старшим, любовь к книгам, эстетика традиционного прикладного искусства.",

      // Programs / Subjects
      programsTag: "Направления обучения",
      programsTitle: "Развиваем природные таланты каждого ребёнка",
      programsSub: "От президентской олимпиадной математики до искусственного интеллекта, языков и спорта.",
      mathTitle: "Олимпиадная Математика",
      mathDesc: "Логика, нестандартное мышление, подготовка к национальным и международным олимпиадам.",
      itTitle: "IT, Робототехника и ИИ",
      itDesc: "Python, веб-разработка, алгоритмы, конструкторы робототехники и машинное обучение для детей.",
      scienceTitle: "STEM и Естественные науки",
      scienceDesc: "Физика, химия и биология в современных лабораториях с интерактивным оборудованием.",
      langTitle: "Иностранные языки (IELTS)",
      langDesc: "Английский, немецкий и арабский языки с носителями языка и подготовкой к экзаменам.",
      artTitle: "Национальное искусство и Шахматы",
      artDesc: "Каллиграфия, роспись, музыкальные инструменты, шахматный клуб гроссмейстеров.",
      sportTitle: "Спорт и Здоровье",
      sportDesc: "Секции футбола, таэквондо, настольного тенниса и гимнастики с профессиональными тренерами.",

      // Teachers
      teachersTag: "Гордость школы",
      teachersTitle: "Наставники, которые вдохновляют",
      teachersSub: "Педагоги высшей категории, победители конкурсов 'Учитель года' и сертифицированные эксперты.",

      // Traditions
      traditionsTag: "Школьная жизнь",
      traditionsTitle: "Яркие традиции и праздники",
      traditionsSub: "Каждый день в школе наполнен радостью открытий, крепкой дружбой и уважением к культуре.",
      navruzTitle: "Празднование Навруза",
      navruzDesc: "Приготовление сумаляка, национальные костюмы из атласа и адраса, весеннее единение поколений.",
      assemblyTitle: "Утренняя линейка с Государственным флагом",
      assemblyDesc: "Каждый понедельник начинается с торжественного поднятия флага и исполнения гимна Родины.",
      stemExpoTitle: "Ежегодная Выставка Юных Изобретателей",
      stemExpoDesc: "Презентация собственных роботов, экологических стартапов и научных исследований.",

      // Form & Contact
      contactTag: "Приёмная комиссия",
      contactTitle: "Постройте успешное будущее вашего ребёнка с нами",
      contactSub: "Оставьте заявку на поступление, и наш методист перезвонит вам в течение 15 минут.",
      lblParentName: "Ф.И.О. родителя:",
      lblPhone: "Номер телефона:",
      lblChildName: "Имя и возраст ребёнка:",
      lblClass: "В какой класс поступаете:",
      btnSubmitForm: "Отправить заявку 🚀",
      addressText: "Сурхандарьинская область, г. Термез, проспект Аль-Хаким Ат-Термизий, 14",
      workHoursText: "Понедельник – Суббота: 08:00 – 18:00"
    }
  };

  let currentLang = 'uz';

  // ─── Apply Language Translations ───
  function setLanguage(lang) {
    if (!i18n[lang]) return;
    currentLang = lang;
    localStorage.setItem('landing_lang', lang);

    document.querySelectorAll('[data-lang-btn]').forEach(btn => {
      btn.classList.toggle('active', btn.getAttribute('data-lang-btn') === lang);
    });

    document.querySelectorAll('[data-uz]').forEach(el => {
      const key = el.getAttribute('data-i18n-key');
      if (key && i18n[lang][key]) {
        el.textContent = i18n[lang][key];
      }
    });

    document.documentElement.lang = lang;
  }

  // ─── Scroll Reveal Observer ───
  function initScrollReveal() {
    const elements = document.querySelectorAll('.reveal-on-scroll');
    if (!('IntersectionObserver' in window)) {
      elements.forEach(el => el.classList.add('revealed'));
      return;
    }

    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('revealed');
          observer.unobserve(entry.target);
        }
      });
    }, {
      threshold: 0.12,
      rootMargin: '0px 0px -40px 0px'
    });

    elements.forEach(el => observer.observe(el));
  }

  // ─── Animated Number Counters ───
  function initCounters() {
    const statsSection = document.getElementById('stats-section');
    if (!statsSection) return;

    let countersStarted = false;

    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting && !countersStarted) {
          countersStarted = true;
          animateAllCounters();
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.25 });

    observer.observe(statsSection);
  }

  function animateAllCounters() {
    const counters = document.querySelectorAll('[data-target-counter]');
    counters.forEach(counter => {
      const target = parseInt(counter.getAttribute('data-target-counter'), 10) || 0;
      const duration = 1800; // ms
      const startTime = performance.now();

      function updateNumber(currentTime) {
        const elapsed = currentTime - startTime;
        const progress = Math.min(elapsed / duration, 1);
        // Ease-out cubic
        const easeProgress = 1 - Math.pow(1 - progress, 3);
        const currentVal = Math.floor(easeProgress * target);

        counter.textContent = currentVal.toLocaleString();

        if (progress < 1) {
          requestAnimationFrame(updateNumber);
        } else {
          counter.textContent = target.toLocaleString();
        }
      }

      requestAnimationFrame(updateNumber);
    });
  }

  // ─── Hero Girih Ambient Parallax Movement ───
  function initHeroParallax() {
    const heroSec = document.querySelector('.hero-section');
    const ornament = document.querySelector('.girih-ornament-watermark');
    if (!heroSec || !ornament) return;

    window.addEventListener('scroll', () => {
      const scrollY = window.pageYOffset;
      if (scrollY < 800) {
        ornament.style.transform = `translateY(${scrollY * 0.18}px)`;
      }
    }, { passive: true });
  }

  // ─── Interactive Enrollment Form Handler ───
  function initEnrollmentForm() {
    const form = document.getElementById('enrollment-form');
    if (!form) return;

    form.addEventListener('submit', function (e) {
      e.preventDefault();
      const parentName = document.getElementById('form-parent-name')?.value;
      const phone = document.getElementById('form-phone')?.value;
      const childName = document.getElementById('form-child-name')?.value;
      const grade = document.getElementById('form-grade')?.value;

      if (!parentName || !phone) {
        alert(currentLang === 'uz' ? 'Iltimos, ismingiz va telefon raqamingizni to\'ldiring!' : 'Пожалуйста, укажите имя и телефон!');
        return;
      }

      // Show success modal or toast
      const msgUz = `Rahmat, ${parentName}! Farzandingiz (${childName || ''}, ${grade}) uchun arizangiz qabul qilindi. 15 daqiqa ichida qo'ng'iroq qilamiz.`;
      const msgRu = `Спасибо, ${parentName}! Ваша заявка для ребёнка (${childName || ''}, ${grade}) принята. Мы перезвоним вам в течение 15 минут.`;

      alert(currentLang === 'uz' ? msgUz : msgRu);
      form.reset();
    });
  }

  // ─── DOM Ready Bootstrapping ───
  document.addEventListener('DOMContentLoaded', () => {
    // Saved lang
    const saved = localStorage.getItem('landing_lang') || 'uz';
    setLanguage(saved);

    // Lang buttons
    document.querySelectorAll('[data-lang-btn]').forEach(btn => {
      btn.addEventListener('click', () => {
        setLanguage(btn.getAttribute('data-lang-btn'));
      });
    });

    initScrollReveal();
    initCounters();
    initHeroParallax();
    initEnrollmentForm();
  });

  // Global window functions for template onclicks
  window.Landing = {
    setLanguage,
    scrollToEnrollment: function () {
      const el = document.getElementById('contact-section');
      if (el) el.scrollIntoView({ behavior: 'smooth' });
    }
  };
})();
