/**
 * 14-Maktab / Jurnal - Authentication & Access Control
 * School Code verification, Secure Login, Role Authorization, Request Approval.
 */

const Auth = (function() {

  // Helper to generate unique school code (e.g. TERMIZ-14-7K29)
  function generateSchoolCode(city, number) {
    const cleanCity = (city || 'MAKTAB')
      .replace(/[^a-zA-Zа-яА-Я0-9]/g, '')
      .toUpperCase()
      .substring(0, 6) || 'MAKTAB';
    const cleanNum = (number || '1').replace(/[^0-9]/g, '') || '1';
    const chars = '23456789ABCDEFGHJKLMNPQRSTUVWXYZ';
    let salt = '';
    for (let i = 0; i < 4; i++) {
      salt += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return `${cleanCity}-${cleanNum}-${salt}`;
  }

  // 1. Register School (Director)
  async function registerSchool(data) {
    // Validate required fields
    if (!data.number || !data.fullName || !data.directorName || !data.directorEmail || !data.password) {
      throw new Error(t('errFillAllFields'));
    }
    if (data.password.length < 6) {
      throw new Error(t('errPasswordTooShort'));
    }
    if (data.password !== data.passwordConfirm) {
      throw new Error(t('errPasswordMismatch'));
    }

    const schoolCode = generateSchoolCode(data.city || data.region, data.number);
    const passHash = await DB.hashPassword(data.password);

    const schoolId = "sch_" + Date.now().toString(36);
    const newSchool = {
      id: schoolId,
      code: schoolCode,
      number: data.number.trim(),
      region: (data.region || '').trim(),
      city: (data.city || '').trim(),
      name: data.fullName.trim(),
      directorName: data.directorName.trim(),
      directorPhone: (data.directorPhone || '').trim(),
      directorEmail: data.directorEmail.trim().toLowerCase(),
      createdAt: new Date().toISOString()
    };
    DB.saveSchool(newSchool);

    // Create Director user
    const dirUser = {
      id: "usr_" + Date.now().toString(36),
      schoolCode: schoolCode,
      role: "director",
      name: data.directorName.trim(),
      phone: (data.directorPhone || '').trim(),
      email: data.directorEmail.trim().toLowerCase(),
      passwordHash: passHash.hash,
      salt: passHash.salt,
      status: "active",
      classId: null,
      createdAt: new Date().toISOString()
    };
    DB.saveUser(dirUser);

    // Note: No automatic default classes are created - classes will be created by the school director as needed!

    // Create session
    const session = {
      token: "sess_" + Math.random().toString(36).substring(2),
      userId: dirUser.id,
      schoolCode: schoolCode,
      role: "director",
      name: dirUser.name,
      email: dirUser.email,
      phone: dirUser.phone,
      classId: null,
      loginAt: new Date().toISOString()
    };
    DB.setSession(session);

    return { school: newSchool, user: dirUser, session };
  }

  // 2. Submit Join Request (Teacher or Starosta)
  async function submitJoinRequest(data) {
    if (!data.schoolCode || !data.role || !data.fullName || !data.email || !data.password) {
      throw new Error(t('errFillAllFields'));
    }
    if (data.password.length < 6) {
      throw new Error(t('errPasswordTooShort'));
    }

    const school = DB.getSchoolByCode(data.schoolCode);
    if (!school) {
      throw new Error(t('errSchoolNotFound'));
    }

    const cleanEmail = data.email.trim().toLowerCase();
    const existingUser = DB.findUserByLogin(school.code, cleanEmail);
    if (existingUser) {
      throw new Error(currentLang === 'uz' ? 'Bu email bilan allaqachon ro\'yxatdan o\'tilgan!' : 'Пользователь с таким email уже зарегистрирован!');
    }

    const passHash = await DB.hashPassword(data.password);
    const userId = "usr_" + Date.now().toString(36) + Math.random().toString(36).substring(2, 5);

    // If teacher: status is pending until director approves
    // If starosta: status is pending until approved by director/teacher
    const isTeacher = (data.role === 'teacher');
    const userStatus = isTeacher ? 'pending' : 'pending';

    const newUser = {
      id: userId,
      schoolCode: school.code,
      role: data.role,
      name: data.fullName.trim(),
      phone: (data.phone || '').trim(),
      email: cleanEmail,
      passwordHash: passHash.hash,
      salt: passHash.salt,
      status: userStatus,
      classId: data.classId || '10-A',
      createdAt: new Date().toISOString()
    };
    DB.saveUser(newUser);

    // Create join request record for Director's queue
    const req = {
      id: "req_" + Date.now().toString(36) + Math.random().toString(36).substring(2, 6),
      schoolCode: school.code,
      userId: userId,
      role: data.role,
      name: newUser.name,
      phone: newUser.phone,
      email: newUser.email,
      classId: newUser.classId,
      status: "pending",
      requestedAt: new Date().toISOString()
    };
    DB.saveJoinRequest(req);

    return { user: newUser, request: req, school };
  }

  // 2b. Direct Member (Teacher / Student) Registration
  async function registerMember({ schoolCode, role, fullName, phone, email, password, classId }) {
    if (!fullName || !password) {
      throw new Error(t('errFillAllFields'));
    }
    if (password.length < 6) {
      throw new Error(t('errPasswordTooShort'));
    }

    let school = DB.getSchoolByCode(schoolCode);
    if (!school) {
      const allSchools = DB.getSchools();
      if (allSchools.length > 0) school = allSchools[0];
    }
    if (!school) {
      await DB.init();
      school = DB.getSchoolByCode('TERMIZ-14-7K29') || DB.getSchools()[0];
    }
    if (!school) {
      throw new Error(t('errSchoolNotFound'));
    }

    const cleanEmail = (email || `${role || 'user'}_${Date.now().toString(36)}@14maktab.uz`).trim().toLowerCase();
    const cleanPhone = (phone || '').trim();
    const finalClassId = (classId || '10-A').trim().toUpperCase();

    const passHash = await DB.hashPassword(password);
    const userId = "usr_" + Date.now().toString(36) + Math.random().toString(36).substring(2, 5);

    const newUser = {
      id: userId,
      schoolCode: school.code,
      role: role || 'teacher',
      name: fullName.trim(),
      phone: cleanPhone,
      email: cleanEmail,
      passwordHash: passHash.hash,
      salt: passHash.salt,
      status: "active",
      classId: finalClassId,
      createdAt: new Date().toISOString()
    };
    DB.saveUser(newUser);

    // If teacher or starosta/student, ensure the specified class exists in the school
    if (finalClassId) {
      const grade = parseInt(finalClassId, 10) || 10;
      const letter = finalClassId.replace(/^[0-9]+-?/, '') || 'A';
      try {
        SchoolManager.addClass(school.code, grade, letter);
      } catch (e) {}
    }

    // If student, also add to the class student list for journal
    if (newUser.role === 'student' || newUser.role === 'starosta') {
      const stdRecord = {
        id: "std_" + newUser.id,
        schoolCode: school.code,
        classId: finalClassId,
        name: newUser.name,
        phone: newUser.phone,
        createdAt: new Date().toISOString()
      };
      DB.saveStudent(stdRecord);
    }

    const session = {
      token: "sess_" + Math.random().toString(36).substring(2),
      userId: newUser.id,
      schoolCode: school.code,
      role: newUser.role,
      name: newUser.name,
      email: newUser.email,
      phone: newUser.phone,
      classId: newUser.classId,
      loginAt: new Date().toISOString()
    };
    DB.setSession(session);

    return { school, user: newUser, session };
  }

  // 2c. Accept Invite and Register
  async function acceptInviteAndRegister({ token, fullName, username, phone, email, password, classId }) {
    if (!token) {
      throw new Error(t('errInviteInvalid'));
    }
    const invite = DB.getInviteByToken(token);
    if (!invite) {
      throw new Error(t('errInviteInvalid'));
    }
    if (invite.status === 'used') {
      throw new Error(t('errInviteAlreadyUsed'));
    }
    if (invite.status === 'expired') {
      throw new Error(t('errInviteExpiredMsg'));
    }
    if (invite.status === 'cancelled') {
      throw new Error(t('errInviteCancelledMsg'));
    }
    if (invite.status !== 'active') {
      throw new Error(t('errInviteInvalid'));
    }

    if (!fullName || !email || !password) {
      throw new Error(t('errFillAllFields'));
    }
    if (password.length < 6) {
      throw new Error(t('errPasswordTooShort'));
    }

    const school = DB.getSchoolByCode(invite.schoolCode);
    if (!school) {
      throw new Error(t('errSchoolNotFound'));
    }

    const cleanEmail = email.trim().toLowerCase();
    const cleanUsername = (username || '').trim().toLowerCase();
    const existingUser = DB.findUserByLogin(school.code, cleanEmail);
    if (existingUser) {
      throw new Error(currentLang === 'uz' ? 'Bu email bilan allaqachon ro\'yxatdan o\'tilgan!' : 'Пользователь с таким email уже зарегистрирован!');
    }

    const passHash = await DB.hashPassword(password);
    const userId = "usr_" + Date.now().toString(36) + Math.random().toString(36).substring(2, 5);
    const finalClassId = classId || invite.classId || '10-A';

    // Record usage in invite
    DB.useInvite(token, {
      userId: userId,
      name: fullName.trim(),
      email: cleanEmail,
      username: cleanUsername,
      classId: finalClassId,
      registeredAt: new Date().toISOString()
    });

    const newUser = {
      id: userId,
      schoolCode: school.code,
      role: invite.role,
      name: fullName.trim(),
      username: cleanUsername,
      phone: (phone || '').trim(),
      email: cleanEmail,
      accessCode: password, // Visible to director in school database as requested
      passwordHash: passHash.hash,
      salt: passHash.salt,
      status: "approved", // Automatically approved directly via 24h authorized link!
      classId: finalClassId,
      inviteToken: invite.token,
      createdAt: new Date().toISOString()
    };
    DB.saveUser(newUser);

    // Save as approved join record in Director's log
    const req = {
      id: "req_" + Date.now().toString(36) + Math.random().toString(36).substring(2, 6),
      schoolCode: school.code,
      userId: userId,
      role: invite.role,
      name: newUser.name,
      phone: newUser.phone,
      email: newUser.email,
      classId: newUser.classId,
      accessCode: password,
      status: "approved", // Directly active!
      inviteToken: invite.token,
      requestedAt: new Date().toISOString()
    };
    DB.saveJoinRequest(req);

    return { user: newUser, request: req, school, invite };
  }

  // 3. Login (Smart school code auto-resolver + Admin bypass)
  async function login(schoolCode, identifier, password) {
    if (!identifier || !password) {
      throw new Error(t('errFillAllFields'));
    }

    // Attempt Enterprise REST API v1 login first
    if (typeof ApiClient !== 'undefined' && ApiClient.auth) {
      try {
        const res = await ApiClient.auth.login({ identifier, password });
        if (res && res.user && res.access_token) {
          const u = res.user;
          const roleNorm = (u.role || 'user').toLowerCase();
          const session = {
            token: res.access_token,
            userId: u.id,
            schoolCode: res.school ? res.school.code : (u.school_id || 'TERMIZ-14-7K29'),
            schoolName: res.school ? res.school.name : "14-sonli umumiy o'rta ta'lim maktabi",
            role: roleNorm,
            name: `${u.first_name || ''} ${u.last_name || ''}`.trim() || u.username,
            email: u.email,
            phone: u.phone,
            classId: u.class_id || '10-A',
            loginAt: new Date().toISOString()
          };
          DB.setSession(session);
          return {
            user: { ...u, name: session.name },
            school: res.school || { code: session.schoolCode, name: session.schoolName },
            session
          };
        }
      } catch (apiErr) {
        // If backend explicitly rejected credentials or blocked account, report immediately
        if (apiErr.status === 401 || apiErr.status === 403) {
          throw apiErr;
        }
        console.warn('Backend login fallback to local DB:', apiErr.message);
      }
    }

    const cleanIdent = identifier.trim().toLowerCase();
    const cleanPass = password.trim();

    // 1. Direct fast bypass for 2 system administrators
    if ((cleanIdent === 'admin' || cleanIdent === 'admin@14maktab.uz') && (cleanPass === 'admin123' || cleanPass === '123456')) {
      const user = DB.getUsers().find(u => u.username === 'admin' || u.role === 'admin') || {
        id: 'usr_admin_1',
        schoolCode: 'TERMIZ-14-7K29',
        role: 'admin',
        name: 'Rustamov Alisher (Admin 1)',
        email: 'admin@14maktab.uz',
        plainPassword: 'admin123'
      };
      const school = DB.getSchoolByCode('TERMIZ-14-7K29') || DB.getSchools()[0];
      const session = {
        token: "sess_admin_" + Date.now(),
        userId: user.id,
        schoolCode: school ? school.code : 'TERMIZ-14-7K29',
        role: 'admin',
        name: user.name,
        email: user.email,
        loginAt: new Date().toISOString()
      };
      DB.setSession(session);
      return { user, school, session };
    }

    if ((cleanIdent === 'superadmin' || cleanIdent === 'superadmin@14maktab.uz') && (cleanPass === 'admin123' || cleanPass === '123456')) {
      const user = DB.getUsers().find(u => u.username === 'superadmin' || u.role === 'superadmin') || {
        id: 'usr_admin_2',
        schoolCode: 'TERMIZ-14-7K29',
        role: 'superadmin',
        name: 'Karimov Dilshod (IT SuperAdmin 2)',
        email: 'superadmin@14maktab.uz',
        plainPassword: 'admin123'
      };
      const school = DB.getSchoolByCode('TERMIZ-14-7K29') || DB.getSchools()[0];
      const session = {
        token: "sess_superadmin_" + Date.now(),
        userId: user.id,
        schoolCode: school ? school.code : 'TERMIZ-14-7K29',
        role: 'superadmin',
        name: user.name,
        email: user.email,
        loginAt: new Date().toISOString()
      };
      DB.setSession(session);
      return { user, school, session };
    }

    // 2. Direct fast bypass for Director
    if ((cleanIdent === 'director' || cleanIdent === 'director@14maktab.uz' || cleanIdent === 'direktor') && (cleanPass === 'director123' || cleanPass === '123456')) {
      const user = DB.getUsers().find(u => u.role === 'director') || {
        id: 'usr_dir_1',
        schoolCode: 'TERMIZ-14-7K29',
        role: 'director',
        name: 'Olimov Bobur',
        email: 'director@14maktab.uz',
        plainPassword: 'director123'
      };
      const school = DB.getSchoolByCode(user.schoolCode || 'TERMIZ-14-7K29') || DB.getSchools()[0];
      const session = {
        token: "sess_dir_" + Date.now(),
        userId: user.id,
        schoolCode: school ? school.code : 'TERMIZ-14-7K29',
        role: 'director',
        name: user.name,
        email: user.email,
        loginAt: new Date().toISOString()
      };
      DB.setSession(session);
      return { user, school, session };
    }

    // 3. Direct fast bypass for Teacher
    if ((cleanIdent === 'teacher' || cleanIdent === 'teacher@14maktab.uz' || cleanIdent === 'dilshod@14maktab.uz') && (cleanPass === 'teacher123' || cleanPass === 'teacher777' || cleanPass === '123456')) {
      const user = DB.getUsers().find(u => u.email === cleanIdent || u.role === 'teacher') || {
        id: 'usr_teach_1',
        schoolCode: 'TERMIZ-14-7K29',
        role: 'teacher',
        name: 'Rahimova Nigora',
        email: 'teacher@14maktab.uz',
        classId: '9-A',
        plainPassword: 'teacher123'
      };
      const school = DB.getSchoolByCode(user.schoolCode || 'TERMIZ-14-7K29') || DB.getSchools()[0];
      const session = {
        token: "sess_teach_" + Date.now(),
        userId: user.id,
        schoolCode: school ? school.code : 'TERMIZ-14-7K29',
        role: 'teacher',
        name: user.name,
        email: user.email,
        classId: user.classId || '9-A',
        loginAt: new Date().toISOString()
      };
      DB.setSession(session);
      return { user, school, session };
    }

    // 4. Direct fast bypass for Starosta / Klasskom
    if ((cleanIdent === 'starosta' || cleanIdent === 'klasskom' || cleanIdent === 'amal' || cleanIdent === 'amal@14maktab.uz' || cleanIdent === 'amal@gmail.com') && (cleanPass === 'starosta123' || cleanPass === '123456')) {
      const user = DB.getUsers().find(u => u.role === 'starosta' || (u.email && u.email.includes('amal'))) || {
        id: 'usr_star_1',
        schoolCode: 'TERMIZ-14-7K29',
        role: 'starosta',
        name: 'Rustamov Amal (Klasskom)',
        email: 'amal@14maktab.uz',
        classId: '9-A',
        plainPassword: 'starosta123'
      };
      const school = DB.getSchoolByCode(user.schoolCode || 'TERMIZ-14-7K29') || DB.getSchools()[0];
      const session = {
        token: "sess_star_" + Date.now(),
        userId: user.id,
        schoolCode: school ? school.code : 'TERMIZ-14-7K29',
        role: 'starosta',
        name: user.name,
        email: user.email,
        classId: user.classId || '9-A',
        loginAt: new Date().toISOString()
      };
      DB.setSession(session);
      return { user, school, session };
    }

    let school = schoolCode ? DB.getSchoolByCode(schoolCode) : null;
    let user = DB.findUserByLogin(schoolCode, identifier);

    if (!user) {
      const allUsers = DB.getUsers();
      const cleanPhone = identifier.replace(/[^0-9]/g, '');
      user = allUsers.find(u => 
        (u.email && u.email.toLowerCase() === cleanIdent) ||
        (u.username && u.username.toLowerCase() === cleanIdent) ||
        (cleanPhone && u.phone && u.phone.replace(/[^0-9]/g, '').includes(cleanPhone))
      );
      if (user && user.schoolCode) {
        school = DB.getSchoolByCode(user.schoolCode);
      }
    }

    if (!school) {
      const allSchools = DB.getSchools();
      school = (allSchools.length > 0) ? allSchools[0] : { code: 'TERMIZ-14-7K29', name: "14-sonli umumiy o'rta ta'lim maktabi" };
    }

    if (!user) {
      throw new Error(currentLang === 'uz' ? 'Foydalanuvchi topilmadi! Login yoki parolni tekshiring.' : 'Пользователь не найден! Проверьте логин или пароль.');
    }

    // Verify Password
    const isValid = await DB.verifyPassword(password, user.plainPassword || user.passwordHash, user.salt);
    if (!isValid) {
      throw new Error(currentLang === 'uz' ? 'Parol noto\'g\'ri kiritildi!' : 'Неверный пароль!');
    }

    if (user.status === 'blocked') {
      throw new Error(currentLang === 'uz' ? 'Hisobingiz ma\'muriyat tomonidan bloklangan!' : 'Ваш аккаунт заблокирован администрацией!');
    }

    const session = {
      token: "sess_" + Math.random().toString(36).substring(2),
      userId: user.id,
      schoolCode: school.code,
      schoolName: school.name,
      role: user.role,
      name: user.name,
      email: user.email,
      phone: user.phone,
      classId: user.classId || '9-A',
      loginAt: new Date().toISOString()
    };
    DB.setSession(session);

    return { user, school, session };
  }

  // 4. Register Teacher with Grade, Letter, Student Count & Database Notification
  async function registerTeacherWithClass({ schoolCode, fullName, grade, letter, studentCount, email, phone, password }) {
    if (!fullName || !password) {
      throw new Error(t('errFillAllFields'));
    }
    if (password.length < 6) {
      throw new Error(t('errPasswordTooShort'));
    }

    const cleanSchoolCode = (schoolCode || 'TERMIZ-14-7K29').trim().toUpperCase();
    const school = DB.getSchoolByCode(cleanSchoolCode) || DB.getSchools()[0];
    const gradeNum = parseInt(grade, 10) || 9;
    const letterStr = (letter || 'A').trim().toUpperCase();
    const classId = `${gradeNum}-${letterStr}`;
    const sCount = parseInt(studentCount, 10) || 25;
    const cleanEmail = (email || '').trim().toLowerCase();
    const cleanPhone = (phone || '').trim();

    // Check existing
    const existing = DB.findUserByLogin(school.code, cleanEmail || fullName);
    if (existing) {
      throw new Error(currentLang === 'uz' ? 'Ushbu foydalanuvchi allaqachon ro\'yxatdan o\'tgan!' : 'Этот пользователь уже зарегистрирован!');
    }

    // Try backend call
    try {
      await fetch('/api/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          role: 'teacher',
          schoolCode: school.code,
          fullName: fullName.trim(),
          email: cleanEmail,
          phone: cleanPhone,
          password: password,
          grade: gradeNum,
          letter: letterStr,
          classId: classId,
          studentCount: sCount
        })
      });
    } catch(e) {}

    const passHash = await DB.hashPassword(password);
    const userId = "usr_" + Date.now().toString(36) + Math.random().toString(36).substring(2, 5);

    const newUser = {
      id: userId,
      schoolCode: school.code,
      role: 'teacher',
      name: fullName.trim(),
      phone: cleanPhone,
      email: cleanEmail || `${userId}@14maktab.uz`,
      username: (cleanEmail ? cleanEmail.split('@')[0] : fullName.toLowerCase().replace(/\s+/g, '_')),
      plainPassword: password, // Retained clearly for Admin & Director oversight
      passwordHash: passHash.hash,
      salt: passHash.salt,
      status: 'active',
      classId: classId,
      grade: gradeNum,
      letter: letterStr,
      studentCount: sCount,
      createdAt: new Date().toISOString()
    };
    DB.saveUser(newUser);

    // Ensure class exists
    let cls = DB.getClassesBySchool(school.code).find(c => c.classId === classId);
    if (!cls) {
      cls = {
        id: 'cls_' + gradeNum + '_' + letterStr.toLowerCase() + '_' + Date.now().toString(36).substring(4),
        schoolCode: school.code,
        classId: classId,
        grade: gradeNum,
        letter: letterStr,
        teacherName: newUser.name,
        teacherId: userId,
        studentCount: sCount,
        createdAt: new Date().toISOString()
      };
      DB.saveClass(cls);
    } else {
      cls.teacherName = newUser.name;
      cls.teacherId = userId;
      cls.studentCount = sCount;
      DB.saveClass(cls);
    }

    // Auto generate students if empty
    const existingStudents = DB.getStudentsByClass(school.code, classId);
    if (existingStudents.length === 0) {
      for (let i = 1; i <= sCount; i++) {
        DB.saveStudent({
          id: `std_${gradeNum}${letterStr.toLowerCase()}_${i}_${Date.now().toString(36).substring(5)}`,
          schoolCode: school.code,
          classId: classId,
          name: `O'quvchi ${i} (${classId})`,
          phone: '+998 90 ' + String(100 + i).padStart(3, '0') + ' 00 00'
        });
      }
    }

    // Record Database Notification for SuperAdmin & Director
    const notif = {
      id: 'notif_' + Date.now().toString(36),
      type: 'teacher_registered',
      title: "Yangi o'qituvchi ro'yxatdan o'tdi",
      message: `${newUser.name} ${classId} sinfini (${sCount} ta o'quvchi) biriktirib ro'yxatdan o'tdi`,
      teacherName: newUser.name,
      classId: classId,
      grade: gradeNum,
      letter: letterStr,
      studentCount: sCount,
      email: newUser.email,
      phone: newUser.phone,
      plainPassword: password,
      timestamp: new Date().toISOString(),
      read: false
    };
    DB.addNotification(notif);

    const session = {
      token: "sess_" + Math.random().toString(36).substring(2),
      userId: newUser.id,
      schoolCode: school.code,
      schoolName: school.name,
      role: 'teacher',
      name: newUser.name,
      email: newUser.email,
      phone: newUser.phone,
      classId: classId,
      loginAt: new Date().toISOString()
    };
    DB.setSession(session);

    return { user: newUser, school, session };
  }

  // 5. Register Starosta with Class
  async function registerStarostaWithClass({ schoolCode, fullName, grade, letter, phone, email, password }) {
    if (!fullName || !password) {
      throw new Error(t('errFillAllFields'));
    }
    if (password.length < 6) {
      throw new Error(t('errPasswordTooShort'));
    }

    const cleanSchoolCode = (schoolCode || 'TERMIZ-14-7K29').trim().toUpperCase();
    const school = DB.getSchoolByCode(cleanSchoolCode) || DB.getSchools()[0];
    const gradeNum = parseInt(grade, 10) || 9;
    const letterStr = (letter || 'A').trim().toUpperCase();
    const classId = `${gradeNum}-${letterStr}`;
    const cleanEmail = (email || '').trim().toLowerCase();
    const cleanPhone = (phone || '').trim();

    const passHash = await DB.hashPassword(password);
    const userId = "usr_" + Date.now().toString(36) + Math.random().toString(36).substring(2, 5);

    const newUser = {
      id: userId,
      schoolCode: school.code,
      role: 'starosta',
      name: fullName.trim(),
      phone: cleanPhone,
      email: cleanEmail || `${userId}@14maktab.uz`,
      username: (cleanEmail ? cleanEmail.split('@')[0] : fullName.toLowerCase().replace(/\s+/g, '_')),
      plainPassword: password,
      passwordHash: passHash.hash,
      salt: passHash.salt,
      status: 'active',
      classId: classId,
      grade: gradeNum,
      letter: letterStr,
      createdAt: new Date().toISOString()
    };
    DB.saveUser(newUser);

    let cls = DB.getClassesBySchool(school.code).find(c => c.classId === classId);
    if (!cls) {
      cls = {
        id: 'cls_' + gradeNum + '_' + letterStr.toLowerCase() + '_' + Date.now().toString(36).substring(4),
        schoolCode: school.code,
        classId: classId,
        grade: gradeNum,
        letter: letterStr,
        studentCount: 25,
        createdAt: new Date().toISOString()
      };
      DB.saveClass(cls);
    }

    DB.saveStudent({
      id: 'std_star_' + userId,
      schoolCode: school.code,
      classId: classId,
      name: newUser.name,
      phone: newUser.phone
    });

    const notif = {
      id: 'notif_' + Date.now().toString(36),
      type: 'starosta_registered',
      title: "Yangi sinf sardori ro'yxatdan o'tdi",
      message: `${newUser.name} ${classId} sinfi sardori sifatida ro'yxatdan o'tdi`,
      teacherName: newUser.name,
      classId: classId,
      grade: gradeNum,
      letter: letterStr,
      email: newUser.email,
      phone: newUser.phone,
      plainPassword: password,
      timestamp: new Date().toISOString(),
      read: false
    };
    DB.addNotification(notif);

    const session = {
      token: "sess_" + Math.random().toString(36).substring(2),
      userId: newUser.id,
      schoolCode: school.code,
      schoolName: school.name,
      role: 'starosta',
      name: newUser.name,
      email: newUser.email,
      phone: newUser.phone,
      classId: classId,
      loginAt: new Date().toISOString()
    };
    DB.setSession(session);

    return { user: newUser, school, session };
  }

  // 6. Direct Member (Teacher / Student) Registration (Legacy fallback)
  async function registerMember(args) {
    if (args.role === 'teacher') {
      const parts = (args.classId || '9-A').split('-');
      return registerTeacherWithClass({
        schoolCode: args.schoolCode,
        fullName: args.fullName,
        grade: parseInt(parts[0], 10) || 9,
        letter: parts[1] || 'A',
        studentCount: 25,
        email: args.email,
        phone: args.phone,
        password: args.password
      });
    }
    const parts = (args.classId || '9-A').split('-');
    return registerStarostaWithClass({
      schoolCode: args.schoolCode,
      fullName: args.fullName,
      grade: parseInt(parts[0], 10) || 9,
      letter: parts[1] || 'A',
      email: args.email,
      phone: args.phone,
      password: args.password
    });
  }

  // 7. Fast Admin Login
  async function loginAdmin(username = 'admin', password = 'admin123') {
    return login(null, username, password);
  }

  // 8. Logout
  function logout() {
    DB.clearSession();
  }

  // 9. Current Session Check
  function getCurrentSession() {
    return DB.getSession();
  }

  return {
    registerSchool,
    registerMember,
    registerTeacherWithClass,
    registerStarostaWithClass,
    submitJoinRequest,
    acceptInviteAndRegister,
    login,
    loginAdmin,
    logout,
    getCurrentSession
  };
})();

