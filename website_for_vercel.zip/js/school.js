/**
 * 14-Maktab / Jurnal - School & Class Management
 * Grade 11-to-1 Hierarchy, Letter Selectors, Teacher Approvals, Director Aggregates.
 */

const SchoolManager = (function() {

  const ALL_GRADES = [11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1];
  const DEFAULT_LETTERS = ['A', 'B', 'V', 'G', 'D', 'E'];

  // 1. Get classes grouped by grade
  function getClassesByGrade(schoolCode, grade) {
    const classes = DB.getClassesBySchool(schoolCode);
    return classes.filter(c => Number(c.grade) === Number(grade));
  }

  // 2. Add new class to school
  function addClass(schoolCode, grade, letter) {
    const cleanGrade = Number(grade);
    const cleanLetter = (letter || 'A').trim().toUpperCase();
    const classId = `${cleanGrade}-${cleanLetter}`;

    const existing = DB.getClassesBySchool(schoolCode).find(c => c.classId === classId);
    if (existing) {
      throw new Error(currentLang === 'uz' ? 'Ushbu sinf allaqachon mavjud!' : 'Этот класс уже существует!');
    }

    const newClass = {
      id: `cls_${schoolCode}_${cleanGrade}_${cleanLetter}`.toLowerCase(),
      schoolCode: schoolCode,
      grade: cleanGrade,
      letter: cleanLetter,
      classId: classId,
      manuallyCreated: true,
      teacherId: null,
      starostaId: null,
      createdAt: new Date().toISOString()
    };
    DB.saveClass(newClass);
    return newClass;
  }

  // 3. Get detailed class information
  function getClassDetail(schoolCode, classId, dateStr) {
    if (!dateStr) {
      dateStr = new Date().toISOString().split('T')[0];
    }
    const classes = DB.getClassesBySchool(schoolCode);
    const cls = classes.find(c => c.classId === classId) || {
      classId: classId,
      schoolCode: schoolCode,
      grade: parseInt(classId, 10) || 10,
      letter: classId.replace(/^[0-9]+-?/, '') || 'A',
      teacherId: null,
      starostaId: null
    };

    const teacher = cls.teacherId ? DB.getUserById(cls.teacherId) : null;
    const starosta = cls.starostaId ? DB.getUserById(cls.starostaId) : null;
    const students = DB.getStudentsByClass(schoolCode, classId);
    const attendance = DB.getAttendanceForDate(schoolCode, classId, dateStr);

    let presentCount = 0;
    let absentCount = 0;
    let excusedCount = 0;
    let lateCount = 0;

    const studentRows = students.map(s => {
      const att = attendance.find(a => a.studentId === s.id);
      const status = att ? att.status : 'present';
      if (status === 'present') presentCount++;
      else if (status === 'absent') absentCount++;
      else if (status === 'excused') excusedCount++;
      else if (status === 'late') lateCount++;

      return {
        ...s,
        status: status,
        reason: att ? att.reason : '',
        note: att ? att.note : ''
      };
    });

    const total = students.length;
    const rate = total > 0 ? Math.round((presentCount / total) * 100) : 100;

    return {
      classInfo: cls,
      teacher: teacher,
      starosta: starosta,
      totalStudents: total,
      presentCount: presentCount,
      absentCount: absentCount,
      excusedCount: excusedCount,
      lateCount: lateCount,
      attendanceRate: rate,
      students: studentRows
    };
  }

  // 4. Overall School Attendance Statistics (for Director Dashboard)
  function getSchoolSummaryStats(schoolCode, dateStr) {
    if (!dateStr) {
      dateStr = new Date().toISOString().split('T')[0];
    }
    const allStudents = DB.getAllStudentsBySchool(schoolCode);
    const allAttendance = DB.getAllAttendanceForSchoolDate(schoolCode, dateStr);

    let total = allStudents.length;
    let present = 0;
    let absent = 0;
    let excused = 0;
    let late = 0;

    allStudents.forEach(st => {
      const att = allAttendance.find(a => a.studentId === st.id);
      const status = att ? att.status : 'present';
      if (status === 'present') present++;
      else if (status === 'absent') absent++;
      else if (status === 'excused') excused++;
      else if (status === 'late') late++;
    });

    const rate = total > 0 ? ((present / total) * 100).toFixed(1) : "100.0";

    return {
      totalStudents: total,
      presentCount: present,
      absentCount: absent,
      excusedCount: excused,
      lateCount: late,
      rate: rate
    };
  }

  // 5. Teacher and Starosta Join Request Approvals
  function getPendingJoinRequests(schoolCode) {
    return DB.getJoinRequestsBySchool(schoolCode).filter(r => r.status === 'pending');
  }

  function approveJoinRequest(reqId) {
    const req = DB.updateJoinRequestStatus(reqId, 'approved');
    if (!req) return null;

    // Activate user
    const user = DB.getUserById(req.userId);
    if (user) {
      user.status = 'active';
      DB.saveUser(user);

      // Link to class
      if (user.classId) {
        const cls = DB.getClassesBySchool(user.schoolCode).find(c => c.classId === user.classId);
        if (cls) {
          if (user.role === 'teacher') cls.teacherId = user.id;
          else if (user.role === 'starosta') cls.starostaId = user.id;
          DB.saveClass(cls);
        }
      }
    }
    return req;
  }

  function rejectJoinRequest(reqId) {
    return DB.updateJoinRequestStatus(reqId, 'rejected');
  }

  // 6. Approved Teachers list
  function getApprovedTeachers(schoolCode) {
    const users = DB.getUsersBySchool(schoolCode);
    return users.filter(u => u.role === 'teacher' && (u.status === 'active' || u.status === 'approved'));
  }

  // 7. Update User Profile (Director / Teacher)
  function updateUserProfile(userId, updates) {
    const user = DB.getUserById(userId);
    if (!user) throw new Error(currentLang === 'uz' ? 'Foydalanuvchi topilmadi!' : 'Пользователь не найден!');
    if (updates.name) user.name = updates.name.trim();
    if (updates.phone) user.phone = updates.phone.trim();
    if (updates.email) user.email = updates.email.trim();
    DB.saveUser(user);

    // If director, also update school director credentials
    if (user.role === 'director') {
      const school = DB.getSchoolByCode(user.schoolCode);
      if (school) {
        if (updates.name) school.directorName = updates.name.trim();
        if (updates.phone) school.directorPhone = updates.phone.trim();
        if (updates.email) school.directorEmail = updates.email.trim();
        DB.saveSchool(school);
      }
    }
    return user;
  }

  // 8. Get all registered classes for a school (sorted cleanly)
  function getSchoolClasses(schoolCode) {
    const classes = DB.getClassesBySchool(schoolCode);
    return classes.sort((a, b) => {
      const gA = Number(a.grade) || 0;
      const gB = Number(b.grade) || 0;
      if (gB !== gA) return gB - gA;
      return (a.letter || '').localeCompare(b.letter || '');
    });
  }

  // 9. Delete a class
  function deleteClass(schoolCode, classId) {
    return DB.deleteClass(schoolCode, classId);
  }

  return {
    ALL_GRADES,
    DEFAULT_LETTERS,
    getClassesByGrade,
    getSchoolClasses,
    addClass,
    deleteClass,
    getClassDetail,
    getSchoolSummaryStats,
    getPendingJoinRequests,
    approveJoinRequest,
    rejectJoinRequest,
    getApprovedTeachers,
    updateUserProfile
  };
})();
