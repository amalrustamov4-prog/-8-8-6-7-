/**
 * 14-Maktab / Jurnal - Attendance Management
 * Student records, Attendance tracking, Reason attribution, Telegram & Director Reports.
 */

const AttendanceManager = (function() {

  // 1. Add student with duplicate check
  function addStudent(schoolCode, classId, lastName, firstName, phone, parentPhone = '') {
    const cleanLast = (lastName || '').trim();
    const cleanFirst = (firstName || '').trim();
    const cleanPhone = (phone || '').trim();
    const cleanParent = (parentPhone || '').trim();

    if (!cleanLast || !cleanFirst) {
      throw new Error(t('errFillAllFields'));
    }

    const existingStudents = DB.getStudentsByClass(schoolCode, classId);
    const isDup = existingStudents.some(s =>
      s.lastName.toLowerCase() === cleanLast.toLowerCase() &&
      s.firstName.toLowerCase() === cleanFirst.toLowerCase()
    );

    if (isDup) {
      throw new Error(t('errDuplicateStudent'));
    }

    const newStudent = {
      id: "std_" + Date.now().toString(36) + Math.random().toString(36).substring(2, 5),
      schoolCode: schoolCode,
      classId: classId,
      lastName: cleanLast,
      firstName: cleanFirst,
      phone: cleanPhone,
      parentPhone: cleanParent,
      createdAt: new Date().toISOString()
    };
    DB.saveStudent(newStudent);
    return newStudent;
  }

  // 2. Set attendance status for a student on a specific date
  function setStudentStatus(schoolCode, classId, studentId, dateStr, status, reason = '', note = '') {
    const record = {
      id: `att_${studentId}_${dateStr}`,
      schoolCode: schoolCode,
      classId: classId,
      studentId: studentId,
      date: dateStr,
      status: status,
      reason: reason,
      note: note,
      updatedAt: new Date().toISOString()
    };
    DB.saveAttendanceRecords([record]);
    return record;
  }

  // 3. Mark all students as present
  function markAllPresent(schoolCode, classId, dateStr) {
    const students = DB.getStudentsByClass(schoolCode, classId);
    const records = students.map(st => ({
      id: `att_${st.id}_${dateStr}`,
      schoolCode: schoolCode,
      classId: classId,
      studentId: st.id,
      date: dateStr,
      status: 'present',
      reason: '',
      note: '',
      updatedAt: new Date().toISOString()
    }));
    DB.saveAttendanceRecords(records);
    return records;
  }

  // 4. Build formatted report text
  function formatReportText(schoolName, classId, senderName, senderRole, dateDisplay, stats, absentList, excusedList, lateList) {
    const isUz = (currentLang === 'uz');
    const roleTitle = senderRole === 'starosta'
      ? (isUz ? 'Sinf sardori' : 'Староста')
      : (isUz ? 'Sinf rahbari' : 'Классный руководитель');

    let text = `📊 ${classId} ${isUz ? 'SINF DAVOMAT HISOBOTI' : 'ОТЧЁТ ПО ПОСЕЩАЕМОСТИ КЛАССА'} (${dateDisplay})\n`;
    text += `🏫 ${schoolName}\n`;
    text += `👤 ${isUz ? 'Yuboruvchi' : 'Отправитель'} (${roleTitle}): ${senderName}\n\n`;

    text += `📌 ${isUz ? 'Jami o\'quvchilar' : 'Всего учеников'}: ${stats.totalStudents} ${isUz ? 'nafar' : 'чел.'}\n`;
    text += `✅ ${isUz ? 'Darsda (Keldi)' : 'Присутствуют'}: ${stats.presentCount} ${isUz ? 'nafar' : 'чел.'}\n`;
    text += `❌ ${isUz ? 'Kelmadi' : 'Отсутствуют'}: ${stats.absentCount + stats.excusedCount} ${isUz ? 'nafar' : 'чел.'}\n`;

    if (stats.lateCount > 0) {
      text += `⏰ ${isUz ? 'Kechikdi' : 'Опоздали'}: ${stats.lateCount} ${isUz ? 'nafar' : 'чел.'}\n`;
    }

    if (excusedList && excusedList.length > 0) {
      text += `\n🟡 ${isUz ? 'Sababli kelmaganlar' : 'По уважительной причине'}:\n`;
      excusedList.forEach((st, idx) => {
        text += `${idx + 1}. ${st.name} (${st.reason || (isUz ? 'Sababli' : 'По причине')}${st.note ? ' - ' + st.note : ''})\n`;
      });
    }

    if (absentList && absentList.length > 0) {
      text += `\n🔴 ${isUz ? 'Sababsiz kelmaganlar' : 'Без уважительной причины'}:\n`;
      absentList.forEach((st, idx) => {
        text += `${idx + 1}. ${st.name}${st.note ? ' (' + st.note + ')' : ''}\n`;
      });
    }

    if (lateList && lateList.length > 0) {
      text += `\n⏰ ${isUz ? 'Kechikkanlar' : 'Опоздавшие'}:\n`;
      lateList.forEach((st, idx) => {
        text += `${idx + 1}. ${st.name}${st.note ? ' (' + st.note + ')' : ''}\n`;
      });
    }

    text += `\n${isUz ? 'Hurmat bilan' : 'С уважением'}, ${senderName}.`;
    return text;
  }

  // 5. Send report to Director and optionally Telegram
  function sendReport(session, school, classId, dateStr, dateDisplay) {
    const detail = SchoolManager.getClassDetail(school.code, classId, dateStr);
    const absentList = detail.students.filter(s => s.status === 'absent').map(s => ({ name: `${s.lastName} ${s.firstName}`, note: s.note }));
    const excusedList = detail.students.filter(s => s.status === 'excused').map(s => ({ name: `${s.lastName} ${s.firstName}`, reason: s.reason, note: s.note }));
    const lateList = detail.students.filter(s => s.status === 'late').map(s => ({ name: `${s.lastName} ${s.firstName}`, note: s.note }));

    const text = formatReportText(
      school.name,
      classId,
      session.name,
      session.role,
      dateDisplay,
      detail,
      absentList,
      excusedList,
      lateList
    );

    const reportObj = {
      id: "rep_" + Date.now().toString(36),
      schoolCode: school.code,
      classId: classId,
      date: dateStr,
      dateDisplay: dateDisplay,
      sentAt: new Date().toISOString(),
      senderName: session.name,
      senderRole: session.role,
      totalStudents: detail.totalStudents,
      presentCount: detail.presentCount,
      absentCount: detail.absentCount,
      excusedCount: detail.excusedCount,
      lateCount: detail.lateCount,
      absentList: absentList,
      excusedList: excusedList,
      lateList: lateList,
      reportText: text,
      read: false
    };

    DB.saveReport(reportObj);

    // Asynchronously dispatch to Enterprise REST API v1
    if (typeof ApiClient !== 'undefined' && ApiClient.attendance) {
      const apiRecords = detail.students.map(s => {
        let statusUpper = 'PRESENT';
        if (s.status === 'absent') statusUpper = 'ABSENT';
        else if (s.status === 'late') statusUpper = 'LATE';
        else if (s.status === 'excused') statusUpper = 'EXCUSED';

        return {
          student_id: s.id,
          status: statusUpper,
          reason_category: s.reason || (statusUpper === 'EXCUSED' ? 'Болезнь' : null),
          reason_text: s.note || s.reason || '',
          late_minutes: statusUpper === 'LATE' ? (parseInt(s.late_minutes, 10) || 15) : null
        };
      });

      ApiClient.attendance.submit({
        class_id: classId,
        date: dateStr,
        records: apiRecords
      }).then(res => {
        console.log('✅ Enterprise Attendance synced to Director API:', res);
      }).catch(err => {
        console.warn('REST API v1 attendance submit notice:', err.message);
      });
    }

    return { report: reportObj, text: text };
  }

  return {
    addStudent,
    setStudentStatus,
    markAllPresent,
    formatReportText,
    sendReport
  };
})();
