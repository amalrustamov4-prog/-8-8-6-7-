/**
 * 14-Maktab / Jurnal - Database & Security Layer
 * Structured Storage, Cryptographic Password Hashing, Safe Isolation.
 */

const DB = (function() {
  const STORAGE_KEYS = {
    SCHOOLS: 'jurnal_v4_schools',
    USERS: 'jurnal_v4_users',
    CLASSES: 'jurnal_v4_classes',
    STUDENTS: 'jurnal_v4_students',
    ATTENDANCE: 'jurnal_v4_attendance',
    JOIN_REQUESTS: 'jurnal_v4_join_requests',
    REPORTS: 'jurnal_v4_reports',
    INVITES: 'jurnal_v4_invites',
    NOTIFICATIONS: 'jurnal_v4_notifications',
    SESSION: 'jurnal_v4_session'
  };

  // 1. Password Hashing (SHA-256 + Salt)
  async function hashPassword(password, salt) {
    if (!salt) {
      salt = Math.random().toString(36).substring(2, 10);
    }
    const encoder = new TextEncoder();
    const data = encoder.encode(password + salt);
    const hashBuffer = await crypto.subtle.digest('SHA-256', data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
    return { hash: hashHex, salt: salt };
  }

  async function verifyPassword(password, storedHash, storedSalt) {
    if (!storedHash) return false;
    // Direct match support for plain password in database
    if (password === storedHash) return true;
    if (!storedSalt) return password === storedHash;
    const result = await hashPassword(password, storedSalt);
    return result.hash === storedHash;
  }

  // 2. Storage Helpers
  function getCollection(key) {
    try {
      const data = localStorage.getItem(key);
      return data ? JSON.parse(data) : [];
    } catch (e) {
      console.error('Error reading collection ' + key, e);
      return [];
    }
  }

  function saveCollection(key, data) {
    try {
      localStorage.setItem(key, JSON.stringify(data));
    } catch (e) {
      console.error('Error saving collection ' + key, e);
    }
  }

  // Asynchronous sync to backend server (data/database.json)
  async function syncToServer() {
    try {
      const payload = {
        schools: getCollection(STORAGE_KEYS.SCHOOLS),
        users: getCollection(STORAGE_KEYS.USERS),
        classes: getCollection(STORAGE_KEYS.CLASSES),
        students: getCollection(STORAGE_KEYS.STUDENTS),
        attendance: getCollection(STORAGE_KEYS.ATTENDANCE),
        reports: getCollection(STORAGE_KEYS.REPORTS),
        notifications: getCollection(STORAGE_KEYS.NOTIFICATIONS)
      };
      await fetch('/api/sync', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
    } catch (e) {
      // Offline fallback
    }
  }

  // Purge any lingering mock/fake classes and demo students on every app start
  function purgeMockData() {
    try {
      if (localStorage.getItem('jurnal_clean_sync_v8') !== 'true') {
        localStorage.removeItem(STORAGE_KEYS.CLASSES);
        localStorage.removeItem(STORAGE_KEYS.STUDENTS);
        localStorage.removeItem(STORAGE_KEYS.USERS);
        localStorage.setItem('jurnal_clean_sync_v8', 'true');
      }
    } catch(e) {}
  }

  // 3. Initial Demo Seed Data & Server Synchronization
  async function ensureDefaultSeed() {
    purgeMockData();

    // 1. First attempt to pull fresh state from backend server
    try {
      const res = await fetch('/api/db');
      if (res.ok) {
        const json = await res.json();
        if (json && json.ok && json.data) {
          const sdb = json.data;
          if (Array.isArray(sdb.schools) && sdb.schools.length > 0) saveCollection(STORAGE_KEYS.SCHOOLS, sdb.schools);
          if (Array.isArray(sdb.users) && sdb.users.length > 0) saveCollection(STORAGE_KEYS.USERS, sdb.users);
          if (Array.isArray(sdb.classes)) saveCollection(STORAGE_KEYS.CLASSES, sdb.classes);
          if (Array.isArray(sdb.students)) saveCollection(STORAGE_KEYS.STUDENTS, sdb.students);
          if (Array.isArray(sdb.attendance)) saveCollection(STORAGE_KEYS.ATTENDANCE, sdb.attendance);
          if (Array.isArray(sdb.reports)) saveCollection(STORAGE_KEYS.REPORTS, sdb.reports);
          if (Array.isArray(sdb.notifications)) saveCollection(STORAGE_KEYS.NOTIFICATIONS, sdb.notifications);
          return;
        }
      }
    } catch (err) {
      // Server not reachable, continue with local seed
    }

    const schools = getCollection(STORAGE_KEYS.SCHOOLS);
    if (schools.length > 0) return; // Already initialized

    const schoolCode = "TERMIZ-14-7K29";
    const dirPass = await hashPassword("director123");
    const teachPass = await hashPassword("teacher123");
    const starPass = await hashPassword("starosta123");
    const adminPass = await hashPassword("admin123");

    // School
    const defaultSchool = {
      id: "school_14_termiz",
      code: schoolCode,
      number: "14",
      region: "Surxondaryo viloyati",
      city: "Termiz shahri",
      name: "14-sonli umumiy o'rta ta'lim maktabi",
      directorName: "Olimov Bobur",
      directorPhone: "+998 90 123 00 14",
      directorEmail: "director@14maktab.uz",
      createdAt: new Date().toISOString()
    };
    saveCollection(STORAGE_KEYS.SCHOOLS, [defaultSchool]);

    // Users (2 Admins with open passwords + Director + Teacher + Starosta)
    const defaultUsers = [
      {
        id: "usr_admin_1",
        schoolCode: schoolCode,
        role: "admin",
        name: "Rustamov Alisher (Admin 1)",
        phone: "+998 90 111 22 33",
        email: "admin@14maktab.uz",
        username: "admin",
        plainPassword: "admin123",
        passwordHash: adminPass.hash,
        salt: adminPass.salt,
        status: "active",
        classId: null,
        createdAt: new Date().toISOString()
      },
      {
        id: "usr_admin_2",
        schoolCode: schoolCode,
        role: "superadmin",
        name: "Karimov Dilshod (IT SuperAdmin 2)",
        phone: "+998 90 777 88 99",
        email: "superadmin@14maktab.uz",
        username: "superadmin",
        plainPassword: "admin123",
        passwordHash: adminPass.hash,
        salt: adminPass.salt,
        status: "active",
        classId: null,
        createdAt: new Date().toISOString()
      },
      {
        id: "usr_dir_1",
        schoolCode: schoolCode,
        role: "director",
        name: "Olimov Bobur",
        phone: "+998 90 123 00 14",
        email: "director@14maktab.uz",
        username: "director",
        plainPassword: "director123",
        passwordHash: dirPass.hash,
        salt: dirPass.salt,
        status: "active",
        classId: null,
        createdAt: new Date().toISOString()
      },
      {
        id: "usr_teach_1",
        schoolCode: schoolCode,
        role: "teacher",
        name: "Rahimova Nigora",
        phone: "+998 90 123 45 67",
        email: "teacher@14maktab.uz",
        username: "rahimova_n",
        plainPassword: "teacher123",
        passwordHash: teachPass.hash,
        salt: teachPass.salt,
        status: "active",
        classId: "9-A",
        grade: 9,
        letter: "A",
        studentCount: 26,
        createdAt: new Date().toISOString()
      },
      {
        id: "usr_star_1",
        schoolCode: schoolCode,
        role: "starosta",
        name: "Rustamov Amal",
        phone: "+998 90 999 88 77",
        email: "amal@14maktab.uz",
        username: "amal_starosta",
        plainPassword: "starosta123",
        passwordHash: starPass.hash,
        salt: starPass.salt,
        status: "active",
        classId: "9-A",
        grade: 9,
        letter: "A",
        createdAt: new Date().toISOString()
      }
    ];
    saveCollection(STORAGE_KEYS.USERS, defaultUsers);

    // Default Class 9-A
    const defaultClasses = [
      {
        id: "cls_9_a",
        schoolCode: schoolCode,
        classId: "9-A",
        grade: 9,
        letter: "A",
        teacherName: "Rahimova Nigora",
        teacherId: "usr_teach_1",
        studentCount: 26,
        createdAt: new Date().toISOString()
      }
    ];
    saveCollection(STORAGE_KEYS.CLASSES, defaultClasses);

    // Default students for 9-A
    const defaultStudents = [];
    const names = [
      "Abdullayev Aziz", "Berdiyev Sanjar", "Eshmurodova Rayhona", "G'ofurov Javohir",
      "Hasanov Dilmurod", "Ismoilova Madina", "Jalilov Otabek", "Karimova Zilola",
      "Mahmudov Bobur", "Norboyeva Gulnoza", "Olimov Sardor", "Panjiyev Elbek",
      "Qodirova Shahlo", "Rustamov Amal", "Sobirova Durdona", "Toshpo'latov Sherzod",
      "Umarov Farrux", "Vohidova Sevara", "Xoliqov Temur", "Yoqubova Nozimaxon",
      "Zokirov Jasur", "Aliyeva Diyora", "Boymurodov Shaxboz", "Choriyev Bekzod",
      "Davlatov Mirjalol", "Ergasheva Mohira"
    ];
    names.forEach((nm, idx) => {
      defaultStudents.push({
        id: `std_9a_${idx + 1}`,
        schoolCode: schoolCode,
        classId: "9-A",
        name: nm,
        phone: "+998 90 " + (100 + idx) + " 00 00"
      });
    });
    saveCollection(STORAGE_KEYS.STUDENTS, defaultStudents);
    saveCollection(STORAGE_KEYS.ATTENDANCE, []);
    saveCollection(STORAGE_KEYS.REPORTS, []);

    // Initial Database Notification
    const defaultNotifications = [
      {
        id: "notif_init_1",
        type: "teacher_registered",
        title: "Yangi o'qituvchi ro'yxatdan o'tdi",
        message: "Rahimova Nigora 9-A sinfini (26 ta o'quvchi) biriktirib ro'yxatdan o'tdi",
        teacherName: "Rahimova Nigora",
        classId: "9-A",
        grade: 9,
        letter: "A",
        studentCount: 26,
        email: "teacher@14maktab.uz",
        plainPassword: "teacher123",
        phone: "+998 90 123 45 67",
        timestamp: new Date().toISOString(),
        read: false
      }
    ];
    saveCollection(STORAGE_KEYS.NOTIFICATIONS, defaultNotifications);

    syncToServer();
  }

  // 4. API Methods
  return {
    init: ensureDefaultSeed,
    hashPassword,
    verifyPassword,

    // Schools
    getSchools: () => getCollection(STORAGE_KEYS.SCHOOLS),
    getSchoolByCode: (code) => {
      let schools = getCollection(STORAGE_KEYS.SCHOOLS);
      if (!schools || schools.length === 0) {
        const defaultSchool = {
          id: "school_14_termiz",
          code: "TERMIZ-14-7K29",
          number: "14",
          region: "Surxondaryo viloyati",
          city: "Termiz shahri",
          name: "14-sonli umumiy o'rta ta'lim maktabi",
          directorName: "Olimov Bobur",
          directorPhone: "+998 90 123 00 14",
          directorEmail: "director@14maktab.uz",
          createdAt: new Date().toISOString()
        };
        saveCollection(STORAGE_KEYS.SCHOOLS, [defaultSchool]);
        schools = [defaultSchool];
      }

      if (!code || !code.trim()) {
        return schools[0];
      }

      const clean = code.trim().toUpperCase();

      // 1. Exact match
      let found = schools.find(s => s.code.toUpperCase() === clean);
      if (found) return found;

      // 2. Normalized alphanumeric match (removes spaces, dashes, apostrophes)
      const normClean = clean.replace(/[^A-Z0-9]/g, '');
      if (normClean) {
        found = schools.find(s => s.code.toUpperCase().replace(/[^A-Z0-9]/g, '') === normClean);
        if (found) return found;
      }

      // 3. Match by number (e.g. "14 UMUMIY ORTA TALIM MAKTABI" -> "14")
      const numOnly = clean.replace(/[^0-9]/g, '');
      if (numOnly) {
        found = schools.find(s => s.number === numOnly || (s.name && s.name.includes(numOnly)));
        if (found) return found;
      }

      // 4. Word-based match (e.g. "14", "UMUMIY", "MAKTABI", "TERMIZ")
      const words = clean.split(/[\s\-_\/]+/).filter(w => w.length >= 2);
      if (words.length > 0) {
        found = schools.find(s => {
          const sText = ((s.name || '') + ' ' + (s.city || '') + ' ' + (s.code || '')).toUpperCase();
          return words.some(w => sText.includes(w));
        });
        if (found) return found;
      }

      // 5. Always fallback to the first active school in DB
      return schools[0];
    },
    getSchool: (code) => {
      return DB.getSchoolByCode(code);
    },
    saveSchool: (school) => {
      const schools = getCollection(STORAGE_KEYS.SCHOOLS);
      const cleanCode = (school.code || '').trim().toUpperCase();
      const idx = schools.findIndex(s => s.code.toUpperCase() === cleanCode);
      if (idx !== -1) {
        schools[idx] = school;
      } else {
        schools.push(school);
      }
      saveCollection(STORAGE_KEYS.SCHOOLS, schools);
      return school;
    },

    // Users
    getUsers: () => getCollection(STORAGE_KEYS.USERS),
    getUsersBySchool: (schoolCode) => {
      const users = getCollection(STORAGE_KEYS.USERS);
      return users.filter(u => u.schoolCode === schoolCode);
    },
    getUserById: (id) => {
      const users = getCollection(STORAGE_KEYS.USERS);
      return users.find(u => u.id === id) || null;
    },
    findUserByLogin: (schoolCode, identifier) => {
      const users = getCollection(STORAGE_KEYS.USERS);
      const cleanIdent = (identifier || '').trim().toLowerCase();
      const cleanPhone = cleanIdent.replace(/[^0-9]/g, '');
      const cleanSchool = (schoolCode || '').trim().toUpperCase();

      // 1. Try match by schoolCode + identifier (email, username, or phone)
      let found = users.find(u => {
        const uSchool = (u.schoolCode || '').toUpperCase();
        const schoolMatch = !cleanSchool || !uSchool || uSchool === cleanSchool;
        if (!schoolMatch) return false;

        const uEmail = (u.email || '').toLowerCase();
        const uName = (u.username || '').toLowerCase();
        const uPhone = (u.phone || '').replace(/[^0-9]/g, '');

        return uEmail === cleanIdent || uName === cleanIdent || (cleanPhone && uPhone.includes(cleanPhone));
      });

      // 2. Fallback: match by identifier across all users regardless of school code
      if (!found) {
        found = users.find(u => {
          const uEmail = (u.email || '').toLowerCase();
          const uName = (u.username || '').toLowerCase();
          const uPhone = (u.phone || '').replace(/[^0-9]/g, '');
          return uEmail === cleanIdent || uName === cleanIdent || (cleanPhone && uPhone.includes(cleanPhone));
        });
      }

      // 3. Fallback: alias mappings for demo roles (director, teacher, starosta, klasskom, admin)
      if (!found) {
        if (cleanIdent === 'director' || cleanIdent === 'direktor') {
          found = users.find(u => u.role === 'director');
        } else if (cleanIdent === 'teacher' || cleanIdent === 'oqituvchi' || cleanIdent === 'uchitel') {
          found = users.find(u => u.role === 'teacher');
        } else if (cleanIdent === 'starosta' || cleanIdent === 'sardor' || cleanIdent === 'klasskom' || cleanIdent === 'amal') {
          found = users.find(u => u.role === 'starosta' || (u.email && u.email.includes('amal')));
        } else if (cleanIdent === 'admin') {
          found = users.find(u => u.role === 'admin');
        } else if (cleanIdent === 'superadmin') {
          found = users.find(u => u.role === 'superadmin');
        }
      }

      return found || null;
    },
    saveUser: (user) => {
      const users = getCollection(STORAGE_KEYS.USERS);
      const idx = users.findIndex(u => u.id === user.id);
      if (idx !== -1) {
        users[idx] = Object.assign({}, users[idx], user);
      } else {
        users.push(user);
      }
      saveCollection(STORAGE_KEYS.USERS, users);
      syncToServer();
      return user;
    },
    deleteUser: (userId) => {
      let users = getCollection(STORAGE_KEYS.USERS);
      users = users.filter(u => u.id !== userId);
      saveCollection(STORAGE_KEYS.USERS, users);
      // Attempt server delete
      try {
        fetch('/api/users/delete', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ id: userId })
        });
      } catch (e) {}
      return true;
    },
    updateUser: (userData) => {
      const users = getCollection(STORAGE_KEYS.USERS);
      const idx = users.findIndex(u => u.id === userData.id);
      if (idx !== -1) {
        users[idx] = Object.assign({}, users[idx], userData);
        saveCollection(STORAGE_KEYS.USERS, users);
        try {
          fetch('/api/users/update', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(userData)
          });
        } catch (e) {}
        return users[idx];
      }
      return null;
    },
    getNotifications: () => getCollection(STORAGE_KEYS.NOTIFICATIONS),
    addNotification: (notif) => {
      const list = getCollection(STORAGE_KEYS.NOTIFICATIONS);
      list.unshift(notif);
      saveCollection(STORAGE_KEYS.NOTIFICATIONS, list);
      syncToServer();
      return notif;
    },
    markNotificationRead: (notifId) => {
      const list = getCollection(STORAGE_KEYS.NOTIFICATIONS);
      const item = list.find(n => n.id === notifId);
      if (item) {
        item.read = true;
        saveCollection(STORAGE_KEYS.NOTIFICATIONS, list);
        syncToServer();
      }
      return item;
    },
    syncToServer,


    // Classes
    getClassesBySchool: (schoolCode) => {
      const classes = getCollection(STORAGE_KEYS.CLASSES);
      return classes.filter(c => c.schoolCode === schoolCode);
    },
    saveClass: (cls) => {
      const classes = getCollection(STORAGE_KEYS.CLASSES);
      const idx = classes.findIndex(c => c.id === cls.id || (c.schoolCode === cls.schoolCode && c.classId === cls.classId));
      if (idx !== -1) {
        classes[idx] = cls;
      } else {
        classes.push(cls);
      }
      saveCollection(STORAGE_KEYS.CLASSES, classes);
      return cls;
    },
    deleteClass: (schoolCode, classId) => {
      const classes = getCollection(STORAGE_KEYS.CLASSES);
      const cleanSchool = (schoolCode || '').trim().toUpperCase();
      const filtered = classes.filter(c => !(c.schoolCode.toUpperCase() === cleanSchool && c.classId === classId));
      saveCollection(STORAGE_KEYS.CLASSES, filtered);

      // Clean up students belonging to this deleted class
      const students = getCollection(STORAGE_KEYS.STUDENTS);
      const filteredStudents = students.filter(s => !(s.schoolCode.toUpperCase() === cleanSchool && s.classId === classId));
      saveCollection(STORAGE_KEYS.STUDENTS, filteredStudents);
      return true;
    },

    // Students
    getStudentsByClass: (schoolCode, classId) => {
      const students = getCollection(STORAGE_KEYS.STUDENTS);
      return students.filter(s => s.schoolCode === schoolCode && s.classId === classId);
    },
    getAllStudentsBySchool: (schoolCode) => {
      const students = getCollection(STORAGE_KEYS.STUDENTS);
      return students.filter(s => s.schoolCode === schoolCode);
    },
    saveStudent: (student) => {
      const students = getCollection(STORAGE_KEYS.STUDENTS);
      const idx = students.findIndex(s => s.id === student.id);
      if (idx !== -1) {
        students[idx] = student;
      } else {
        students.push(student);
      }
      saveCollection(STORAGE_KEYS.STUDENTS, students);
      return student;
    },
    deleteStudent: (studentId) => {
      let students = getCollection(STORAGE_KEYS.STUDENTS);
      students = students.filter(s => s.id !== studentId);
      saveCollection(STORAGE_KEYS.STUDENTS, students);
    },

    // Attendance
    getAttendanceForDate: (schoolCode, classId, dateStr) => {
      const attendance = getCollection(STORAGE_KEYS.ATTENDANCE);
      return attendance.filter(a => a.schoolCode === schoolCode && a.classId === classId && a.date === dateStr);
    },
    getAllAttendanceForSchoolDate: (schoolCode, dateStr) => {
      const attendance = getCollection(STORAGE_KEYS.ATTENDANCE);
      return attendance.filter(a => a.schoolCode === schoolCode && a.date === dateStr);
    },
    saveAttendanceRecords: (records) => {
      const attendance = getCollection(STORAGE_KEYS.ATTENDANCE);
      records.forEach(rec => {
        const idx = attendance.findIndex(a => a.schoolCode === rec.schoolCode && a.classId === rec.classId && a.studentId === rec.studentId && a.date === rec.date);
        if (idx !== -1) {
          attendance[idx] = rec;
        } else {
          attendance.push(rec);
        }
      });
      saveCollection(STORAGE_KEYS.ATTENDANCE, attendance);
    },

    // Join Requests
    getJoinRequestsBySchool: (schoolCode) => {
      const reqs = getCollection(STORAGE_KEYS.JOIN_REQUESTS);
      return reqs.filter(r => r.schoolCode === schoolCode);
    },
    saveJoinRequest: (req) => {
      const reqs = getCollection(STORAGE_KEYS.JOIN_REQUESTS);
      reqs.push(req);
      saveCollection(STORAGE_KEYS.JOIN_REQUESTS, reqs);
      return req;
    },
    updateJoinRequestStatus: (reqId, status) => {
      const reqs = getCollection(STORAGE_KEYS.JOIN_REQUESTS);
      const target = reqs.find(r => r.id === reqId);
      if (target) {
        target.status = status;
        saveCollection(STORAGE_KEYS.JOIN_REQUESTS, reqs);
      }
      return target;
    },

    // Reports
    getReportsBySchool: (schoolCode) => {
      const reports = getCollection(STORAGE_KEYS.REPORTS);
      return reports.filter(r => r.schoolCode === schoolCode);
    },
    saveReport: (report) => {
      const reports = getCollection(STORAGE_KEYS.REPORTS);
      reports.unshift(report);
      saveCollection(STORAGE_KEYS.REPORTS, reports);
      return report;
    },
    markReportRead: (reportId) => {
      const reports = getCollection(STORAGE_KEYS.REPORTS);
      const rep = reports.find(r => r.id === reportId);
      if (rep) {
        rep.read = true;
        saveCollection(STORAGE_KEYS.REPORTS, reports);
      }
    },

    // Invites (Group links for teacher chat or single-use)
    createInvite: ({ schoolCode, role, classId, createdByName, isGroup = true, durationHours = 72 }) => {
      const chars = '23456789ABCDEFGHJKLMNPQRSTUVWXYZ';
      let part1 = '', part2 = '';
      for (let i = 0; i < 4; i++) part1 += chars.charAt(Math.floor(Math.random() * chars.length));
      for (let i = 0; i < 4; i++) part2 += chars.charAt(Math.floor(Math.random() * chars.length));
      const token = `${part1}-${part2}`;

      const now = Date.now();
      const hours = durationHours || 72; // default 3 days (72 hours) so all teachers have time to join
      const expiresAt = now + (hours * 60 * 60 * 1000);
      const invite = {
        id: 'inv_' + Date.now().toString(36),
        token: token,
        schoolCode: schoolCode,
        role: role || 'teacher',
        classId: classId || '10-A',
        createdByName: createdByName || 'Direktor',
        isGroup: (isGroup !== false), // All teachers in group can use this single link
        usesCount: 0,
        usedBy: [],
        createdAt: new Date(now).toISOString(),
        expiresAt: new Date(expiresAt).toISOString(),
        expiresTimestamp: expiresAt,
        status: 'active'
      };
      const invites = getCollection(STORAGE_KEYS.INVITES);
      invites.unshift(invite);
      saveCollection(STORAGE_KEYS.INVITES, invites);
      return invite;
    },
    getInviteByToken: (token) => {
      if (!token) return null;
      const clean = token.trim().toUpperCase();
      const invites = getCollection(STORAGE_KEYS.INVITES);
      const inv = invites.find(i => i.token.toUpperCase() === clean);
      if (!inv) return null;
      if (inv.status === 'active' && Date.now() > inv.expiresTimestamp) {
        inv.status = 'expired';
        saveCollection(STORAGE_KEYS.INVITES, invites);
      }
      return inv;
    },
    getInvitesBySchool: (schoolCode) => {
      const invites = getCollection(STORAGE_KEYS.INVITES);
      const now = Date.now();
      let updated = false;
      invites.forEach(inv => {
        if (inv.status === 'active' && now > inv.expiresTimestamp) {
          inv.status = 'expired';
          updated = true;
        }
      });
      if (updated) saveCollection(STORAGE_KEYS.INVITES, invites);
      return invites.filter(i => i.schoolCode === schoolCode);
    },
    useInvite: (token, userSummary) => {
      const clean = (token || '').trim().toUpperCase();
      const invites = getCollection(STORAGE_KEYS.INVITES);
      const inv = invites.find(i => i.token.toUpperCase() === clean);
      if (inv) {
        inv.usesCount = (inv.usesCount || 0) + 1;
        if (!Array.isArray(inv.usedBy)) inv.usedBy = [];
        if (userSummary) inv.usedBy.push(userSummary);

        // Single-use link marks used; Group link stays active so all teachers in the chat can join!
        if (inv.isGroup === false) {
          inv.status = 'used';
        }
        inv.lastUsedAt = new Date().toISOString();
        saveCollection(STORAGE_KEYS.INVITES, invites);
      }
      return inv;
    },
    cancelInvite: (token) => {
      const clean = (token || '').trim().toUpperCase();
      const invites = getCollection(STORAGE_KEYS.INVITES);
      const inv = invites.find(i => i.token.toUpperCase() === clean);
      if (inv) {
        inv.status = 'cancelled';
        saveCollection(STORAGE_KEYS.INVITES, invites);
      }
      return inv;
    },

    // Session
    getSession: () => {
      try {
        const raw = localStorage.getItem(STORAGE_KEYS.SESSION);
        return raw ? JSON.parse(raw) : null;
      } catch (e) {
        return null;
      }
    },
    setSession: (session) => {
      if (!session) {
        localStorage.removeItem(STORAGE_KEYS.SESSION);
      } else {
        localStorage.setItem(STORAGE_KEYS.SESSION, JSON.stringify(session));
      }
    },
    clearSession: () => {
      localStorage.removeItem(STORAGE_KEYS.SESSION);
    },

    // Backup Dump & Restore
    dumpBackup: (schoolCode) => {
      return {
        version: "4.0",
        exportedAt: new Date().toISOString(),
        school: DB.getSchoolByCode(schoolCode),
        users: DB.getUsersBySchool(schoolCode),
        classes: DB.getClassesBySchool(schoolCode),
        students: DB.getAllStudentsBySchool(schoolCode),
        attendance: getCollection(STORAGE_KEYS.ATTENDANCE).filter(a => a.schoolCode === schoolCode),
        reports: DB.getReportsBySchool(schoolCode)
      };
    },
    restoreBackup: (payload) => {
      if (!payload || !payload.version || !payload.school || !payload.school.code) {
        throw new Error("Invalid backup schema");
      }
      const schoolCode = payload.school.code;

      // Merge school
      const schools = getCollection(STORAGE_KEYS.SCHOOLS).filter(s => s.code !== schoolCode);
      schools.push(payload.school);
      saveCollection(STORAGE_KEYS.SCHOOLS, schools);

      // Merge users
      const users = getCollection(STORAGE_KEYS.USERS).filter(u => u.schoolCode !== schoolCode);
      if (Array.isArray(payload.users)) {
        users.push(...payload.users);
      }
      saveCollection(STORAGE_KEYS.USERS, users);

      // Merge classes
      const classes = getCollection(STORAGE_KEYS.CLASSES).filter(c => c.schoolCode !== schoolCode);
      if (Array.isArray(payload.classes)) {
        classes.push(...payload.classes);
      }
      saveCollection(STORAGE_KEYS.CLASSES, classes);

      // Merge students
      const students = getCollection(STORAGE_KEYS.STUDENTS).filter(s => s.schoolCode !== schoolCode);
      if (Array.isArray(payload.students)) {
        students.push(...payload.students);
      }
      saveCollection(STORAGE_KEYS.STUDENTS, students);

      // Merge attendance
      const attendance = getCollection(STORAGE_KEYS.ATTENDANCE).filter(a => a.schoolCode !== schoolCode);
      if (Array.isArray(payload.attendance)) {
        attendance.push(...payload.attendance);
      }
      saveCollection(STORAGE_KEYS.ATTENDANCE, attendance);

      // Merge reports
      const reports = getCollection(STORAGE_KEYS.REPORTS).filter(r => r.schoolCode !== schoolCode);
      if (Array.isArray(payload.reports)) {
        reports.push(...payload.reports);
      }
      saveCollection(STORAGE_KEYS.REPORTS, reports);

      return true;
    }
  };
})();
