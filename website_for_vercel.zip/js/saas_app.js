/**
 * Uzbek Modern EdTech & School Enterprise Management System
 * Front-end controller interacting with FastAPI / REST v1 Backend
 */

const API_BASE = window.location.port === '8000' ? '/api/v1' : 'http://127.0.0.1:8000/api/v1';

const AppState = {
  token: localStorage.getItem('school_token') || null,
  user: null,
  school: null,
  activeRole: null,
  activeView: 'dashboard',
  currentClassId: null,
  currentClassName: '10-A',
  selectedDate: '2026-09-19',
  classes: [],
  students: [],
  sheetRecords: [],
  notifications: [],
  unreadNotifsCount: 0,
  auditLogs: [],
  stats: null
};

// ─── NOTIFICATION TOAST HELPER ───
function showToast(message, type = 'info') {
  const container = document.getElementById('toast-container') || createToastContainer();
  const toast = document.createElement('div');
  toast.className = `saas-toast ${type}`;
  toast.innerHTML = `
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
      ${type === 'success' 
        ? '<path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline>' 
        : '<circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line>'}
    </svg>
    <span>${message}</span>
  `;
  container.appendChild(toast);
  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(10px)';
    setTimeout(() => toast.remove(), 250);
  }, 3500);
}

function createToastContainer() {
  const c = document.createElement('div');
  c.id = 'toast-container';
  c.className = 'toast-container';
  document.body.appendChild(c);
  return c;
}

// ─── API CLIENT WRAPPER ───
async function apiRequest(endpoint, method = 'GET', data = null) {
  const headers = { 'Content-Type': 'application/json' };
  if (AppState.token) {
    headers['Authorization'] = `Bearer ${AppState.token}`;
  }

  const options = { method, headers };
  if (data && (method === 'POST' || method === 'PUT' || method === 'PATCH')) {
    options.body = JSON.stringify(data);
  }

  try {
    const res = await fetch(`${API_BASE}${endpoint}`, options);
    if (res.status === 401) {
      // Session expired or invalid
      console.warn('Unauthorized request - session cleared');
      return { ok: false, status: 401, error: 'Sessiya muddati tugadi. Iltimos qaytadan kiring.' };
    }
    const json = await res.json();
    return { ok: res.ok, status: res.status, data: json };
  } catch (err) {
    console.error('Network/API Error:', err);
    return { ok: false, status: 500, error: 'Server bilan aloqa uzildi: ' + err.message };
  }
}

// ─── AUTHENTICATION FLOW ───
async function loginWithCredentials(username, password) {
  const res = await apiRequest('/auth/login', 'POST', { username, password });
  if (!res.ok) {
    showToast(res.data?.detail || res.error || 'Kirishda xatolik yuz berdi', 'error');
    return false;
  }

  AppState.token = res.data.access_token;
  localStorage.setItem('school_token', AppState.token);
  AppState.user = res.data.user;
  AppState.school = res.data.school;
  AppState.activeRole = res.data.user.role;

  showToast(`Xush kelibsiz, ${AppState.user.first_name} ${AppState.user.last_name}!`, 'success');
  closeModal('auth-modal');
  updateHeaderProfile();
  renderRoleNavigation();
  loadInitialDataForRole();
  return true;
}

async function registerUser(payload) {
  const res = await apiRequest('/auth/register', 'POST', payload);
  if (!res.ok) {
    showToast(res.data?.detail || res.error || 'Ro\'yxatdan o\'tishda xatolik', 'error');
    return false;
  }
  showToast('Ro\'yxatdan muvaffaqiyatli o\'tdingiz! Tizimga kiring.', 'success');
  // Switch to login tab in modal
  switchAuthTab('login');
  document.getElementById('login-username').value = payload.email;
  document.getElementById('login-password').value = payload.password;
  return true;
}

async function redeemInvite(code) {
  const res = await apiRequest('/auth/accept-invite', 'POST', { token: code });
  if (!res.ok) {
    showToast(res.data?.detail || 'Taklifnoma kodi yaroqsiz yoki muddati tugagan', 'error');
    return false;
  }
  AppState.token = res.data.access_token;
  localStorage.setItem('school_token', AppState.token);
  AppState.user = res.data.user;
  AppState.school = res.data.school;
  AppState.activeRole = res.data.user.role;

  showToast(`Tabriklaymiz! Sizga ${AppState.activeRole} huquqi berildi!`, 'success');
  updateHeaderProfile();
  renderRoleNavigation();
  loadInitialDataForRole();
  return true;
}

function logout() {
  AppState.token = null;
  AppState.user = null;
  AppState.school = null;
  AppState.activeRole = null;
  localStorage.removeItem('school_token');
  showToast('Tizimdan chiqildi', 'info');
  openModal('auth-modal');
  updateHeaderProfile();
}

// ─── QUICK DEMO ROLE SWITCHER ───
async function quickLoginAs(roleKey) {
  const credentials = {
    'SUPER_ADMIN': ['admin', 'admin123'],
    'DIRECTOR': ['director', 'director123'],
    'TEACHER': ['teacher', 'teacher123'],
    'STAROSTA': ['amal', 'starosta123']
  };

  const cred = credentials[roleKey];
  if (!cred) return;

  // Highlight active button in topbar
  document.querySelectorAll('.role-switch-btn').forEach(b => b.classList.remove('active'));
  const activeBtn = document.querySelector(`.role-switch-btn[data-role="${roleKey}"]`);
  if (activeBtn) activeBtn.classList.add('active');

  await loginWithCredentials(cred[0], cred[1]);
}

// ─── UI CONTROLLER & RENDERING ───
function updateHeaderProfile() {
  const profileName = document.getElementById('header-user-name');
  const roleBadge = document.getElementById('header-role-badge');
  const schoolTitle = document.getElementById('header-school-name');
  const avatarEl = document.getElementById('header-user-avatar');

  if (AppState.user) {
    if (profileName) profileName.textContent = `${AppState.user.first_name} ${AppState.user.last_name}`;
    if (avatarEl) avatarEl.textContent = `${AppState.user.first_name[0]}${AppState.user.last_name[0]}`.toUpperCase();
    if (roleBadge) {
      roleBadge.textContent = AppState.user.role;
      roleBadge.className = `role-badge ${AppState.user.role.toLowerCase()}`;
    }
  } else {
    if (profileName) profileName.textContent = 'Mehmon';
    if (roleBadge) {
      roleBadge.textContent = 'KIRISH';
      roleBadge.className = 'role-badge user';
    }
  }

  if (AppState.school && schoolTitle) {
    schoolTitle.textContent = AppState.school.name;
  }
}

function renderRoleNavigation() {
  const navContainer = document.getElementById('sidebar-navigation-links');
  if (!navContainer) return;

  const role = AppState.activeRole;
  let items = [];

  if (role === 'SUPER_ADMIN') {
    items = [
      { id: 'admin-dashboard', icon: 'bar-chart-2', label: 'Boshqaruv paneli', active: true },
      { id: 'admin-schools', icon: 'home', label: 'Maktablar ro\'yxati' },
      { id: 'admin-users', icon: 'users', label: 'Foydalanuvchilar' },
      { id: 'admin-invites', icon: 'mail', label: 'Taklifnomalar' },
      { id: 'admin-audit', icon: 'shield', label: 'Audit jurnali' }
    ];
  } else if (role === 'DIRECTOR') {
    items = [
      { id: 'director-dashboard', icon: 'grid', label: 'Bosh sahifa (Bugun)', active: true },
      { id: 'director-classes', icon: 'layers', label: 'Sinf xonalari' },
      { id: 'director-students', icon: 'user-check', label: 'O\'quvchilar' },
      { id: 'director-assignments', icon: 'briefcase', label: 'O\'qituvchilar' },
      { id: 'director-attendance', icon: 'calendar', label: 'Davomat tekshirish' },
      { id: 'director-notifications', icon: 'bell', label: 'Bildirishnomalar' },
      { id: 'director-reports', icon: 'trending-up', label: 'Hisobotlar va grafik' }
    ];
  } else if (role === 'TEACHER' || role === 'CLASS_LEADER') {
    items = [
      { id: 'journal-view', icon: 'edit-3', label: 'Elektron jurnal', active: true },
      { id: 'teacher-classes', icon: 'users', label: 'Mening sinflarim' },
      { id: 'teacher-history', icon: 'clock', label: 'Davomat tarixi' }
    ];
  } else if (role === 'STAROSTA') {
    items = [
      { id: 'journal-view', icon: 'check-square', label: 'Sinf davomati (10-A)', active: true },
      { id: 'starosta-rules', icon: 'info', label: 'Yo\'riqnoma va huquqlar' }
    ];
  } else {
    items = [
      { id: 'user-home', icon: 'user', label: 'Shaxsiy kabinet', active: true },
      { id: 'user-redeem', icon: 'key', label: 'Taklifnoma kiritish' }
    ];
  }

  navContainer.innerHTML = items.map(item => `
    <li>
      <button class="nav-item-btn ${item.active ? 'active' : ''}" onclick="switchView('${item.id}', this)">
        <span class="nav-icon-slot">📌</span>
        <span>${item.label}</span>
      </button>
    </li>
  `).join('');
}

function switchView(viewId, btnEl) {
  if (btnEl) {
    document.querySelectorAll('.nav-item-btn').forEach(b => b.classList.remove('active'));
    btnEl.classList.add('active');
  }

  AppState.activeView = viewId;

  // Hide all view panels and show selected
  document.querySelectorAll('.saas-view-panel').forEach(p => p.style.display = 'none');
  const target = document.getElementById(`panel-${viewId}`);
  if (target) {
    target.style.display = 'block';
  }

  // Load specific data based on view
  if (viewId === 'director-dashboard') loadDirectorDashboard();
  if (viewId === 'director-classes') loadDirectorClasses();
  if (viewId === 'director-students') loadDirectorStudents();
  if (viewId === 'director-notifications') loadDirectorNotifications();
  if (viewId === 'journal-view') loadAttendanceSheet();
  if (viewId === 'admin-dashboard' || viewId === 'admin-schools') loadAdminDashboard();
  if (viewId === 'admin-users') loadAdminUsers();
  if (viewId === 'admin-audit') loadAdminAudit();
  if (viewId === 'admin-invites') loadAdminInvites();
}

async function loadInitialDataForRole() {
  if (AppState.activeRole === 'SUPER_ADMIN') {
    switchView('admin-dashboard');
  } else if (AppState.activeRole === 'DIRECTOR') {
    switchView('director-dashboard');
    fetchUnreadNotificationsCount();
  } else if (AppState.activeRole === 'TEACHER' || AppState.activeRole === 'CLASS_LEADER' || AppState.activeRole === 'STAROSTA') {
    switchView('journal-view');
  } else {
    switchView('user-home');
  }
}

// ─── DIRECTOR DASHBOARD LOGIC ───
async function loadDirectorDashboard() {
  const res = await apiRequest('/director/dashboard');
  if (!res.ok) return;

  const data = res.data;
  AppState.stats = data;

  // Update counters
  setMetric('metric-total-students', data.total_students);
  setMetric('metric-present', data.present_count);
  setMetric('metric-absent', data.absent_count);
  setMetric('metric-late', data.late_count);
  setMetric('metric-rate', `${data.attendance_rate_percent}%`);

  const fillEl = document.getElementById('metric-rate-bar');
  if (fillEl) fillEl.style.width = `${data.attendance_rate_percent}%`;

  // Also load and render class cards
  loadDirectorClasses();
}

function setMetric(id, val) {
  const el = document.getElementById(id);
  if (el) el.textContent = val;
}

async function loadDirectorClasses() {
  const res = await apiRequest('/director/classes');
  if (!res.ok) return;
  AppState.classes = res.data;

  const container = document.getElementById('director-classes-grid');
  if (!container) return;

  container.innerHTML = AppState.classes.map(c => `
    <div class="metric-card" style="cursor:pointer;" onclick="openClassJournal('${c.id}', '${c.name}')">
      <div class="metric-header">
        <span class="metric-label">Sinf</span>
        <div class="metric-icon-wrap" style="background:#EFF6FF; color:#1E5AA8;">🏫</div>
      </div>
      <div class="metric-value">${c.name}</div>
      <div class="metric-hint">
        <span>👥 ${c.students_count || 0} o'quvchi</span>
        <span>•</span>
        <span style="color:#059669; font-weight:700;">Jurnalni ochish ›</span>
      </div>
    </div>
  `).join('');

  // Populate class dropdown in journal view
  const selectEl = document.getElementById('journal-class-select');
  if (selectEl) {
    selectEl.innerHTML = AppState.classes.map(c => `<option value="${c.id}">${c.name}</option>`).join('');
    if (AppState.classes.length > 0 && !AppState.currentClassId) {
      AppState.currentClassId = AppState.classes[0].id;
      AppState.currentClassName = AppState.classes[0].name;
    }
  }
}

function openClassJournal(classId, className) {
  AppState.currentClassId = classId;
  AppState.currentClassName = className;
  const selectEl = document.getElementById('journal-class-select');
  if (selectEl) selectEl.value = classId;
  switchView('journal-view');
}

// ─── ATTENDANCE JOURNAL LOGIC ───
async function loadAttendanceSheet() {
  const classId = AppState.currentClassId || (AppState.classes[0]?.id);
  const date = AppState.selectedDate || '2026-09-19';

  let query = '';
  if (classId) {
    query = `?class_id=${classId}&date=${date}`;
  } else {
    query = `?class_name=${encodeURIComponent(AppState.currentClassName || '10-A')}&date=${date}`;
  }

  const res = await apiRequest(`/attendance/sheet${query}`);
  if (!res.ok) {
    showToast(res.data?.detail || 'Jurnal ma\'lumotlarini yuklab bo\'lmadi', 'error');
    return;
  }

  const sheetData = res.data;
  AppState.currentClassId = sheetData.class.id;
  AppState.currentClassName = sheetData.class.name;
  AppState.sheetRecords = sheetData.records;

  // Render submit button authorization status
  const submitBtn = document.getElementById('btn-submit-attendance');
  const permWarning = document.getElementById('journal-perm-notice');
  if (submitBtn) {
    if (sheetData.can_submit_attendance) {
      submitBtn.disabled = false;
      submitBtn.style.opacity = '1';
      if (permWarning) permWarning.style.display = 'none';
    } else {
      submitBtn.disabled = true;
      submitBtn.style.opacity = '0.5';
      if (permWarning) {
        permWarning.style.display = 'block';
        permWarning.textContent = '⚠️ Sizda bu sinf davomatini direktorga jo\'natish huquqi yo\'q.';
      }
    }
  }

  renderAttendanceTable();
}

function renderAttendanceTable() {
  const tbody = document.getElementById('attendance-table-body');
  if (!tbody) return;

  if (AppState.sheetRecords.length === 0) {
    tbody.innerHTML = `<tr><td colspan="5" style="text-align:center; padding:2rem; color:#64748B;">Ushbu sinfda hozircha faol o'quvchilar yo'q.</td></tr>`;
    return;
  }

  tbody.innerHTML = AppState.sheetRecords.map((r, idx) => {
    const isAbsent = r.status === 'ABSENT';
    const isLate = r.status === 'LATE';

    return `
      <tr data-student-id="${r.student_id}">
        <td style="width:40px; text-align:center; color:#94A3B8; font-weight:700;">${idx + 1}</td>
        <td>
          <div class="student-row-info">
            <div class="student-avatar">${r.first_name[0]}${r.last_name[0]}</div>
            <div>
              <div class="student-name-text">${r.last_name} ${r.first_name}</div>
              <div class="student-phone-sub">${r.phone || 'Telefon kiritilmagan'}</div>
            </div>
          </div>
        </td>
        <td>
          <div class="status-pill-group">
            <button type="button" class="status-btn ${r.status === 'PRESENT' ? 'active-present' : ''}" onclick="setRowStatus('${r.student_id}', 'PRESENT')">
              ✓ Hozir
            </button>
            <button type="button" class="status-btn ${r.status === 'ABSENT' ? 'active-absent' : ''}" onclick="setRowStatus('${r.student_id}', 'ABSENT')">
              ✗ Qatnashmadi
            </button>
            <button type="button" class="status-btn ${r.status === 'LATE' ? 'active-late' : ''}" onclick="setRowStatus('${r.student_id}', 'LATE')">
              ⏱ Kechikdi
            </button>
            <button type="button" class="status-btn ${r.status === 'EXCUSED' ? 'active-excused' : ''}" onclick="setRowStatus('${r.student_id}', 'EXCUSED')">
              📄 Sababli
            </button>
          </div>
        </td>
        <td>
          ${isAbsent ? `
            <select class="reason-select-inline" onchange="setRowReasonCategory('${r.student_id}', this.value)">
              <option value="Болезнь" ${r.reason_category === 'Болезнь' ? 'selected' : ''}>Kasal (Болезнь)</option>
              <option value="Семейные обстоятельства" ${r.reason_category === 'Семейные обстоятельства' ? 'selected' : ''}>Oilaviy sharoit</option>
              <option value="Разрешение администрации" ${r.reason_category === 'Разрешение администрации' ? 'selected' : ''}>Ma'muriyat ruxsati</option>
              <option value="Соревнования" ${r.reason_category === 'Соревнования' ? 'selected' : ''}>Musobaqa / Olimpiada</option>
              <option value="Другая причина" ${r.reason_category === 'Другая причина' ? 'selected' : ''}>Boshqa sabab</option>
            </select>
          ` : isLate ? `
            <div style="display:flex; align-items:center; gap:0.4rem;">
              <input type="number" min="1" max="120" class="late-input-inline" value="${r.late_minutes || 10}" onchange="setRowLateMinutes('${r.student_id}', this.value)">
              <span style="font-size:0.75rem; color:#92400E; font-weight:700;">daq</span>
            </div>
          ` : `<span style="color:#94A3B8; font-size:0.8rem;">—</span>`}
        </td>
        <td>
          <input type="text" placeholder="Izoh..." value="${r.reason_text || ''}" class="form-input-saas" style="padding:0.35rem 0.6rem; font-size:0.8rem; width:100%;" onchange="setRowComment('${r.student_id}', this.value)">
        </td>
      </tr>
    `;
  }).join('');
}

function setRowStatus(studentId, newStatus) {
  const item = AppState.sheetRecords.find(x => x.student_id === studentId);
  if (!item) return;
  item.status = newStatus;
  if (newStatus === 'ABSENT' && !item.reason_category) item.reason_category = 'Болезнь';
  if (newStatus === 'LATE' && !item.late_minutes) item.late_minutes = 10;
  renderAttendanceTable();
}

function setRowReasonCategory(studentId, cat) {
  const item = AppState.sheetRecords.find(x => x.student_id === studentId);
  if (item) item.reason_category = cat;
}

function setRowLateMinutes(studentId, mins) {
  const item = AppState.sheetRecords.find(x => x.student_id === studentId);
  if (item) item.late_minutes = parseInt(mins, 10) || 0;
}

function setRowComment(studentId, comment) {
  const item = AppState.sheetRecords.find(x => x.student_id === studentId);
  if (item) item.reason_text = comment;
}

function markAllPresent() {
  AppState.sheetRecords.forEach(r => {
    r.status = 'PRESENT';
    r.reason_category = null;
    r.late_minutes = null;
  });
  renderAttendanceTable();
  showToast('Barcha o\'quvchilar hozir deb belgilandi!', 'info');
}

async function submitAttendanceBatch() {
  const btn = document.getElementById('btn-submit-attendance');
  if (btn) {
    btn.disabled = true;
    btn.textContent = 'Jo\'natilmoqda...';
  }

  const payload = {
    class_id: AppState.currentClassId,
    date: AppState.selectedDate || '2026-09-19',
    records: AppState.sheetRecords.map(r => ({
      student_id: r.student_id,
      status: r.status,
      reason_category: r.status === 'ABSENT' ? (r.reason_category || 'Болезнь') : null,
      reason_text: r.reason_text || null,
      late_minutes: r.status === 'LATE' ? (r.late_minutes || 10) : null
    }))
  };

  const res = await apiRequest('/attendance/submit', 'POST', payload);
  if (btn) {
    btn.disabled = false;
    btn.textContent = '🚀 Direktorga jo\'natish';
  }

  if (!res.ok) {
    showToast(res.data?.detail || 'Davomatni jo\'natishda xatolik', 'error');
    return;
  }

  showToast(`Muvaffaqiyatli! Sinf (${AppState.currentClassName}) davomati direktorga yetkazildi.`, 'success');
  // Refresh notifications count if director
  fetchUnreadNotificationsCount();
}

// ─── DIRECTOR NOTIFICATIONS LOGIC ───
async function fetchUnreadNotificationsCount() {
  if (AppState.activeRole !== 'DIRECTOR') return;
  const res = await apiRequest('/director/notifications');
  if (res.ok) {
    AppState.notifications = res.data;
    const unread = res.data.filter(n => !n.is_read).length;
    AppState.unreadNotifsCount = unread;
    const badge = document.getElementById('notif-badge-counter');
    if (badge) {
      badge.textContent = unread;
      badge.style.display = unread > 0 ? 'flex' : 'none';
    }
  }
}

async function loadDirectorNotifications() {
  const res = await apiRequest('/director/notifications');
  if (!res.ok) return;

  AppState.notifications = res.data;
  const listContainer = document.getElementById('director-notifications-list');
  if (!listContainer) return;

  if (AppState.notifications.length === 0) {
    listContainer.innerHTML = `<div style="text-align:center; padding:2rem; color:#64748B;">Hozircha yangi bildirishnomalar yo'q.</div>`;
    return;
  }

  listContainer.innerHTML = AppState.notifications.map(n => `
    <div class="panel-card" style="margin-bottom:0.75rem; border-left: 4px solid ${n.is_read ? '#CBD5E1' : '#1E5AA8'};">
      <div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:0.35rem;">
        <h4 style="font-size:0.95rem; font-weight:800; color:#0F172A;">${n.title}</h4>
        <span style="font-size:0.75rem; color:#94A3B8;">${new Date(n.created_at).toLocaleTimeString('uz-UZ', {hour:'2-digit', minute:'2-digit'})}</span>
      </div>
      <p style="font-size:0.875rem; color:#475569; margin-bottom:0.5rem;">${n.message}</p>
      <div style="display:flex; gap:0.5rem;">
        <button class="btn-saas btn-saas-secondary" style="padding:0.3rem 0.65rem; font-size:0.75rem;" onclick="markNotificationAsRead('${n.id}')">
          ✓ O'qilgan deb belgilash
        </button>
      </div>
    </div>
  `).join('');
}

async function markNotificationAsRead(notifId) {
  await apiRequest(`/director/notifications/${notifId}/read`, 'PATCH');
  fetchUnreadNotificationsCount();
  loadDirectorNotifications();
}

// ─── SUPERADMIN LOGIC ───
async function loadAdminDashboard() {
  const res = await apiRequest('/admin/dashboard');
  if (!res.ok) return;
  const data = res.data;

  setMetric('admin-metric-schools', data.total_schools);
  setMetric('admin-metric-directors', data.total_directors);
  setMetric('admin-metric-teachers', data.total_teachers);
  setMetric('admin-metric-users', data.total_users);

  // Load schools list
  const schoolsRes = await apiRequest('/admin/schools');
  if (schoolsRes.ok) {
    const listEl = document.getElementById('admin-schools-table-body');
    if (listEl) {
      listEl.innerHTML = schoolsRes.data.map(s => `
        <tr>
          <td style="font-weight:700;">${s.name}</td>
          <td><code style="background:#F1F5F9; padding:2px 6px; border-radius:4px;">${s.code}</code></td>
          <td>${s.address || '—'}</td>
          <td>${s.phone || '—'}</td>
          <td><span class="role-badge" style="background:#ECFDF5; color:#047857;">FAOL</span></td>
        </tr>
      `).join('');
    }
  }
}

async function loadAdminUsers() {
  const res = await apiRequest('/admin/users');
  if (!res.ok) return;

  const tbody = document.getElementById('admin-users-table-body');
  if (!tbody) return;

  tbody.innerHTML = res.data.map(u => `
    <tr>
      <td style="font-weight:700;">${u.last_name} ${u.first_name}</td>
      <td>${u.email}</td>
      <td><span class="role-badge ${u.role.toLowerCase()}">${u.role}</span></td>
      <td>
        <span class="role-badge" style="background:${u.is_active ? '#ECFDF5' : '#FEE2E2'}; color:${u.is_active ? '#047857' : '#DC2626'};">
          ${u.is_active ? 'Aktiv' : 'Bloklangan'}
        </span>
      </td>
      <td>
        <button class="btn-saas btn-saas-secondary" style="padding:0.25rem 0.5rem; font-size:0.75rem;" onclick="toggleUserActive('${u.id}', ${!u.is_active})">
          ${u.is_active ? 'Bloklash' : 'Faollashtirish'}
        </button>
      </td>
    </tr>
  `).join('');
}

async function toggleUserActive(userId, makeActive) {
  const res = await apiRequest(`/admin/users/${userId}/status?is_active=${makeActive}`, 'PUT');
  if (res.ok) {
    showToast('Foydalanuvchi holati yangilandi!', 'success');
    loadAdminUsers();
  }
}

async function loadAdminAudit() {
  const res = await apiRequest('/admin/audit-logs');
  if (!res.ok) return;

  const tbody = document.getElementById('admin-audit-table-body');
  if (!tbody) return;

  tbody.innerHTML = res.data.map(log => `
    <tr>
      <td style="font-size:0.8rem; color:#64748B;">${new Date(log.created_at).toLocaleString('uz-UZ')}</td>
      <td style="font-weight:700; color:#1E5AA8;">${log.action}</td>
      <td>${log.entity_name} (${log.entity_id ? log.entity_id.substring(0, 8) : '—'})</td>
      <td><code>${log.ip_address || '127.0.0.1'}</code></td>
    </tr>
  `).join('');
}

async function loadAdminInvites() {
  const res = await apiRequest('/admin/invitations');
  if (!res.ok) return;

  const tbody = document.getElementById('admin-invites-table-body');
  if (!tbody) return;

  tbody.innerHTML = res.data.map(inv => `
    <tr>
      <td><code style="font-weight:800; color:#059669; background:#ECFDF5; padding:3px 8px; border-radius:4px;">${inv.token}</code></td>
      <td><span class="role-badge ${inv.role.toLowerCase()}">${inv.role}</span></td>
      <td>${inv.is_used ? '<span style="color:#DC2626; font-weight:700;">Ishlatilgan</span>' : '<span style="color:#059669; font-weight:700;">Faol</span>'}</td>
      <td>
        <button class="btn-saas btn-saas-secondary" style="padding:0.25rem 0.5rem; font-size:0.75rem;" onclick="copyToClipboard('${inv.token}')">
          Nusxalash
        </button>
      </td>
    </tr>
  `).join('');
}

function copyToClipboard(text) {
  navigator.clipboard.writeText(text);
  showToast(`Taklif kodi nusxalandi: ${text}`, 'success');
}

// ─── MODAL CONTROLLERS ───
function openModal(id) {
  const modal = document.getElementById(id);
  if (modal) modal.classList.add('open');
}

function closeModal(id) {
  const modal = document.getElementById(id);
  if (modal) modal.classList.remove('open');
}

function switchAuthTab(tab) {
  document.getElementById('auth-login-form').style.display = tab === 'login' ? 'flex' : 'none';
  document.getElementById('auth-register-form').style.display = tab === 'register' ? 'flex' : 'none';
  document.getElementById('tab-btn-login').classList.toggle('active', tab === 'login');
  document.getElementById('tab-btn-register').classList.toggle('active', tab === 'register');
}

// ─── INITIALIZATION ON PAGE LOAD ───
window.addEventListener('DOMContentLoaded', async () => {
  // Check existing token
  if (AppState.token) {
    const res = await apiRequest('/auth/me');
    if (res.ok) {
      AppState.user = res.data.user;
      AppState.school = res.data.school;
      AppState.activeRole = res.data.user.role;
      updateHeaderProfile();
      renderRoleNavigation();
      loadInitialDataForRole();
    } else {
      // Default to Director demo
      quickLoginAs('DIRECTOR');
    }
  } else {
    // Automatically login as Director for instant preview
    quickLoginAs('DIRECTOR');
  }

  // Bind date picker changes
  const dateInput = document.getElementById('journal-date-picker');
  if (dateInput) {
    dateInput.value = AppState.selectedDate;
    dateInput.addEventListener('change', (e) => {
      AppState.selectedDate = e.target.value;
      loadAttendanceSheet();
    });
  }

  // Bind class select change
  const classSelect = document.getElementById('journal-class-select');
  if (classSelect) {
    classSelect.addEventListener('change', (e) => {
      AppState.currentClassId = e.target.value;
      const opt = classSelect.options[classSelect.selectedIndex];
      AppState.currentClassName = opt ? opt.text : '10-A';
      loadAttendanceSheet();
    });
  }
});
