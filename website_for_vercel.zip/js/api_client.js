/**
 * Enterprise School Attendance System — Frontend API v1 Client
 * Strictly typed contracts matching backend REST API v1.
 */

const ApiClient = (function () {
  const BASE_URL = '/api/v1';
  const TOKEN_KEY = 'jurnal_v1_jwt_token';
  const USER_KEY = 'jurnal_v1_user';
  const SCHOOL_KEY = 'jurnal_v1_school';

  function getToken() {
    return localStorage.getItem(TOKEN_KEY) || '';
  }

  function setSession(data) {
    if (data.access_token) {
      localStorage.setItem(TOKEN_KEY, data.access_token);
    }
    if (data.user) {
      localStorage.setItem(USER_KEY, JSON.stringify(data.user));
    }
    if (data.school) {
      localStorage.setItem(SCHOOL_KEY, JSON.stringify(data.school));
    }
  }

  function clearSession() {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(USER_KEY);
    localStorage.removeItem(SCHOOL_KEY);
  }

  function getUser() {
    try {
      const u = localStorage.getItem(USER_KEY);
      return u ? JSON.parse(u) : null;
    } catch (e) {
      return null;
    }
  }

  function getSchool() {
    try {
      const s = localStorage.getItem(SCHOOL_KEY);
      return s ? JSON.parse(s) : null;
    } catch (e) {
      return null;
    }
  }

  function getRole() {
    const u = getUser();
    return u ? u.role : null;
  }

  async function request(endpoint, options = {}) {
    const url = `${BASE_URL}${endpoint}`;
    const headers = {
      'Content-Type': 'application/json',
      ...(options.headers || {})
    };

    const token = getToken();
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }

    const config = {
      method: options.method || 'GET',
      headers,
      ...options
    };

    if (options.body && typeof options.body === 'object') {
      config.body = JSON.stringify(options.body);
    }

    const res = await fetch(url, config);
    const contentType = res.headers.get('content-type') || '';
    let responseData = null;
    if (contentType.includes('application/json')) {
      responseData = await res.json();
    } else {
      responseData = await res.text();
    }

    if (!res.ok) {
      const err = new Error(
        (responseData && responseData.message) ||
        (responseData && responseData.error) ||
        `HTTP Error ${res.status}`
      );
      err.status = res.status;
      err.data = responseData;
      throw err;
    }

    return responseData;
  }

  return {
    getToken,
    getUser,
    getSchool,
    getRole,
    setSession,
    clearSession,

    // ─── AUTHENTICATION & INVITES ───
    auth: {
      async register({ first_name, last_name, middle_name, email, phone, username, password }) {
        return request('/auth/register', {
          method: 'POST',
          body: { first_name, last_name, middle_name, email, phone, username, password }
        });
      },

      async login({ identifier, username, email, password }) {
        const data = await request('/auth/login', {
          method: 'POST',
          body: { identifier: identifier || username || email, password }
        });
        setSession(data);
        return data;
      },

      async getMe() {
        const data = await request('/auth/me');
        if (data.user) {
          localStorage.setItem(USER_KEY, JSON.stringify(data.user));
        }
        if (data.school) {
          localStorage.setItem(SCHOOL_KEY, JSON.stringify(data.school));
        }
        return data;
      },

      async acceptInvite(token) {
        const data = await request('/auth/accept-invite', {
          method: 'POST',
          body: { token }
        });
        setSession(data);
        return data;
      },

      logout() {
        clearSession();
      }
    },

    // ─── SUPER ADMIN API ───
    admin: {
      async getDashboard() {
        return request('/admin/dashboard');
      },

      async getSchools() {
        return request('/admin/schools');
      },

      async createSchool({ name, address, phone }) {
        return request('/admin/schools', {
          method: 'POST',
          body: { name, address, phone }
        });
      },

      async createDirectorInvite({ school_id, role = 'DIRECTOR', expires_in_hours = 72 }) {
        return request('/admin/invitations', {
          method: 'POST',
          body: { school_id, role, expires_in_hours }
        });
      },

      async getUsers() {
        return request('/admin/users');
      },

      async updateUserStatus(userId, is_active) {
        return request(`/admin/users/${userId}/status`, {
          method: 'PATCH',
          body: { is_active }
        });
      },

      async getAuditLogs() {
        return request('/admin/audit-logs');
      }
    },

    // ─── DIRECTOR API ───
    director: {
      async getDashboard(date) {
        const q = date ? `?date=${encodeURIComponent(date)}` : '';
        return request(`/director/dashboard${q}`);
      },

      async getClasses() {
        return request('/director/classes');
      },

      async createClass({ name, academic_year = '2026-2027' }) {
        return request('/director/classes', {
          method: 'POST',
          body: { name, academic_year }
        });
      },

      async getClassStudents(classId) {
        return request(`/director/classes/${classId}/students`);
      },

      async createStudent({ class_id, first_name, last_name, middle_name, birth_date, phone }) {
        return request('/director/students', {
          method: 'POST',
          body: { class_id, first_name, last_name, middle_name, birth_date, phone }
        });
      },

      async createStudentsBulk(class_id, students_bulk) {
        return request('/director/students', {
          method: 'POST',
          body: { class_id, students_bulk }
        });
      },

      async createMemberInvite({ role = 'TEACHER', class_id = null, expires_in_hours = 72 }) {
        return request('/director/invitations', {
          method: 'POST',
          body: { role, class_id, expires_in_hours }
        });
      },

      async assignMember({ class_id, user_id, role_in_class, can_submit_attendance = true }) {
        return request('/director/assignments', {
          method: 'POST',
          body: { class_id, user_id, role_in_class, can_submit_attendance }
        });
      },

      async getAttendance(date, classId) {
        const params = new URLSearchParams();
        if (date) params.set('date', date);
        if (classId) params.set('class_id', classId);
        const q = params.toString() ? `?${params.toString()}` : '';
        return request(`/director/attendance${q}`);
      },

      async getNotifications() {
        return request('/director/notifications');
      },

      async markNotificationRead(id) {
        return request(`/director/notifications/${id}/read`, {
          method: 'PATCH'
        });
      }
    },

    // ─── ATTENDANCE JOURNAL API ───
    attendance: {
      async getMyClasses() {
        return request('/attendance/my-classes');
      },

      async getSheet(classId, date) {
        const params = new URLSearchParams();
        if (classId) params.set('class_id', classId);
        if (date) params.set('date', date);
        return request(`/attendance/sheet?${params.toString()}`);
      },

      async submit({ class_id, date, records }) {
        return request('/attendance/submit', {
          method: 'POST',
          body: { class_id, date, records }
        });
      }
    }
  };
})();

// Global browser window export
if (typeof window !== 'undefined') {
  window.ApiClient = ApiClient;
}
