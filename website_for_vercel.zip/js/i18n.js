/**
 * 14-Maktab / Jurnal - Internationalization (i18n)
 * Clean, consistent translations for Uzbek and Russian.
 */

const I18N = {
  uz: {
    appTitle: "14-maktab — Davomat Jurnali",
    appSubtitle: "Yagona maktab boshqaruvi va elektron davomat tizimi",
    langName: "O'zbekcha",
    
    // Auth & Landing
    tabLogin: "Tizimga kirish",
    tabRegister: "Ro'yxatdan o'tish",
    tabRegisterSchool: "Yangi maktabni ro'yxatdan o'tkazish",
    tabJoinSchool: "Maktabga ulanish",
    emptyClassesTitle: "Hozircha birorta sinf qo'shilmagan",
    emptyClassesDesc: "Maktab o'quvchilari va davomatini yuritish uchun yangi sinf qo'shing.",
    
    // School Registration
    lblRegSchoolTitle: "Maktabni ro'yxatdan o'tkazish",
    lblRegSchoolSub: "Maktab direktori tomonidan to'ldiriladi",
    lblRegion: "Viloyat / Hudud:",
    lblCity: "Shahar yoki Tuman:",
    lblSchoolNumber: "Maktab raqami:",
    lblSchoolFullName: "Maktab to'liq rasmiy nomi:",
    lblDirectorName: "Direktor F.I.O (Ism va Familiya):",
    lblDirectorPhone: "Direktor telefon raqami:",
    lblDirectorEmail: "Direktor emaili (Gmail):",
    lblPassword: "Maxfiy parol:",
    lblPasswordConfirm: "Parolni tasdiqlang:",
    btnCreateSchool: "🏫 Maktabni yaratish va kod olish",
    
    // School Code Generated
    lblCodeSuccessTitle: "Maktab muvaffaqiyatli ro'yxatdan o'tdi!",
    lblCodeSuccessDesc: "Quyidagi maxsus kod orqali o'qituvchi va sardorlar ushbu maktabga ulanadi. Uni saqlab oling:",
    btnCopyCode: "📋 Maktab kodini nusxalash",
    btnEnterDirectorPanel: "👔 Direktor paneliga kirish",
    
    // Join School
    lblJoinTitle: "Mavjud maktabga ulanish",
    lblJoinSub: "Direktor bergan maktab kodini kiriting",
    lblSchoolCode: "Maktab maxsus kodi:",
    lblChooseRole: "Sizning rolingiz:",
    roleTeacher: "O'qituvchi (Sinf rahbari)",
    roleStarosta: "Sinf sardori",
    roleDirector: "Maktab direktori",
    lblFullName: "Ism va Familiyangiz:",
    lblPhone: "Telefon raqamingiz:",
    lblEmail: "Email (Gmail):",
    lblSelectClass: "Biriktirilgan sinf:",
    btnSendJoinRequest: "📩 A'zo bo'lish arizasini yuborish",
    lblPendingApproval: "Arizangiz direktorga yuborildi. Direktor tasdiqlagach, tizimga kira olasiz.",
    
    // Login
    lblLoginTitle: "Tizimga kirish",
    lblLoginSub: "Maktab kodi, email/telefon va parolingizni kiriting",
    lblLoginIdentifier: "Email yoki telefon raqam:",
    btnLogin: "TIZIMGA KIRISH",
    lblQuickLogin: "Tezkor sinov uchun kirish:",
    
    // Director Dashboard
    navMySchool: "🏫 Maktabim",
    navTeachers: "👨‍🏫 O'qituvchilar",
    navClasses: "📚 Sinflar",
    navStudents: "👨‍🎓 O'quvchilar",
    navReports: "📈 Hisobotlar",
    navSettings: "⚙️ Sozlamalar",
    btnLogout: "Chiqish",
    
    // Stats
    lblTodayStats: "Bugungi maktab davomati",
    lblTotalStudents: "Jami o'quvchilar",
    lblPresentCount: "Darsda (Keldi)",
    lblAbsentCount: "Kelmadi (Sababsiz)",
    lblExcusedCount: "Sababli kelmagan",
    lblLateCount: "Kechikkanlar",
    lblAttendanceRate: "Davomat ko'rsatkichi",
    
    // Classes hierarchy
    lblClassesHierarchy: "Maktab sinflari (11-sinfdan 1-sinfgacha):",
    lblSelectGrade: "Sinf darajasini tanlang:",
    lblSelectLetter: "Sinf harfini tanlang:",
    gradeSuffix: "-sinf",
    classCardTeacher: "Sinf rahbari",
    classCardStarosta: "Sardor",
    classCardStudents: "O'quvchilar",
    btnOpenJournal: "📖 Jurnalni ochish",
    btnClassStudents: "👥 O'quvchilar",
    btnClassStats: "📊 Statistika",
    btnAddClass: "➕ Yangi sinf qo'shish",
    
    // Teacher Approval Queue
    lblPendingRequests: "Tasdiqlash kutilayotgan arizalar",
    lblNoPendingRequests: "Yangi arizalar mavjud emas",
    btnApprove: "✅ Qabul qilish",
    btnReject: "❌ Rad etish",
    
    // Journal View
    lblClassJournal: "Sinf Jurnali",
    btnMarkAllPresent: "✅ HAMMASI KELDI",
    btnAddStudent: "➕ Yangi o'quvchi",
    searchPlaceholder: "Familiya bo'yicha qidirish...",
    statusPresent: "Darsda",
    statusAbsent: "Kelmadi",
    statusExcused: "Sababli",
    statusLate: "Kechikdi",
    btnCallParent: "Qo'ng'iroq",
    btnSendReport: "📤 Direktorga yuborish",
    btnShareTelegram: "✈️ Telegramda ulashish",
    
    // Student Form
    modalAddStudentTitle: "Yangi o'quvchi qo'shish",
    lblStudentLast: "Familiya:",
    lblStudentFirst: "Ism:",
    lblStudentPhone: "Ota-ona telefoni:",
    btnSave: "Saqlash",
    btnCancel: "Bekor qilish",
    btnDelete: "O'chirish",
    
    // Reasons
    modalReasonTitle: "Dars qoldirish sababi",
    reasonsList: [
      "Kasallik (shifokor ma'lumotnomasi)",
      "Oilaviy sharoit (sababli)",
      "Ota-ona arizasi / xati",
      "Olimpiada / Musobaqa",
      "Sababsiz (dars qoldirish)"
    ],
    lblReasonNote: "Qo'shimcha izoh:",
    
    // Backup & Restore
    lblBackupTitle: "Zaxira nusxalari va Ma'lumotlarni eksport/import qilish",
    btnExportData: "💾 Zaxira nusxasini yuklab olish (JSON)",
    btnImportData: "📥 Zaxiradan tiklash (JSON)",
    
    // Messages & Alerts
    errFillAllFields: "Iltimos, barcha majburiy maydonlarni to'ldiring!",
    errInvalidEmail: "Email manzili noto'g'ri kiritildi!",
    errInvalidPhone: "Telefon raqami noto'g'ri kiritildi!",
    errPasswordMismatch: "Kiritilgan parollar bir-biriga mos kelmadi!",
    errPasswordTooShort: "Parol kamida 6 ta belgidan iborat bo'lishi kerak!",
    errSchoolNotFound: "Bunday kodli maktab topilmadi. Kodni qayta tekshiring!",
    errLoginFailed: "Telefon/Email yoki parol noto'g'ri!",
    errAccountPending: "Arizangiz hali direktor tomonidan tasdiqlanmagan.",
    errDuplicateStudent: "Ushbu ism va familiyadagi o'quvchi bu sinfda allaqachon mavjud!",
    errInvalidBackupFile: "Zaxira fayli yaroqsiz yoki mos emas!",
    toastSaved: "Muvaffaqiyatli saqlandi!",
    toastReportSent: "Hisobot yuborildi!",
    toastStudentAdded: "O'quvchi qo'shildi!",
    toastStudentDeleted: "O'quvchi o'chirildi!",
    toastApproved: "Foydalanuvchi qabul qilindi!",
    toastRejected: "Ariza bekor qilindi!",
    confirmDeleteStudent: "Haqiqatan ham ushbu o'quvchini sinfdan o'chirmoqchimisiz?",
    
    // Invites & Links
    btnInviteMember: "🔗 Taklif havolasi yaratish",
    btnInviteCodePrompt: "🔗 Taklif kodi orqali a'zo bo'lish",
    modalCreateInviteTitle: "Yangi taklif havolasi yaratish",
    lblInviteRole: "Kimni taklif qilmoqchisiz?",
    lblInviteClass: "Sinf (Sinf sardori uchun):",
    btnGenerateInvite: "✨ Havolani yaratish",
    lblGeneratedLink: "Yaratilgan havola (24 soat amal qiladi):",
    btnCopyLink: "📋 Havoladan nusxa olish",
    btnSendToTelegram: "✈️ Telegram orqali yuborish",
    lblActiveInvites: "Faol taklif havolalari",
    lblNoActiveInvites: "Hozircha faol takliflar yo'q",
    btnCancelInvite: "Bekor qilish",
    lblInviteValid24h: "⏱ 24 soat amal qiladi • Bir martalik",
    lblInviteUsed: "Ishlatilgan",
    lblInviteExpired: "Muddati o'tgan",
    lblInviteCancelled: "Bekor qilingan",
    lblInviteActive: "Faol",
    inviteWelcomeTitle: "Maktabga taklifnoma",
    inviteInvitedBy: "Sizni maktab direktori taklif qildi",
    btnJoinViaInvite: "Akkount yaratish va qo'shilish",
    errInviteInvalid: "Ushbu taklif havolasi yaroqsiz yoki eskirgan!",
    errInviteAlreadyUsed: "Ushbu havola allaqachon ishlatilgan!",
    errInviteExpiredMsg: "Ushbu taklifnomaning 24 soatlik amal qilish muddati tugagan!",
    errInviteCancelledMsg: "Ushbu taklifnoma direktor tomonidan bekor qilingan!",
    toastInviteCreated: "Taklif havolasi yaratildi!",
    toastInviteCopied: "Havola nusxalandi!",
    toastInviteCancelled: "Taklifnoma bekor qilindi!",
    toastInviteSubmitted: "Arizangiz yuborildi! Direktor tasdiqlashi kutilmoqda.",
    lblInviteType: "Taklif turi:",
    optTeacherGroup: "👥 O'qituvchilar guruhi uchun umumiy havola (Barcha o'qituvchilar bitta havola bilan ulanadi)",
    optStarosta: "🎓 Sinf sardori uchun havola",
    optTeacherSingle: "👨‍🏫 Bitta o'qituvchi uchun shaxsiy havola",
    lblInviteDuration: "Amal qilish muddati:",
    optDuration3d: "3 kun (72 soat) — Tavsiya etiladi",
    optDuration7d: "7 kun (1 hafta)",
    optDuration24h: "24 soat (1 kun)",
    lblGroupNotice: "Ushbu havolani o'qituvchilarning Telegram guruhiga tashlasangiz, guruhdagi barcha o'qituvchilar a'zo bo'la oladi. Direktor har birini o'zi [Qabul qilish] orqali tasdiqlaydi.",
    lblJoinedCount: "nafar a'zo bo'ldi",

    // Settings & Profile
    modalSettingsTitle: "Sozlamalar va Profil",
    lblUserProfile: "Foydalanuvchi profili",
    lblAppLanguage: "Ilova tili:",
    btnCopyMyCredentials: "📋 Kirish ma'lumotlarimni nusxalash",
    toastCredentialsCopied: "Kirish ma'lumotlari nusxalandi!",
    btnLogoutConfirm: "Haqiqatan ham hisobingizdan chiqmoqchimisiz?",
    btnLogoutFromAccount: "🚪 Akkauntdan chiqish (Chiqish)",
    btnLogoutDesc: "Chiqish faqat ushbu sozlamalar orqali amalga oshiriladi",
    lblSchoolDetails: "Maktab ma'lumotlari",
    btnCopySchoolCode: "📋 Maktab kodini nusxalash",
    toastCodeCopied: "Maktab kodi nusxalandi!",

    // iOS Bottom Navigation & Windows
    tabNavHome: "Bosh sahifa",
    tabNavClasses: "Sinflar",
    tabNavJournal: "Jurnal",
    tabNavTeachers: "O'qituvchilar",
    tabNavSettings: "Sozlamalar",
    titleTeachersWindow: "Maktab O'qituvchilari va Arizalar",
    titleSettingsWindow: "Maktab Sozlamalari va Baza",
    btnEditProfile: "Ma'lumotlarni tahrirlash",
    btnSaveProfile: "O'zgarishlarni saqlash",
    toastProfileSaved: "Profil ma'lumotlari muvaffaqiyatli saqlandi!",
    lblActiveTeachers: "Faol o'qituvchilar ro'yxati",
    lblNoTeachers: "Hozircha biriktirilgan o'qituvchilar mavjud emas",
    modalDirectorTitle: "Direktor sifatida kirish yoki ro'yxatdan o'tish",
    btnSaveAndEnter: "💾 Saqlash va Kirish",
    btnTopSave: "💾 Saqlash",
    modalSavedTitle: "Ro'yxatdan o'tish saqlandi!",
    msgAccountSavedDesc: "Sizning login va parolingiz saqlandi. Endi ushbu ma'lumotlar bilan tizimga kirishingiz mumkin:",

    // Interactive Questionnaire Registration
    stepRole: "1. Kim siz? (Rolni tanlang)",
    stepSchool: "2. Qaysi maktab va shahar?",
    stepPersonal: "3. Shaxsiy ma'lumotlar",
    stepPassword: "4. Maxfiy parol",
    stepVerify: "5. Gmail orqali tasdiqlash",
    btnNextStep: "Keyingisi →",
    btnPrevStep: "← Ortga",
    lblVerifyCode: "Gmail pochtangizga yuborilgan 6 xonali tasdiqlash kodini kiriting:",
    btnSendCode: "📩 Kodni yuborish",
    btnVerifyAndFinish: "✅ Tasdiqlash va Kirish",
    codeSentNotice: "Tasdiqlash kodi Gmail pochtangizga yuborildi!",
    codeSimulatedAlert: "Tasdiqlash kodi (Gmail simulyatsiyasi): ",

    // 24-Hour Teacher Invite Link
    lblTeacherInvite24: "O'qituvchilar uchun 24 soatlik havola",
    btnShareTelegram: "✈️ Telegram guruhga yuborish",
    lblAutoBound: "O'qituvchi direktor bazasiga avtomatik tarzda ulanadi",
    lblInviteExpiresIn: "Yaroqlilik muddati: 24 soat",
    lblCopyInviteSuccess: "24 soatlik taklif havolasi nusxalandi!",

    // Attendance and Late Reasons
    lblStatusLate: "Kechikdi",
    lblStatusAbsent: "Kelmadi",
    lblStatusPresent: "Keldi",
    lblAttendanceReason: "Sababini kiriting yoki tanlang:",
    reasonTransport: "Transport / Yo'l tirbandligi",
    reasonIllness: "Salomatligi / Shifokorda",
    reasonFamily: "Oilaviy sabablar",
    reasonOther: "Boshqa sabab",

    // Database & Student phone management
    titleDatabase: "Maktab Ma'lumotlar Bazasi",
    lblStudentsDatabase: "O'quvchilar ro'yxati va telefon raqamlari",
    lblTeachersDatabase: "O'qituvchilar ro'yxati, parollari va sinflari",
    btnAddNewStudent: "➕ Yangi o'quvchi qo'shish",
    lblStudentPhone: "O'quvchi telefon raqami:",
    lblParentPhone: "Ota-onasining telefon raqami:",

    // iPhone PWA
    titleIphoneApp: "📱 iPhone uchun 14-Maktab Ilovasi",
    descIphoneApp: "Ilovani iPhone-ga App Store-siz to'liq ekranli o'rnatish:",
    stepIphone1: "1. Safari pastki panelidagi 'Ulashish' (Share ⎋) tugmasini bosing",
    stepIphone2: "2. Chiqqan ro'yxatdan 'Bosh ekranga' ('На экран «Домой»' ➕) bandini tanlang",
    stepIphone3: "3. Yuqoridagi 'Qo'shish' tugmasini bosing — ilova ekranga tushadi!",
    btnGotIt: "Tushundim, rahmat"
  },
  
  ru: {
    appTitle: "14-maktab — Школьный Журнал",
    appSubtitle: "Единая система управления школой и электронного учёта посещаемости",
    langName: "Русский",
    
    // Auth & Landing
    tabLogin: "Войти в систему",
    tabRegister: "Регистрация",
    tabRegisterSchool: "Регистрация новой школы",
    tabJoinSchool: "Подключиться к школе",
    emptyClassesTitle: "Классы пока не добавлены",
    emptyClassesDesc: "Чтобы вести список учеников и посещаемость, добавьте первый класс.",
    
    // School Registration
    lblRegSchoolTitle: "Регистрация школы",
    lblRegSchoolSub: "Заполняется директором школы",
    lblRegion: "Область / Регион:",
    lblCity: "Город или Район:",
    lblSchoolNumber: "Номер школы:",
    lblSchoolFullName: "Полное официальное название школы:",
    lblDirectorName: "Ф.И.О Директора (Имя и Фамилия):",
    lblDirectorPhone: "Телефон директора:",
    lblDirectorEmail: "Email директора (Gmail):",
    lblPassword: "Секретный пароль:",
    lblPasswordConfirm: "Подтверждение пароля:",
    btnCreateSchool: "🏫 Создать школу и получить код",
    
    // School Code Generated
    lblCodeSuccessTitle: "Школа успешно зарегистрирована!",
    lblCodeSuccessDesc: "По этому постоянному коду учителя и старосты будут подключаться к вашей школе. Сохраните его:",
    btnCopyCode: "📋 Скопировать код школы",
    btnEnterDirectorPanel: "👔 Войти в панель директора",
    
    // Join School
    lblJoinTitle: "Подключение к школе",
    lblJoinSub: "Введите код, выданный директором вашей школы",
    lblSchoolCode: "Код школы:",
    lblChooseRole: "Ваша роль:",
    roleTeacher: "Учитель (Классный руководитель)",
    roleStarosta: "Староста класса",
    roleDirector: "Директор школы",
    lblFullName: "Ваше Имя и Фамилия:",
    lblPhone: "Ваш номер телефона:",
    lblEmail: "Электронная почта (Gmail):",
    lblSelectClass: "Закреплённый класс:",
    btnSendJoinRequest: "📩 Отправить заявку на вступление",
    lblPendingApproval: "Заявка отправлена директору. После одобрения вы сможете войти в систему.",
    
    // Login
    lblLoginTitle: "Вход в систему",
    lblLoginSub: "Введите код школы, email/телефон и пароль",
    lblLoginIdentifier: "Email или номер телефона:",
    btnLogin: "ВОЙТИ В СИСТЕМУ",
    lblQuickLogin: "Быстрый вход для проверки:",
    
    // Director Dashboard
    navMySchool: "🏫 Моя школа",
    navTeachers: "👨‍🏫 Учителя",
    navClasses: "📚 Классы",
    navStudents: "👨‍🎓 Ученики",
    navReports: "📈 Отчёты",
    navSettings: "⚙️ Настройки",
    btnLogout: "Выйти",
    
    // Stats
    lblTodayStats: "Посещаемость школы за сегодня",
    lblTotalStudents: "Всего учеников",
    lblPresentCount: "Присутствуют",
    lblAbsentCount: "Отсутствуют",
    lblExcusedCount: "По уважительной",
    lblLateCount: "Опоздали",
    lblAttendanceRate: "Процент посещаемости",
    
    // Classes hierarchy
    lblClassesHierarchy: "Классы школы (с 11-го по 1-й):",
    lblSelectGrade: "Выберите параллель классов:",
    lblSelectLetter: "Выберите литеру класса:",
    gradeSuffix: " класс",
    classCardTeacher: "Классный руководитель",
    classCardStarosta: "Староста",
    classCardStudents: "Ученики",
    btnOpenJournal: "📖 Открыть журнал",
    btnClassStudents: "👥 Ученики",
    btnClassStats: "📊 Статистика",
    btnAddClass: "➕ Добавить класс",
    
    // Teacher Approval Queue
    lblPendingRequests: "Заявки на присоединение к школе",
    lblNoPendingRequests: "Нет ожидающих заявок",
    btnApprove: "✅ Принять",
    btnReject: "❌ Отклонить",
    
    // Journal View
    lblClassJournal: "Журнал класса",
    btnMarkAllPresent: "✅ ВСЕ ПРИСУТСТВУЮТ",
    btnAddStudent: "➕ Новый ученик",
    searchPlaceholder: "Поиск по фамилии...",
    statusPresent: "Присутствует",
    statusAbsent: "Отсутствует",
    statusExcused: "По причине",
    statusLate: "Опоздал",
    btnCallParent: "Позвонить",
    btnSendReport: "📤 Отправить директору",
    btnShareTelegram: "✈️ Поделиться в Telegram",
    
    // Student Form
    modalAddStudentTitle: "Добавление ученика",
    lblStudentLast: "Фамилия:",
    lblStudentFirst: "Имя:",
    lblStudentPhone: "Телефон родителей:",
    btnSave: "Сохранить",
    btnCancel: "Отмена",
    btnDelete: "Удалить",
    
    // Reasons
    modalReasonTitle: "Причина отсутствия",
    reasonsList: [
      "Болезнь (справка от врача)",
      "Семейные обстоятельства (по заявлению)",
      "Заявление родителей",
      "Олимпиада / Соревнования",
      "Прогул (без уважительной причины)"
    ],
    lblReasonNote: "Дополнительный комментарий:",
    
    // Backup & Restore
    lblBackupTitle: "Резервное копирование и экспорт/импорт данных",
    btnExportData: "💾 Скачать резервную копию (JSON)",
    btnImportData: "📥 Восстановить из копии (JSON)",
    
    // Messages & Alerts
    errFillAllFields: "Пожалуйста, заполните все обязательные поля!",
    errInvalidEmail: "Некорректный адрес электронной почты!",
    errInvalidPhone: "Некорректный номер телефона!",
    errPasswordMismatch: "Введённые пароли не совпадают!",
    errPasswordTooShort: "Пароль должен содержать не менее 6 символов!",
    errSchoolNotFound: "Школа с таким кодом не найдена. Проверьте код!",
    errLoginFailed: "Неверный телефон/email или пароль!",
    errAccountPending: "Ваша заявка ещё не одобрена директором школы.",
    errDuplicateStudent: "Ученик с таким именем и фамилией уже есть в этом классе!",
    errInvalidBackupFile: "Некорректный файл резервной копии!",
    toastSaved: "Успешно сохранено!",
    toastReportSent: "Отчёт отправлен!",
    toastStudentAdded: "Ученик добавлен!",
    toastStudentDeleted: "Ученик удалён!",
    toastApproved: "Пользователь успешно принят!",
    toastRejected: "Заявка отклонена!",
    confirmDeleteStudent: "Вы действительно хотите удалить этого ученика из класса?",
    
    // Invites & Links
    btnInviteMember: "🔗 Создать ссылку-приглашение",
    btnInviteCodePrompt: "🔗 Присоединиться по коду-приглашению",
    modalCreateInviteTitle: "Создать приглашение",
    lblInviteRole: "Кого вы хотите пригласить?",
    lblInviteClass: "Класс (для старосты):",
    btnGenerateInvite: "✨ Создать приглашение",
    lblGeneratedLink: "Ссылка для приглашения (действует 24 часа):",
    btnCopyLink: "📋 Скопировать ссылку",
    btnSendToTelegram: "✈️ Отправить в Telegram",
    lblActiveInvites: "Активные ссылки-приглашения",
    lblNoActiveInvites: "Нет активных приглашений",
    btnCancelInvite: "Отменить",
    lblInviteValid24h: "⏱ Действует 24 часа • Одноразовая",
    lblInviteUsed: "Использована",
    lblInviteExpired: "Истекла",
    lblInviteCancelled: "Отменена",
    lblInviteActive: "Активна",
    inviteWelcomeTitle: "Приглашение в школу",
    inviteInvitedBy: "Вас пригласил директор школы",
    btnJoinViaInvite: "Создать аккаунт и присоединиться",
    errInviteInvalid: "Ссылка-приглашение недействительна или не существует!",
    errInviteAlreadyUsed: "Эта ссылка уже была использована ранее!",
    errInviteExpiredMsg: "Срок действия приглашения (24 часа) истёк!",
    errInviteCancelledMsg: "Это приглашение было отменено директором!",
    toastInviteCreated: "Ссылка-приглашение создана!",
    toastInviteCopied: "Ссылка скопирована в буфер!",
    toastInviteCancelled: "Приглашение отменено!",
    toastInviteSubmitted: "Заявка отправлена директору на подтверждение!",
    lblInviteType: "Тип приглашения:",
    optTeacherGroup: "👥 Общая ссылка для группы учителей (все учителя вступают по одной ссылке)",
    optStarosta: "🎓 Персональная ссылка для старосты",
    optTeacherSingle: "👨‍🏫 Одноразовая ссылка для одного учителя",
    lblInviteDuration: "Срок действия ссылки:",
    optDuration3d: "3 дня (72 часа) — Рекомендуется",
    optDuration7d: "7 дней (1 неделя)",
    optDuration24h: "24 часа (1 день)",
    lblGroupNotice: "Отправьте эту ссылку в Telegram-группу учителей школы. Все учителя смогут зарегистрироваться по ней. Директор подтверждает каждого лично кнопкой [Принять].",
    lblJoinedCount: "учителей вступило",

    // Settings & Profile
    modalSettingsTitle: "Настройки и профиль",
    lblUserProfile: "Профиль пользователя",
    lblAppLanguage: "Язык приложения:",
    btnCopyMyCredentials: "📋 Скопировать данные для входа",
    toastCredentialsCopied: "Данные для входа скопированы!",
    btnLogoutConfirm: "Вы действительно хотите выйти из своего аккаунта?",
    btnLogoutFromAccount: "🚪 Выйти из аккаунта",
    btnLogoutDesc: "Выход осуществляется через настройки",
    lblSchoolDetails: "Информация о школе",
    btnCopySchoolCode: "📋 Скопировать код школы",
    toastCodeCopied: "Код школы скопирован!",

    // iOS Bottom Navigation & Windows
    tabNavHome: "Главная",
    tabNavClasses: "Классы",
    tabNavJournal: "Журнал",
    tabNavTeachers: "Учителя",
    tabNavSettings: "Настройки",
    titleTeachersWindow: "Учителя школы и заявки",
    titleSettingsWindow: "Настройки школы и База",
    btnEditProfile: "Редактировать данные",
    btnSaveProfile: "Сохранить изменения",
    toastProfileSaved: "Данные профиля успешно сохранены!",
    lblActiveTeachers: "Список активных учителей",
    lblNoTeachers: "Учителя пока не подключены",
    modalDirectorTitle: "Вход и регистрация Директора",
    btnSaveAndEnter: "💾 Сохранить и войти",
    btnTopSave: "💾 Сохранить",
    modalSavedTitle: "Регистрация сохранена!",
    msgAccountSavedDesc: "Ваш логин и пароль сохранены. Теперь вы можете войти в систему с этими данными:",

    // Interactive Questionnaire Registration
    stepRole: "1. Кто вы? (Выберите роль)",
    stepSchool: "2. Какая школа и город?",
    stepPersonal: "3. Личные данные",
    stepPassword: "4. Секретный пароль",
    stepVerify: "5. Подтверждение через Gmail",
    btnNextStep: "Следующий шаг →",
    btnPrevStep: "← Назад",
    lblVerifyCode: "Введите 6-значный проверочный код, отправленный на Gmail:",
    btnSendCode: "📩 Отправить код",
    btnVerifyAndFinish: "✅ Подтвердить и войти",
    codeSentNotice: "Проверочный код отправлен на вашу почту Gmail!",
    codeSimulatedAlert: "Проверочный код (Gmail симуляция): ",

    // 24-Hour Teacher Invite Link
    lblTeacherInvite24: "24-часовая ссылка для учителей",
    btnShareTelegram: "✈️ Отправить в группу Telegram",
    lblAutoBound: "Учитель автоматически привязывается к базе директора",
    lblInviteExpiresIn: "Срок действия ссылки: 24 часа",
    lblCopyInviteSuccess: "24-часовая ссылка для учителей скопирована!",

    // Attendance and Late Reasons
    lblStatusLate: "Опоздал",
    lblStatusAbsent: "Не пришел",
    lblStatusPresent: "Пришел",
    lblAttendanceReason: "Укажите или выберите причину:",
    reasonTransport: "Транспорт / Пробки",
    reasonIllness: "Болен / Поликлиника",
    reasonFamily: "Семейные обстоятельства",
    reasonOther: "Другая причина",

    // Database & Student phone management
    titleDatabase: "База данных школы",
    lblStudentsDatabase: "Список учеников и номера телефонов",
    lblTeachersDatabase: "Список учителей, пароли и классы",
    btnAddNewStudent: "➕ Добавить ученика",
    lblStudentPhone: "Телефон ученика:",
    lblParentPhone: "Телефон родителей:",

    // iPhone PWA
    titleIphoneApp: "📱 Приложение 14-Школа для iPhone",
    descIphoneApp: "Как установить приложение на iPhone на весь экран без App Store:",
    stepIphone1: "1. В браузере Safari внизу нажмите кнопку «Поделиться» (Share ⎋)",
    stepIphone2: "2. Прокрутите меню и выберите «На экран «Домой» (Add to Home Screen ➕)»",
    stepIphone3: "3. В правом верхнем углу нажмите «Добавить» — приложение готово!",
    btnGotIt: "Понятно, спасибо"
  }
};

let currentLang = localStorage.getItem('journal_lang') || 'uz';

function t(key) {
  const dict = I18N[currentLang] || I18N.uz;
  return dict[key] !== undefined ? dict[key] : key;
}

function setLanguage(lang) {
  if (lang !== 'uz' && lang !== 'ru') lang = 'uz';
  currentLang = lang;
  localStorage.setItem('journal_lang', lang);
  if (window.onLanguageChanged) {
    window.onLanguageChanged(lang);
  }
}
