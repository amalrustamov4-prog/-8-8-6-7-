/**
 * 14-Maktab / Jurnal - Strict Backup & Import Manager
 * Schema Validation, Integrity Check, Safe Restore without Overwriting.
 */

const BackupManager = (function() {

  function exportBackupJSON(schoolCode) {
    const data = DB.dumpBackup(schoolCode);
    const jsonStr = JSON.stringify(data, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `maktab_backup_${schoolCode}_${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    return jsonStr;
  }

  function validateAndImport(jsonString) {
    if (!jsonString || typeof jsonString !== 'string') {
      throw new Error(t('errInvalidBackupFile') + " (Bo'sh ma'lumot)");
    }

    let payload;
    try {
      payload = JSON.parse(jsonString);
    } catch (e) {
      throw new Error(t('errInvalidBackupFile') + " (JSON formati noto'g'ri)");
    }

    // 1. Check version
    if (!payload.version) {
      throw new Error(t('errInvalidBackupFile') + " (Versiya ko'rsatilmagan)");
    }

    // 2. Check school integrity
    if (!payload.school || !payload.school.code || !payload.school.name) {
      throw new Error(t('errInvalidBackupFile') + " (Maktab ma'lumotlari to'liq emas)");
    }

    // 3. Check array formats
    if (!Array.isArray(payload.students)) {
      throw new Error(t('errInvalidBackupFile') + " (O'quvchilar ro'yxati noto'g'ri formatda)");
    }

    // 4. Validate each student record
    payload.students.forEach((st, idx) => {
      if (!st.lastName || !st.firstName) {
        throw new Error(t('errInvalidBackupFile') + ` (${idx + 1}-o'quvchi ismi yoki familiyasi to'liq emas)`);
      }
    });

    // 5. Safe restore
    DB.restoreBackup(payload);
    return payload.school;
  }

  return {
    exportBackupJSON,
    validateAndImport
  };
})();
