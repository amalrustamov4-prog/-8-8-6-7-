/**
 * 14-Maktab 3D & Cyber-Motion Engine
 * Interactive particle constellation canvas, 3D card tilt physics, ambient neon lighting
 */

(function init3DEngine() {
  // 1. Interactive 3D Background Canvas
  function setupParticleCanvas() {
    const canvas = document.getElementById('bg-3d-canvas');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    window.addEventListener('resize', () => {
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    });

    const particles = [];
    const PARTICLE_COUNT = Math.min(Math.floor((width * height) / 14000), 85);
    let mouse = { x: width / 2, y: height / 2, active: false };

    window.addEventListener('mousemove', (e) => {
      mouse.x = e.clientX;
      mouse.y = e.clientY;
      mouse.active = true;
    });

    window.addEventListener('mouseleave', () => {
      mouse.active = false;
    });

    const colors = [
      'rgba(99, 102, 241, ', // Indigo
      'rgba(56, 189, 248, ', // Sky
      'rgba(168, 85, 247, ', // Purple
      'rgba(16, 185, 129, '  // Emerald
    ];

    for (let i = 0; i < PARTICLE_COUNT; i++) {
      particles.push({
        x: Math.random() * width,
        y: Math.random() * height,
        z: Math.random() * 0.8 + 0.2, // 3D depth layer
        vx: (Math.random() - 0.5) * 0.8,
        vy: (Math.random() - 0.5) * 0.8,
        radius: Math.random() * 2.2 + 1.2,
        baseColor: colors[Math.floor(Math.random() * colors.length)],
        pulse: Math.random() * Math.PI
      });
    }

    function render() {
      ctx.clearRect(0, 0, width, height);

      // Render connected lines & particle nodes
      for (let i = 0; i < particles.length; i++) {
        const p = particles[i];

        p.x += p.vx * p.z;
        p.y += p.vy * p.z;
        p.pulse += 0.02;

        if (p.x < 0) p.x = width;
        if (p.x > width) p.x = 0;
        if (p.y < 0) p.y = height;
        if (p.y > height) p.y = 0;

        // Subtle mouse gravity in 3D
        if (mouse.active) {
          const dx = mouse.x - p.x;
          const dy = mouse.y - p.y;
          const dist = Math.sqrt(dx * dx + dy * dy);
          if (dist < 180) {
            const force = (180 - dist) / 180;
            p.x += (dx / dist) * force * 1.5 * p.z;
            p.y += (dy / dist) * force * 1.5 * p.z;
          }
        }

        const opacity = (0.35 + Math.sin(p.pulse) * 0.2) * p.z;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.radius * p.z, 0, Math.PI * 2);
        ctx.fillStyle = p.baseColor + opacity + ')';
        ctx.shadowBlur = 12 * p.z;
        ctx.shadowColor = p.baseColor + '0.6)';
        ctx.fill();
        ctx.shadowBlur = 0; // reset

        // Connect nearby nodes
        for (let j = i + 1; j < particles.length; j++) {
          const p2 = particles[j];
          const dist = Math.hypot(p.x - p2.x, p.y - p2.y);
          if (dist < 130) {
            const lineAlpha = (1 - dist / 130) * 0.22 * Math.min(p.z, p2.z);
            ctx.beginPath();
            ctx.moveTo(p.x, p.y);
            ctx.lineTo(p2.x, p2.y);
            ctx.strokeStyle = `rgba(148, 163, 184, ${lineAlpha})`;
            ctx.lineWidth = 0.8 * Math.min(p.z, p2.z);
            ctx.stroke();
          }
        }
      }

      requestAnimationFrame(render);
    }

    render();
  }

  // 2. 3D Card Tilt Physics
  function setup3DTiltCards() {
    const cards = document.querySelectorAll('.card-3d, .auth-hero-card, .admin-stat-card, .hologram-card');

    cards.forEach((card) => {
      card.addEventListener('mousemove', (e) => {
        const rect = card.getBoundingClientRect();
        const x = e.clientX - rect.left; // x pos within card
        const y = e.clientY - rect.top;  // y pos within card
        const centerX = rect.width / 2;
        const centerY = rect.height / 2;

        const rotateX = ((y - centerY) / centerY) * -9; // Max 9 deg tilt
        const rotateY = ((x - centerX) / centerX) * 9;

        card.style.transform = `perspective(1000px) rotateX(${rotateX.toFixed(2)}deg) rotateY(${rotateY.toFixed(2)}deg) scale3d(1.02, 1.02, 1.02)`;
      });

      card.addEventListener('mouseleave', () => {
        card.style.transform = 'perspective(1000px) rotateX(0deg) rotateY(0deg) scale3d(1, 1, 1)';
      });
    });
  }

  // DOM ready init
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
      setupParticleCanvas();
      setup3DTiltCards();
    });
  } else {
    setupParticleCanvas();
    setup3DTiltCards();
  }

  // Re-bind 3D tilt when tabs or screens switch
  window.rebind3DTilt = function () {
    setTimeout(setup3DTiltCards, 100);
  };
})();
