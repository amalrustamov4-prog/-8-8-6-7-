/**
 * 14-Maktab / Jurnal - UI Controller & Application Orchestrator
 * Connects UI events to Auth, SchoolManager, AttendanceManager, and DB.
 */

const App = (function() {

  let currentSchool = null;
  let currentSession = null;
  let selectedGrade = 10;
  let selectedLetter = 'A';
  let selectedClassId = '10-A';
  let currentDayOffset = 0;
  let activeStudentForReason = null;
  let activeInvite = null;
  let lastGeneratedInvite = null;

  // 1. Toast Notification
  function showToast(msg) {
    const el = document.getElementById('toast');
    if (!el) return;
    el.textContent = msg;
    el.style.display = 'block';
    setTimeout(() => { el.style.display = 'none'; }, 2400);
  }

  // 2. Screen Switching
  function switchScreen(screenId) {
    document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
    const target = document.getElementById(screenId);
    if (target) target.classList.add('active');
  }

  // 3. Tab Switching in Auth
  function switchAuthTab(tab) {
    document.querySelectorAll('.auth-nav-tab').forEach(b => b.classList.remove('active'));
    const tb = document.getElementById(`tab-btn-${tab}`);
    if (tb) tb.classList.add('active');

    const loginP = document.getElementById('auth-panel-login');
    const regP = document.getElementById('auth-panel-register');
    if (loginP) loginP.style.display = (tab === 'login') ? 'block' : 'none';
    if (regP) regP.style.display = (tab === 'register') ? 'block' : 'none';
  }

  // 3b. Role Selection in Registration
  let currentRegRole = 'director';
  function selectRegRole(role) {
    currentRegRole = role;
    ['director', 'teacher', 'starosta'].forEach(r => {
      const btn = document.getElementById(`btn-role-${r}`);
      if (btn) {
        if (r === role) btn.classList.add('active');
        else btn.classList.remove('active');
      }
      const form = document.getElementById(`reg-form-${r}`);
      if (form) {
        form.style.display = (r === role) ? 'block' : 'none';
      }
    });
  }

  // 3c. Direct Registration Handlers
  async function handleDirectDirectorRegister() {
    const schoolName = (document.getElementById('reg-dir-school-name').value || '').trim();
    const city = (document.getElementById('reg-dir-city').value || '').trim();
    const directorName = (document.getElementById('reg-dir-fullname').value || '').trim();
    const directorPhone = (document.getElementById('reg-dir-phone').value || '').trim();
    const directorEmail = (document.getElementById('reg-dir-email').value || '').trim();
    const password = document.getElementById('reg-dir-password').value || '';

    if (!schoolName || !directorName || !directorEmail || !password) {
      alert(currentLang === 'uz' ? 'Iltimos, barcha majburiy maydonlarni to\'ldiring!' : 'Пожалуйста, заполните все обязательные поля!');
      return;
    }
    if (password.length < 6) {
      alert(t('errPasswordTooShort'));
      return;
    }

    try {
      const res = await Auth.registerSchool({
        fullName: schoolName,
        number: schoolName.replace(/[^0-9]/g, '') || '14',
        city: city || 'Termiz',
        region: city || 'Surxondaryo',
        directorName: directorName,
        directorPhone: directorPhone,
        directorEmail: directorEmail,
        password: password,
        passwordConfirm: password
      });

      currentSchool = res.school;
      currentSession = res.session;
      enterAuthenticatedState();
      showToast(currentLang === 'uz' ? `Xush kelibsiz, Direktor ${directorName}!` : `Добро пожаловать, Директор ${directorName}!`);
    } catch (e) {
      alert(e.message);
    }
  }

  // 3d. Teacher Registration with Grade, Letter & Student Count
  async function handleTeacherRegisterWithClass() {
    const schoolCode = (document.getElementById('reg-teach-school-code').value || 'TERMIZ-14-7K29').trim();
    const fullName = (document.getElementById('reg-teach-fullname').value || '').trim();
    const grade = parseInt(document.getElementById('reg-teach-grade').value, 10) || 9;
    const letter = (document.getElementById('reg-teach-letter').value || 'A').trim().toUpperCase();
    const studentCount = parseInt(document.getElementById('reg-teach-count').value, 10) || 25;
    const phone = (document.getElementById('reg-teach-phone').value || '').trim();
    const email = (document.getElementById('reg-teach-email').value || '').trim();
    const password = document.getElementById('reg-teach-password').value || '';

    if (!fullName || !password) {
      alert(currentLang === 'uz' ? 'Iltimos, ismingiz va parolni to\'ldiring!' : 'Пожалуйста, укажите имя и пароль!');
      return;
    }
    if (password.length < 6) {
      alert(t('errPasswordTooShort'));
      return;
    }

    try {
      const res = await Auth.registerTeacherWithClass({
        schoolCode,
        fullName,
        grade,
        letter,
        studentCount,
        phone,
        email,
        password
      });

      currentSchool = res.school;
      currentSession = res.session;
      selectedClassId = `${grade}-${letter}`;

      enterAuthenticatedState();
      showToast(currentLang === 'uz' ? `Xush kelibsiz, ${fullName}! (${grade}-${letter} sinfi yaratildi)` : `Добро пожаловать, ${fullName}! (Класс ${grade}-${letter} создан)`);
    } catch (e) {
      alert(e.message);
    }
  }

  // 3e. Starosta Registration with Grade & Letter
  async function handleStarostaRegisterWithClass() {
    const schoolCode = (document.getElementById('reg-stud-school-code').value || 'TERMIZ-14-7K29').trim();
    const fullName = (document.getElementById('reg-stud-fullname').value || '').trim();
    const grade = parseInt(document.getElementById('reg-stud-grade').value, 10) || 9;
    const letter = (document.getElementById('reg-stud-letter').value || 'A').trim().toUpperCase();
    const phone = (document.getElementById('reg-stud-phone').value || '').trim();
    const email = (document.getElementById('reg-stud-email').value || '').trim();
    const password = document.getElementById('reg-stud-password').value || '';

    if (!fullName || !password) {
      alert(currentLang === 'uz' ? 'Iltimos, ismingiz va parolni to\'ldiring!' : 'Пожалуйста, укажите имя и пароль!');
      return;
    }
    if (password.length < 6) {
      alert(t('errPasswordTooShort'));
      return;
    }

    try {
      const res = await Auth.registerStarostaWithClass({
        schoolCode,
        fullName,
        grade,
        letter,
        phone,
        email,
        password
      });

      currentSchool = res.school;
      currentSession = res.session;
      selectedClassId = `${grade}-${letter}`;

      enterAuthenticatedState();
      showToast(currentLang === 'uz' ? `Xush kelibsiz, ${fullName}! (${grade}-${letter} sinf sardori)` : `Добро пожаловать, ${fullName}! (Староста ${grade}-${letter})`);
    } catch (e) {
      alert(e.message);
    }
  }

  // Legacy fallback
  async function handleDirectMemberRegister(role) {
    if (role === 'teacher') return handleTeacherRegisterWithClass();
    return handleStarostaRegisterWithClass();
  }

  // Quick Demo Helper for 1-click Testing
  function fillDemoLogin(ident, pass) {
    const identEl = document.getElementById('login-ident');
    const passEl = document.getElementById('login-password');
    if (identEl) identEl.value = ident;
    if (passEl) passEl.value = pass;
    handleLogin();
  }

  function openAdminPanelDirect() {
    const users = DB.getUsers();
    let adminUser = users.find(u => u.role === 'admin' || u.role === 'superadmin' || u.username === 'admin');
    if (!adminUser) {
      adminUser = {
        id: 'usr_admin_1',
        role: 'superadmin',
        name: 'Tizim Administratori (Baza)',
        username: 'admin',
        email: 'admin@14maktab.uz',
        schoolCode: 'TERMIZ-14-7K29',
        plainPassword: 'admin123'
      };
    }
    Auth.saveSession(adminUser);
    currentSession = adminUser;
    currentSchool = DB.getSchoolByCode(adminUser.schoolCode || 'TERMIZ-14-7K29') || {
      name: "14-sonli umumiy o'rta ta'lim maktabi",
      code: 'TERMIZ-14-7K29'
    };
    try {
      if (window.location.hash !== '#admin') {
        window.location.hash = 'admin';
      }
    } catch (e) {}

    enterAuthenticatedState();
    switchScreen('screen-admin');
    renderAdminPanel();
    showToast(currentLang === 'uz' ? 'Admin Panel va Baza ochildi' : 'Открыта панель администратора');
  }

  function openDirectorPanelDirect() {
    const users = DB.getUsers();
    let dirUser = users.find(u => u.role === 'director');
    if (!dirUser) {
      dirUser = {
        id: 'usr_director_1',
        role: 'director',
        name: 'Olimov Bobur',
        email: 'director@14maktab.uz',
        schoolCode: 'TERMIZ-14-7K29',
        plainPassword: 'director123'
      };
    }
    Auth.saveSession(dirUser);
    currentSession = dirUser;
    currentSchool = DB.getSchoolByCode(dirUser.schoolCode || 'TERMIZ-14-7K29');
    try {
      if (window.location.hash !== '#director') {
        window.location.hash = 'director';
      }
    } catch (e) {}

    enterAuthenticatedState();
    switchScreen('screen-director');
    switchWindow('teachers');
    showToast(currentLang === 'uz' ? 'Direktor kabinetiga o\'tildi' : 'Переход в кабинет директора');
  }

  // 4. Date formatting
  function getDateString(offset = 0) {
    const d = new Date();
    d.setDate(d.getDate() + offset);
    return d.toISOString().split('T')[0];
  }

  function getDateDisplay(offset = 0) {
    const d = new Date();
    d.setDate(d.getDate() + offset);
    const monthsUz = ['yanvar','fevral','mart','aprel','may','iyun','iyul','avgust','sentabr','oktabr','noyabr','dekabr'];
    const monthsRu = ['января','февраля','марта','апреля','мая','июня','июля','августа','сентября','октября','ноября','декабря'];
    const daysUz = ['Yakshanba','Dushanba','Seshanba','Chorshanba','Payshanba','Juma','Shanba'];
    const daysRu = ['Воскресенье','Понедельник','Вторник','Среда','Четверг','Пятница','Суббота'];

    const isUz = (currentLang === 'uz');
    const dayName = isUz ? daysUz[d.getDay()] : daysRu[d.getDay()];
    const monthName = isUz ? monthsUz[d.getMonth()] : monthsRu[d.getMonth()];
    return `${dayName}, ${d.getDate()} ${monthName}`;
  }

  function checkInviteFromUrl() {
    try {
      const hash = window.location.hash || '';
      const search = window.location.search || '';
      
      let token = null;
      if (hash) {
        const match = hash.match(/invite[=\/]([A-Za-z0-9\-]+)/i);
        if (match) token = match[1];
        else if (hash.includes('/join/')) {
          token = hash.split('/join/')[1];
        }
      }
      if (!token && search) {
        const match = search.match(/invite=([A-Za-z0-9\-]+)/i);
        if (match) token = match[1];
      }
      return token ? token.trim().toUpperCase() : null;
    } catch (e) {
      return null;
    }
  }

  // 5. Initialize Application
  async function init() {
    await DB.init();
    applyAllTranslations();

    // 1. Check if opened with #admin hash
    if (window.location.hash && window.location.hash.toLowerCase().includes('admin')) {
      openAdminPanelDirect();
      return;
    }

    // 2. Check if opened via invite link / hash / parameter
    const inviteToken = checkInviteFromUrl();
    if (inviteToken) {
      openInviteScreen(inviteToken);
      return;
    }

    // 3. Check Session
    const sess = Auth.getCurrentSession();
    if (sess) {
      currentSession = sess;
      currentSchool = DB.getSchoolByCode(sess.schoolCode);
      if (currentSchool) {
        enterAuthenticatedState();
        return;
      }
    }

    // No session -> open login
    switchScreen('screen-auth');
    switchAuthTab('login');

    // Auto-fill remembered school code & login identifier
    try {
      const allSchools = DB.getSchools();
      const defaultSchoolCode = (allSchools && allSchools.length > 0) ? allSchools[0].code : 'TERMIZ-14-7K29';
      const savedSchoolCode = localStorage.getItem('jurnal_last_school_code') || defaultSchoolCode;
      const savedIdent = localStorage.getItem('jurnal_last_login_ident');

      ['login-school-code', 'reg-teach-school-code', 'reg-stud-school-code'].forEach(id => {
        const el = document.getElementById(id);
        if (el && !el.value) {
          el.value = savedSchoolCode;
        }
      });

      if (savedIdent && document.getElementById('login-ident')) {
        document.getElementById('login-ident').value = savedIdent;
      }
    } catch (e) {}

    window.addEventListener('hashchange', () => {
      const hash = window.location.hash || '';
      if (hash.toLowerCase().includes('admin')) {
        openAdminPanelDirect();
        return;
      }
      if (hash.toLowerCase().includes('director')) {
        openDirectorPanelDirect();
        return;
      }
      const tok = checkInviteFromUrl();
      if (tok) openInviteScreen(tok);
    });

    // Initialize Telegram bottom bar drag gesture & wizard default role
    setupTelegramLiquidDockGesture();
    selectWizardRole('director');
  }

  function autoFillSchoolCode(code = 'TERMIZ-14-7K29') {
    ['login-school-code', 'reg-teach-school-code', 'reg-stud-school-code'].forEach(id => {
      const el = document.getElementById(id);
      if (el) el.value = code;
    });
    showToast(currentLang === 'uz' ? `Maktab kodi kiritildi: ${code}` : `Код школы вставлен: ${code}`);
  }

  function applyAllTranslations() {
    document.querySelectorAll('[data-i18n]').forEach(el => {
      const key = el.getAttribute('data-i18n');
      if (key) {
        el.textContent = t(key);
      }
    });

    document.querySelectorAll('[data-i18n-placeholder]').forEach(el => {
      const key = el.getAttribute('data-i18n-placeholder');
      if (key) {
        el.placeholder = t(key);
      }
    });

    // Update active lang button in header
    const ruBtn = document.getElementById('btn-lang-ru');
    const uzBtn = document.getElementById('btn-lang-uz');
    if (ruBtn) ruBtn.classList.toggle('active', currentLang === 'ru');
    if (uzBtn) uzBtn.classList.toggle('active', currentLang === 'uz');
  }

  window.onLanguageChanged = function() {
    applyAllTranslations();
    if (currentSession) {
      if (currentSession.role === 'director') {
        switchWindow(currentActiveWindow || 'journal');
      } else {
        renderJournal();
      }
    }
  };

  // 6. Enter Authenticated State
  function enterAuthenticatedState() {
    const isDirector = (currentSession.role === 'director');

    if (document.getElementById('header-school-name') && currentSchool) {
      document.getElementById('header-school-name').textContent = currentSchool.name;
    }
    if (document.getElementById('header-user-badge')) {
      document.getElementById('header-user-badge').textContent = currentSession.name;
    }

    // eMaktab user avatar initials & role badge
    const initialsEl = document.getElementById('header-avatar-initials');
    if (initialsEl && currentSession.name) {
      const parts = currentSession.name.trim().split(/\s+/);
      const initials = parts.length > 1 ? (parts[0][0] + parts[1][0]).toUpperCase() : parts[0].slice(0, 2).toUpperCase();
      initialsEl.textContent = initials;
    }
    const roleBadge = document.getElementById('header-user-role-badge');
    if (roleBadge) {
      let roleTitle = t('roleDirector');
      if (currentSession.role === 'teacher') roleTitle = `${t('roleTeacher')} (${currentSession.classId || '10-A'})`;
      else if (currentSession.role === 'starosta') roleTitle = `${t('roleStarosta')} (${currentSession.classId || '10-A'})`;
      roleBadge.textContent = roleTitle;
    }

    // Show eMaktab top user chip & cyan navigation strip
    const userChip = document.getElementById('emaktab-user-chip');
    if (userChip) userChip.style.display = 'flex';

    const navStrip = document.getElementById('emaktab-nav-strip');
    if (navStrip) navStrip.style.display = 'flex';

    // Show settings icon in header if present
    const headSettings = document.getElementById('btn-head-settings');
    if (headSettings) headSettings.style.display = 'flex';

    // Auto-remember credentials for quick subsequent logins
    try {
      if (currentSchool && currentSchool.code) {
        localStorage.setItem('jurnal_last_school_code', currentSchool.code);
      }
      if (currentSession && (currentSession.email || currentSession.phone)) {
        localStorage.setItem('jurnal_last_login_ident', currentSession.email || currentSession.phone);
      }
    } catch (e) {}

    const isAdmin = (currentSession.role === 'admin' || currentSession.role === 'superadmin');
    if (isAdmin) {
      const bottomBar = document.getElementById('app-bottom-bar');
      if (bottomBar) bottomBar.style.display = 'none';
      switchScreen('screen-admin');
      renderAdminPanel();
      return;
    }

    if (isDirector) {
      switchScreen('screen-director');
      const bottomBar = document.getElementById('app-bottom-bar');
      if (bottomBar) bottomBar.style.display = 'flex';
      const screenDir = document.getElementById('screen-director');
      if (screenDir) screenDir.classList.add('has-liquid-bar');
      switchWindow('journal');
      renderDirectorDashboard();
      renderDirectorTeachersTable();
    } else {
      const bottomBar = document.getElementById('app-bottom-bar');
      if (bottomBar) bottomBar.style.display = 'none';
      const screenDir = document.getElementById('screen-director');
      if (screenDir) screenDir.classList.remove('has-liquid-bar');
      selectedClassId = currentSession.classId || '9-A';
      switchScreen('screen-journal');
      renderJournal();
    }
  }

  // 7. Render Director Dashboard
  function renderDirectorDashboard() {
    if (!currentSchool) return;


    // School code badge
    document.getElementById('dir-dash-school-code').textContent = currentSchool.code;
    document.getElementById('dir-dash-school-title').textContent = currentSchool.name;
    document.getElementById('dir-dash-school-region').textContent = `${currentSchool.region}, ${currentSchool.city}`;

    // Overall School Attendance Stats
    const dateStr = getDateString(currentDayOffset);
    const summary = SchoolManager.getSchoolSummaryStats(currentSchool.code, dateStr);

    document.getElementById('stat-dir-total').textContent = summary.totalStudents;
    document.getElementById('stat-dir-present').textContent = summary.presentCount;
    document.getElementById('stat-dir-absent').textContent = summary.absentCount;
    document.getElementById('stat-dir-excused').textContent = summary.excusedCount;
    document.getElementById('stat-dir-rate').textContent = `${summary.rate}% ${currentLang === 'uz' ? 'darsda' : 'на уроках'}`;

    // Render Pending Join Requests
    renderPendingRequests();

    // Render Active Invites
    renderActiveInvites();

    // Render Classes Grid
    renderClassesWindow();

    // Render Reports Feed
    renderReportsFeed();
  }

  // Grades row (11 to 1)
  function renderGradesRow() {
    const container = document.getElementById('grades-row');
    if (!container) return;
    container.innerHTML = '';

    SchoolManager.ALL_GRADES.forEach(g => {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = `grade-btn ${selectedGrade === g ? 'active' : ''}`;
      btn.textContent = `${g}${t('gradeSuffix')}`;
      btn.onclick = () => {
        selectedGrade = g;
        renderGradesRow();
        renderLettersRow();
        renderSelectedClassCard();
      };
      container.appendChild(btn);
    });
  }

  // Letters row for selected grade (Grades 1 to 11 with RU: А, Б, В, Г, Д or UZ: A, B, D, V, G)
  function renderLettersRow() {
    const container = document.getElementById('letters-row');
    if (!container) return;
    container.innerHTML = '';

    const isUz = (currentLang === 'uz');
    const defaultLetters = isUz ? ['A', 'B', 'D', 'V', 'G'] : ['А', 'Б', 'В', 'Г', 'Д'];

    const classesInGrade = currentSchool ? SchoolManager.getClassesByGrade(currentSchool.code, selectedGrade) : [];
    const existingLetters = classesInGrade.map(c => c.letter);

    // Merge default letters with any existing custom letters in this grade
    const allLetters = Array.from(new Set([...defaultLetters, ...existingLetters]));

    // If selected letter is not in this grade, default to first available
    if (!allLetters.includes(selectedLetter) && allLetters.length > 0) {
      selectedLetter = allLetters[0];
    }
    selectedClassId = `${selectedGrade}-${selectedLetter}`;

    allLetters.forEach(l => {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = `letter-btn ${selectedLetter === l ? 'active' : ''}`;
      btn.textContent = `${selectedGrade}-${l}`;
      btn.onclick = () => {
        selectedLetter = l;
        selectedClassId = `${selectedGrade}-${l}`;

        if (currentSchool) {
          try {
            const exists = DB.getClassesBySchool(currentSchool.code).some(c => c.classId === selectedClassId);
            if (!exists) {
              SchoolManager.addClass(currentSchool.code, selectedGrade, l);
            }
          } catch (e) {}
        }

        renderLettersRow();
        renderSelectedClassCard();
      };
      container.appendChild(btn);
    });
  }

  // Selected Class Card
  function renderSelectedClassCard() {
    const container = document.getElementById('selected-class-card-container');
    if (!container) return;

    const dateStr = getDateString(currentDayOffset);
    const detail = SchoolManager.getClassDetail(currentSchool.code, selectedClassId, dateStr);

    const teacherName = detail.teacher ? detail.teacher.name : (currentLang === 'uz' ? 'Tayinlanmagan' : 'Не назначен');
    const starostaName = detail.starosta ? detail.starosta.name : (currentLang === 'uz' ? 'Tayinlanmagan' : 'Не назначен');

    container.innerHTML = `
      <div class="class-info-card">
        <div class="class-header-row">
          <div style="display:flex; align-items:center; gap:10px;">
            <span class="class-badge-pill">${selectedClassId}</span>
            <div>
              <div style="font-size:15px; font-weight:900;">${selectedClassId} ${t('gradeSuffix')}</div>
              <div style="font-size:12px; color:var(--text-muted); font-weight:700;">
                👨‍🏫 ${t('classCardTeacher')}: <strong>${teacherName}</strong>
              </div>
            </div>
          </div>
          <span style="font-size:11px; font-weight:800; padding:4px 8px; border-radius:6px; background:${detail.absentCount === 0 ? 'var(--present-bg)' : 'var(--absent-bg)'}; color:${detail.absentCount === 0 ? 'var(--present)' : 'var(--absent)'};">
            ${detail.attendanceRate}%
          </span>
        </div>

        <div style="font-size:11px; color:#475569; margin-bottom:12px;">
          🎓 ${t('classCardStarosta')}: <strong>${starostaName}</strong> • 👨‍🎓 ${t('classCardStudents')}: <strong>${detail.totalStudents}</strong>
        </div>

        <div class="stats-summary-grid" style="margin-bottom:14px;">
          <div class="stat-card">
            <div class="stat-num">${detail.totalStudents}</div>
            <div class="stat-lbl">${t('lblTotalStudents')}</div>
          </div>
          <div class="stat-card present">
            <div class="stat-num">${detail.presentCount}</div>
            <div class="stat-lbl">${t('statusPresent')}</div>
          </div>
          <div class="stat-card absent">
            <div class="stat-num">${detail.absentCount}</div>
            <div class="stat-lbl">${t('statusAbsent')}</div>
          </div>
          <div class="stat-card excused">
            <div class="stat-num">${detail.excusedCount}</div>
            <div class="stat-lbl">${t('statusExcused')}</div>
          </div>
        </div>

        <div style="display:flex; gap:8px;">
          <button type="button" class="btn-primary" style="flex:2;" onclick="App.openJournalFromDirector('${selectedClassId}')">
            ${t('btnOpenJournal')}
          </button>
          <button type="button" class="btn-secondary" style="flex:1;" onclick="App.toggleDirectorClassStudents()">
            ${t('btnClassStudents')}
          </button>
        </div>

        <div id="dir-class-students-list" style="display:none; margin-top:14px; border-top:1px dashed var(--border); padding-top:12px;">
          ${detail.students.map((st, i) => `
            <div style="display:flex; justify-content:space-between; align-items:center; padding:6px 0; border-bottom:1px solid #F1F5F9;">
              <div style="font-size:12px; font-weight:800;">
                ${i + 1}. ${st.lastName} ${st.firstName}
                ${st.phone ? `<a href="tel:${st.phone}" style="margin-left:6px; color:var(--primary); text-decoration:none; font-size:11px;">📞</a>` : ''}
              </div>
              <span style="font-size:10px; font-weight:800; padding:2px 6px; border-radius:4px; ${st.status === 'present' ? 'background:var(--present-bg);color:var(--present);' : (st.status === 'excused' ? 'background:var(--excused-bg);color:var(--excused);' : 'background:var(--absent-bg);color:var(--absent);')}">
                ${st.status === 'present' ? '✅ ' + t('statusPresent') : (st.status === 'excused' ? '🟡 ' + t('statusExcused') : '❌ ' + t('statusAbsent'))}
              </span>
            </div>
          `).join('')}
        </div>
      </div>
    `;
  }

  function toggleDirectorClassStudents() {
    const el = document.getElementById('dir-class-students-list');
    if (el) {
      el.style.display = (el.style.display === 'none') ? 'block' : 'none';
    }
  }

  // Pending Join Requests for Director
  function renderPendingRequests() {
    const box = document.getElementById('dir-pending-requests-box');
    const list = document.getElementById('dir-pending-requests-list');
    if (!box || !list) return;

    const reqs = SchoolManager.getPendingJoinRequests(currentSchool.code);
    if (reqs.length === 0) {
      box.style.display = 'none';
      return;
    }

    box.style.display = 'block';
    list.innerHTML = '';

    reqs.forEach(r => {
      const card = document.createElement('div');
      card.style.background = '#EFF6FF';
      card.style.border = '1px solid #BFDBFE';
      card.style.borderRadius = '10px';
      card.style.padding = '10px 12px';
      card.style.marginBottom = '8px';

      const roleStr = r.role === 'teacher' ? t('roleTeacher') : t('roleStarosta');
      card.innerHTML = `
        <div style="display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:8px;">
          <div>
            <div style="font-size:13px; font-weight:900; color:#1E3A8A;">${r.name} (${roleStr})</div>
            <div style="font-size:11px; color:#3B82F6;">Sinf: <strong>${r.classId}</strong> • 📞 ${r.phone || '-'} • ✉️ ${r.email}</div>
          </div>
        </div>
        <div style="display:flex; gap:6px;">
          <button type="button" class="btn-primary" style="height:32px; font-size:11px; background:#16A34A;" onclick="App.approveRequest('${r.id}')">${t('btnApprove')}</button>
          <button type="button" class="btn-secondary" style="height:32px; font-size:11px; color:#DC2626;" onclick="App.rejectRequest('${r.id}')">${t('btnReject')}</button>
        </div>
      `;
      list.appendChild(card);
    });
  }

  function approveRequest(reqId) {
    SchoolManager.approveJoinRequest(reqId);
    showToast(t('toastApproved'));
    renderPendingRequests();
    renderTeachersWindow();
    renderSelectedClassCard();
  }

  function rejectRequest(reqId) {
    SchoolManager.rejectJoinRequest(reqId);
    showToast(t('toastRejected'));
    renderPendingRequests();
    renderTeachersWindow();
  }

  // ──────────────────────────────────────────────
  // INVITATION LINKS SYSTEM (Group links / Single-use)
  // ──────────────────────────────────────────────

  function openCreateInviteModal() {
    if (!currentSchool) return;
    const roleEl = document.getElementById('inp-invite-role');
    if (roleEl) roleEl.value = 'teacher_group';
    const durEl = document.getElementById('inp-invite-duration');
    if (durEl) durEl.value = '72';
    const grp = document.getElementById('grp-invite-class');
    if (grp) grp.style.display = 'none';

    // Populate class selector
    const classSel = document.getElementById('inp-invite-class');
    if (classSel) {
      classSel.innerHTML = '';
      const classes = DB.getClassesBySchool(currentSchool.code);
      classes.forEach(c => {
        const opt = document.createElement('option');
        opt.value = c.classId;
        opt.textContent = `${c.classId}-sinf`;
        classSel.appendChild(opt);
      });
    }

    document.getElementById('invite-generator-inputs').style.display = 'block';
    document.getElementById('invite-generator-result').style.display = 'none';
    document.getElementById('modal-create-invite').classList.add('open');
  }

  function closeCreateInviteModal() {
    document.getElementById('modal-create-invite').classList.remove('open');
  }

  function handleInviteRoleChange() {
    const roleChoice = document.getElementById('inp-invite-role').value;
    const grp = document.getElementById('grp-invite-class');
    if (grp) {
      grp.style.display = (roleChoice === 'starosta') ? 'block' : 'none';
    }
  }

  function generateNewInvite() {
    if (!currentSchool || !currentSession) return;
    const roleChoice = document.getElementById('inp-invite-role').value;
    const durationHours = parseInt(document.getElementById('inp-invite-duration').value) || 72;

    let role = 'teacher';
    let isGroup = true;
    let classId = selectedClassId || '10-A';

    if (roleChoice === 'teacher_group') {
      role = 'teacher';
      isGroup = true;
    } else if (roleChoice === 'teacher_single') {
      role = 'teacher';
      isGroup = false;
    } else if (roleChoice === 'starosta') {
      role = 'starosta';
      isGroup = false;
      const cEl = document.getElementById('inp-invite-class');
      classId = cEl ? cEl.value : '10-A';
    }

    const invite = DB.createInvite({
      schoolCode: currentSchool.code,
      role: role,
      classId: classId,
      createdByName: currentSession.name,
      isGroup: isGroup,
      durationHours: durationHours
    });

    lastGeneratedInvite = invite;

    // Show URL in result box
    const dispUrl = `Jurnal.app/join/${invite.token}`;
    document.getElementById('disp-invite-url').textContent = dispUrl;

    const noticeEl = document.getElementById('disp-invite-notice');
    if (noticeEl) {
      if (isGroup) {
        noticeEl.textContent = currentLang === 'uz'
          ? "Ushbu havolani o'qituvchilarning Telegram guruhiga tashlang (barcha o'qituvchilar ulanadi):"
          : "Отправьте эту ссылку в Telegram-чат учителей (все учителя смогут войти):";
      } else {
        noticeEl.textContent = currentLang === 'uz'
          ? "Ushbu shaxsiy havolani yuboring:"
          : "Отправьте эту персональную ссылку:";
      }
    }

    document.getElementById('invite-generator-inputs').style.display = 'none';
    document.getElementById('invite-generator-result').style.display = 'block';

    showToast(t('toastInviteCreated'));
    renderActiveInvites();
  }

  function formatInviteTelegramMessage(invite, school) {
    const link = `https://jurnal.app/join/${invite.token}`;

    if (invite.isGroup) {
      if (currentLang === 'uz') {
        return `🏫 ${school.name}\n📍 ${school.city}\n\nҲурматли устозлар! Барча ўқитувчилар учун мактаб электрон журналига уланиш ҳаволаси:\n\nҲар бир ўқитувчи ушбу ҳавола орқали рўйхатдан ўтиб, ўз синфини танласин.\n\nҲавола:\n${link}\n\n(Аризангиз юборилгач, директор тасдиқлайди)`;
      } else {
        return `🏫 ${school.name}\n📍 ${school.city}\n\nУважаемые учителя! Общая ссылка для подключения к электронному школьному журналу:\n\nКаждый учитель переходит по ссылке, заполняет свои данные и выбирает класс.\n\nСсылка:\n${link}\n\n(После отправки заявки директор подтверждает доступ)`;
      }
    }

    const roleTitle = invite.role === 'teacher'
      ? (currentLang === 'uz' ? "O'qituvchi" : "Учитель")
      : (currentLang === 'uz' ? `Sinf sardori (${invite.classId})` : `Староста класса (${invite.classId})`);

    if (currentLang === 'uz') {
      return `🏫 ${school.name}\n📍 ${school.city}\n\nAssalomu alaykum! Sizni maktab elektron jurnal tizimiga taklif qilamiz.\n\n👤 Rol: ${roleTitle}\n\nQuyidagi havola orqali ro'yxatdan o'ting:\n${link}`;
    } else {
      return `🏫 ${school.name}\n📍 ${school.city}\n\nЗдравствуйте! Вас пригласил директор школы в систему электронного журнала.\n\n👤 Роль: ${roleTitle}\n\nПерейдите по ссылке для регистрации:\n${link}`;
    }
  }

  function shareInviteTelegram() {
    if (!lastGeneratedInvite || !currentSchool) return;
    const msg = formatInviteTelegramMessage(lastGeneratedInvite, currentSchool);
    const link = `https://jurnal.app/join/${lastGeneratedInvite.token}`;
    const url = `https://t.me/share/url?url=${encodeURIComponent(link)}&text=${encodeURIComponent(msg)}`;
    window.open(url, '_blank');
  }

  function shareInviteTelegramByToken(token) {
    const inv = DB.getInviteByToken(token);
    if (!inv || !currentSchool) return;
    const msg = formatInviteTelegramMessage(inv, currentSchool);
    const link = `https://jurnal.app/join/${inv.token}`;
    const url = `https://t.me/share/url?url=${encodeURIComponent(link)}&text=${encodeURIComponent(msg)}`;
    window.open(url, '_blank');
  }

  function copyInviteUrl() {
    if (!lastGeneratedInvite) return;
    const link = `https://jurnal.app/join/${lastGeneratedInvite.token}`;
    navigator.clipboard.writeText(link);
    showToast(t('toastInviteCopied'));
  }

  function copyInviteUrlByToken(token) {
    const link = `https://jurnal.app/join/${token}`;
    navigator.clipboard.writeText(link);
    showToast(t('toastInviteCopied'));
  }

  function cancelInviteAction(token) {
    DB.cancelInvite(token);
    showToast(t('toastInviteCancelled'));
    renderActiveInvites();
  }

  function renderActiveInvites() {
    const box = document.getElementById('dir-active-invites-box');
    const list = document.getElementById('dir-active-invites-list');
    const countEl = document.getElementById('dir-active-invites-count');
    if (!box || !list || !currentSchool) return;

    const invites = DB.getInvitesBySchool(currentSchool.code);
    if (!invites || invites.length === 0) {
      box.style.display = 'none';
      return;
    }

    box.style.display = 'block';
    if (countEl) countEl.textContent = `${invites.length} ta`;
    list.innerHTML = '';

    const now = Date.now();
    invites.slice(0, 10).forEach(inv => {
      const card = document.createElement('div');
      card.style.background = inv.status === 'active' ? '#F8FAFC' : '#F1F5F9';
      card.style.border = inv.status === 'active' ? '1px solid #CBD5E1' : '1px solid #E2E8F0';
      card.style.borderRadius = '10px';
      card.style.padding = '10px 12px';
      card.style.marginBottom = '8px';

      const typeLabel = inv.isGroup
        ? (currentLang === 'uz' ? "👥 O'qituvchilar guruhi uchun umumiy havola" : "👥 Общая ссылка для учителей")
        : (inv.role === 'teacher' ? t('roleTeacher') : `${t('roleStarosta')} (${inv.classId})`);

      const usesCount = inv.usesCount || 0;
      const joinedCountText = inv.isGroup
        ? (currentLang === 'uz' ? ` • 👥 ${usesCount} nafar ulandi` : ` • 👥 ${usesCount} учителей вступило`)
        : '';
      
      let statusBadge = '';
      let actionButtons = '';
      let remainingText = '';

      if (inv.status === 'active') {
        const msLeft = inv.expiresTimestamp - now;
        const hoursLeft = Math.max(0, Math.ceil(msLeft / (1000 * 60 * 60)));
        const daysLeft = Math.floor(hoursLeft / 24);
        remainingText = daysLeft > 0
          ? (currentLang === 'uz' ? `⏱ ${daysLeft} kun qoldi` : `⏱ осталось ${daysLeft} дн.`)
          : (currentLang === 'uz' ? `⏱ ${hoursLeft} soat qoldi` : `⏱ осталось ${hoursLeft} ч.`);

        statusBadge = `<span style="font-size:10px; font-weight:800; padding:2px 6px; border-radius:4px; background:#DCFCE7; color:#15803D;">● ${t('lblInviteActive')}</span>`;
        actionButtons = `
          <div style="display:flex; gap:6px; margin-top:8px;">
            <button type="button" class="btn-secondary" style="height:30px; font-size:11px; padding:0 8px;" onclick="App.copyInviteUrlByToken('${inv.token}')">📋 ${t('btnCopyLink')}</button>
            <button type="button" class="btn-secondary" style="height:30px; font-size:11px; padding:0 8px; color:#0284C7;" onclick="App.shareInviteTelegramByToken('${inv.token}')">✈️ Telegram</button>
            <button type="button" class="btn-secondary" style="height:30px; font-size:11px; padding:0 8px; color:#DC2626;" onclick="App.cancelInviteAction('${inv.token}')">${t('btnCancelInvite')}</button>
          </div>
        `;
      } else if (inv.status === 'used') {
        statusBadge = `<span style="font-size:10px; font-weight:800; padding:2px 6px; border-radius:4px; background:#E2E8F0; color:#475569;">✓ ${t('lblInviteUsed')}</span>`;
      } else if (inv.status === 'expired') {
        statusBadge = `<span style="font-size:10px; font-weight:800; padding:2px 6px; border-radius:4px; background:#FEF3C7; color:#B45309;">⏱ ${t('lblInviteExpired')}</span>`;
      } else if (inv.status === 'cancelled') {
        statusBadge = `<span style="font-size:10px; font-weight:800; padding:2px 6px; border-radius:4px; background:#FEE2E2; color:#B91C1C;">✕ ${t('lblInviteCancelled')}</span>`;
      }

      card.innerHTML = `
        <div style="display:flex; justify-content:space-between; align-items:center;">
          <div>
            <div style="font-family:monospace; font-weight:900; font-size:13px; color:#1E3A8A; letter-spacing:0.5px;">
              ${inv.token}
            </div>
            <div style="font-size:11px; color:#64748B; margin-top:2px;">
              ${typeLabel}${joinedCountText} • ${remainingText}
            </div>
          </div>
          <div>${statusBadge}</div>
        </div>
        ${actionButtons}
      `;
      list.appendChild(card);
    });
  }

  // Invitee Screen Experience
  function openInviteScreen(token) {
    if (!token) return;
    const cleanToken = token.trim().toUpperCase();
    const invite = DB.getInviteByToken(cleanToken);

    const errBanner = document.getElementById('invite-error-banner');
    const formContainer = document.getElementById('invite-form-container');
    const schoolNameEl = document.getElementById('invite-school-name');
    const schoolLocEl = document.getElementById('invite-school-location');
    const roleBadgeEl = document.getElementById('invite-role-badge');
    const noticeEl = document.getElementById('invite-director-notice');
    const btnSubmit = document.getElementById('btn-submit-invite-reg');

    switchScreen('screen-invite');

    if (!invite) {
      if (errBanner) {
        errBanner.textContent = t('errInviteInvalid');
        errBanner.style.display = 'block';
      }
      if (formContainer) formContainer.style.display = 'none';
      return;
    }

    if (invite.status === 'used') {
      if (errBanner) {
        errBanner.textContent = t('errInviteAlreadyUsed');
        errBanner.style.display = 'block';
      }
      if (formContainer) formContainer.style.display = 'none';
      return;
    }

    if (invite.status === 'expired') {
      if (errBanner) {
        errBanner.textContent = t('errInviteExpiredMsg');
        errBanner.style.display = 'block';
      }
      if (formContainer) formContainer.style.display = 'none';
      return;
    }

    if (invite.status === 'cancelled') {
      if (errBanner) {
        errBanner.textContent = t('errInviteCancelledMsg');
        errBanner.style.display = 'block';
      }
      if (formContainer) formContainer.style.display = 'none';
      return;
    }

    activeInvite = invite;
    if (errBanner) errBanner.style.display = 'none';
    if (formContainer) formContainer.style.display = 'block';

    const school = DB.getSchoolByCode(invite.schoolCode);
    if (school) {
      if (schoolNameEl) schoolNameEl.textContent = school.name;
      if (schoolLocEl) schoolLocEl.textContent = `📍 ${school.region}, ${school.city}`;
    }

    // Populate classes dropdown for teacher
    const classGrp = document.getElementById('grp-inv-reg-class');
    const classSel = document.getElementById('inv-reg-class');
    if (classSel && school) {
      classSel.innerHTML = '';
      const classes = DB.getClassesBySchool(school.code);
      classes.forEach(c => {
        const opt = document.createElement('option');
        opt.value = c.classId;
        opt.textContent = `${c.classId}-sinf`;
        if (c.classId === (invite.classId || '10-A')) opt.selected = true;
        classSel.appendChild(opt);
      });
    }

    if (invite.role === 'teacher') {
      if (classGrp) classGrp.style.display = 'block';
    } else {
      if (classGrp) classGrp.style.display = 'none';
    }

    if (roleBadgeEl) {
      if (invite.isGroup) {
        roleBadgeEl.textContent = currentLang === 'uz'
          ? "👥 O'qituvchilar uchun umumiy havola"
          : "👥 Общая ссылка для учителей";
      } else if (invite.role === 'teacher') {
        roleBadgeEl.textContent = currentLang === 'uz'
          ? "👨‍🏫 O'qituvchi sifatida taklif"
          : "👨‍🏫 Приглашение в качестве учителя";
      } else {
        roleBadgeEl.textContent = currentLang === 'uz'
          ? `🎓 Sinf sardori (${invite.classId}) sifatida taklif`
          : `🎓 Приглашение: Староста (${invite.classId})`;
      }
    }

    if (noticeEl) {
      noticeEl.textContent = currentLang === 'uz'
        ? `Sizni maktab direktori (${invite.createdByName || 'Direktor'}) taklif qildi.`
        : `Вас пригласил директор школы (${invite.createdByName || 'Директор'}).`;
    }

    if (btnSubmit) {
      btnSubmit.textContent = invite.role === 'teacher'
        ? (currentLang === 'uz' ? "👨‍🏫 O'qituvchi sifatida qo'shilish" : "👨‍🏫 Присоединиться как учитель")
        : (currentLang === 'uz' ? `🎓 Sardor (${invite.classId}) sifatida qo'shilish` : `🎓 Присоединиться как староста (${invite.classId})`);
    }

    const footerNote = document.getElementById('invite-type-footer-note');
    if (footerNote) {
      if (invite.isGroup) {
        footerNote.textContent = currentLang === 'uz'
          ? "👥 O'qituvchilar guruhi uchun umumiy havola • Direktor tasdiqlashi bilan"
          : "👥 Общая ссылка для группы учителей • С подтверждением директора";
      } else {
        footerNote.textContent = currentLang === 'uz'
          ? "⏱ Bir martalik shaxsiy taklifnoma"
          : "⏱ Одноразовое персональное приглашение";
      }
    }

    // Reset input fields
    const fn = document.getElementById('inv-reg-fullname');
    const ph = document.getElementById('inv-reg-phone');
    const em = document.getElementById('inv-reg-email');
    const pw = document.getElementById('inv-reg-password');
    const pwc = document.getElementById('inv-reg-password-confirm');
    if (fn) fn.value = '';
    if (ph) ph.value = '';
    if (em) em.value = '';
    if (pw) pw.value = '';
    if (pwc) pwc.value = '';
  }

  function cancelInviteFlow() {
    activeInvite = null;
    try {
      if (window.history && window.history.replaceState) {
        window.history.replaceState(null, '', window.location.pathname);
      }
    } catch (e) {}

    if (currentSession && currentSchool) {
      enterAuthenticatedState();
    } else {
      switchScreen('screen-auth');
      switchAuthTab('login');
    }
  }

  let lastSavedInviteCreds = null;

  async function handleInviteSubmit() {
    if (!activeInvite) return;
    const fullName = (document.getElementById('inv-reg-fullname').value || '').trim();
    const usernameEl = document.getElementById('inv-reg-username');
    const username = usernameEl ? usernameEl.value.trim() : '';
    const phone = (document.getElementById('inv-reg-phone').value || '').trim();
    const email = (document.getElementById('inv-reg-email').value || '').trim();
    const password = document.getElementById('inv-reg-password').value;
    const passwordConfirm = document.getElementById('inv-reg-password-confirm').value;

    const classIdEl = document.getElementById('inv-reg-class');
    const classId = (classIdEl && classIdEl.value) ? classIdEl.value : (activeInvite.classId || '10-A');

    if (!fullName || !email || !password) {
      alert(t('errFillAllFields'));
      return;
    }
    if (password.length < 6) {
      alert(t('errPasswordTooShort'));
      return;
    }
    if (password !== passwordConfirm) {
      alert(t('errPasswordMismatch'));
      return;
    }

    try {
      const res = await Auth.acceptInviteAndRegister({
        token: activeInvite.token,
        fullName,
        username,
        phone,
        email,
        password,
        classId
      });

      lastSavedInviteCreds = {
        fullName,
        username,
        email,
        phone,
        password,
        schoolName: (res.school && res.school.name) || '14-maktab',
        schoolCode: (res.school && res.school.code) || 'TERMIZ-14-7K29'
      };

      const dispLogin = document.getElementById('saved-cred-login');
      if (dispLogin) dispLogin.textContent = email || username || phone;
      const dispPhone = document.getElementById('saved-cred-phone');
      if (dispPhone) dispPhone.textContent = phone || '-';
      const dispPass = document.getElementById('saved-cred-pass');
      if (dispPass) dispPass.textContent = password;

      const modalSuccess = document.getElementById('modal-invite-saved-success');
      if (modalSuccess) {
        modalSuccess.classList.add('open');
      } else {
        alert(currentLang === 'uz' ? "Ro'yxatdan o'tish muvaffaqiyatli saqlandi!" : "Регистрация успешно сохранена!");
        proceedToLoginWithSavedCreds();
      }

      showToast(t('toastInviteSubmitted'));
    } catch (e) {
      alert(e.message);
    }
  }

  function proceedToLoginWithSavedCreds() {
    const modal = document.getElementById('modal-invite-saved-success');
    if (modal) modal.classList.remove('open');
    cancelInviteFlow();
    switchAuthTab('login');
    if (lastSavedInviteCreds) {
      const codeEl = document.getElementById('login-school-code');
      if (codeEl && lastSavedInviteCreds.schoolCode) codeEl.value = lastSavedInviteCreds.schoolCode;
      const identEl = document.getElementById('login-ident');
      if (identEl) identEl.value = lastSavedInviteCreds.email || lastSavedInviteCreds.username || lastSavedInviteCreds.phone;
      const passEl = document.getElementById('login-password');
      if (passEl) passEl.value = lastSavedInviteCreds.password;
    }
    showToast(currentLang === 'uz' ? 'Ma\'lumotlar to\'ldirildi! "Tizimga kirish" tugmasini bosing' : 'Данные заполнены! Нажмите "Войти в систему"');
  }

  function copySavedInviteCreds() {
    if (!lastSavedInviteCreds) return;
    const text = `Maktab kodi: ${lastSavedInviteCreds.schoolCode}\nLogin: ${lastSavedInviteCreds.email || lastSavedInviteCreds.username}\nParol: ${lastSavedInviteCreds.password}\nTel: ${lastSavedInviteCreds.phone || ''}`;
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(() => {
        showToast(currentLang === 'uz' ? 'Ma\'lumotlar nusxalandi!' : 'Данные скопированы!');
      }).catch(() => {
        prompt("Nusxalang:", text);
      });
    } else {
      prompt("Nusxalang:", text);
    }
  }

  // Enter Invite Code Modal (on login screen)
  function openEnterInviteModal() {
    document.getElementById('inp-enter-invite-token').value = '';
    document.getElementById('modal-enter-invite').classList.add('open');
  }

  function closeEnterInviteModal() {
    document.getElementById('modal-enter-invite').classList.remove('open');
  }

  function submitEnterInviteToken() {
    let raw = (document.getElementById('inp-enter-invite-token').value || '').trim();
    if (!raw) {
      alert(t('errFillAllFields'));
      return;
    }
    // Extract token if user pasted full URL
    if (raw.includes('/join/')) {
      raw = raw.split('/join/')[1];
    } else if (raw.includes('invite=')) {
      raw = raw.split('invite=')[1];
    }
    raw = raw.replace(/[^A-Za-z0-9\-]/g, '');

    closeEnterInviteModal();
    openInviteScreen(raw);
  }

  // Reports Feed for Director
  function renderReportsFeed() {
    const list = document.getElementById('dir-reports-list');
    if (!list) return;

    const reports = DB.getReportsBySchool(currentSchool.code);
    if (reports.length === 0) {
      list.innerHTML = `<div style="text-align:center; padding:16px; color:var(--text-muted); font-size:12px;">Hozircha hisobotlar mavjud emas</div>`;
      return;
    }

    list.innerHTML = '';
    reports.forEach(r => {
      const card = document.createElement('div');
      card.style.background = '#FFFFFF';
      card.style.border = '1px solid var(--border)';
      card.style.borderRadius = '12px';
      card.style.padding = '12px';
      card.style.marginBottom = '8px';

      card.innerHTML = `
        <div style="display:flex; justify-content:space-between; margin-bottom:6px;">
          <span style="font-weight:900; font-size:13px;">${r.classId} SINF HISOBOTI (${r.dateDisplay || r.date})</span>
          <span style="font-size:10px; color:var(--text-muted);">${new Date(r.sentAt).toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'})}</span>
        </div>
        <div style="font-size:11px; color:var(--text-muted); margin-bottom:6px;">
          👤 Yuboruvchi: <strong>${r.senderName}</strong> (${r.senderRole})
        </div>
        <div style="font-size:11px; background:#F8FAFC; padding:6px; border-radius:6px; margin-bottom:8px; line-height:1.4;">
          ✅ Darsda: ${r.presentCount} | ❌ Kelmadi: ${r.absentCount + r.excusedCount} ${r.lateCount > 0 ? '| ⏰ Kechikdi: ' + r.lateCount : ''}
          ${r.excusedList && r.excusedList.length > 0 ? '<div style="color:var(--excused);margin-top:4px;">🟡 Sababli: ' + r.excusedList.map(e => e.name).join(', ') + '</div>' : ''}
        </div>
        <div style="display:flex; gap:6px;">
          <button type="button" class="btn-secondary" style="height:30px; font-size:11px;" onclick="App.copyReportText('${r.id}')">📋 Nusxa olish</button>
          <button type="button" class="btn-secondary" style="height:30px; font-size:11px; color:#0284C7;" onclick="App.shareReportTelegram('${r.id}')">✈️ Telegram</button>
        </div>
      `;
      list.appendChild(card);
    });
  }

  function copyReportText(reportId) {
    if (!currentSchool) return;
    const reports = DB.getReportsBySchool(currentSchool.code);
    const r = reports.find(x => x.id === reportId);
    if (r && r.reportText) {
      navigator.clipboard.writeText(r.reportText);
      showToast(t('toastSaved'));
    }
  }

  function shareReportTelegram(reportId) {
    if (!currentSchool) return;
    const reports = DB.getReportsBySchool(currentSchool.code);
    const r = reports.find(x => x.id === reportId);
    if (r && r.reportText) {
      window.open('https://t.me/share/url?text=' + encodeURIComponent(r.reportText), '_blank');
    }
  }

  // 8. Render Journal View (Teacher / Starosta / Director Inspect)
  function renderJournal() {
    const isDirector = (currentSession && currentSession.role === 'director');
    const isStarosta = (currentSession && currentSession.role === 'starosta');

    // Return button for Director
    const returnBar = document.getElementById('journal-dir-return-bar');
    if (returnBar) {
      returnBar.style.display = isDirector ? 'flex' : 'none';
    }

    // Class and Date
    document.getElementById('journal-class-badge').textContent = selectedClassId;
    document.getElementById('journal-date-text').textContent = getDateDisplay(currentDayOffset);

    // Load Class details and student rows
    const dateStr = getDateString(currentDayOffset);
    const detail = SchoolManager.getClassDetail(currentSchool.code, selectedClassId, dateStr);

    document.getElementById('journal-stat-total').textContent = detail.totalStudents;
    document.getElementById('journal-stat-present').textContent = detail.presentCount;
    document.getElementById('journal-stat-absent').textContent = detail.absentCount;
    document.getElementById('journal-stat-excused').textContent = detail.excusedCount;

    const container = document.getElementById('journal-students-list');
    container.innerHTML = '';

    if (detail.students.length === 0) {
      container.innerHTML = `
        <div class="classes-empty-state" style="padding:28px 16px; margin:8px 0;">
          <div class="classes-empty-icon" style="width:52px; height:52px;">
            <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="#2563EB" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/></svg>
          </div>
          <div class="classes-empty-title" style="font-size:14px;">${currentLang === 'uz' ? 'O\'quvchilar ro\'yxati bo\'sh' : 'Список учеников пуст'}</div>
          <div class="classes-empty-desc" style="font-size:11.5px;">${currentLang === 'uz' ? 'Ushbu sinfga o\'quvchi qo\'shish uchun "Yangi o\'quvchi" tugmasini bosing.' : 'Нажмите "Новый ученик", чтобы добавить учеников в этот класс.'}</div>
        </div>
      `;
      return;
    }

    detail.students.forEach((st, idx) => {
      const card = document.createElement('div');
      card.className = 'student-row-card';

      card.innerHTML = `
        <div class="student-info-line">
          <div class="student-name">
            ${idx + 1}. ${st.lastName} ${st.firstName}
            ${st.phone ? `<a href="tel:${st.phone}" class="student-phone-link" style="margin-left:6px; font-weight:700; display:inline-flex; align-items:center; gap:3px;"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg> ${st.phone}</a>` : ''}
            ${st.parentPhone ? `<span style="font-size:11px; color:#059669; font-weight:700; margin-left:6px; display:inline-flex; align-items:center; gap:3px;" title="${currentLang === 'uz' ? 'Ota-onasi' : 'Родители'}"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg> ${st.parentPhone}</span>` : ''}
          </div>
          ${!isStarosta ? `<button type="button" class="btn-icon-subtle" style="border:none;background:transparent;color:#EF4444;padding:4px;cursor:pointer;display:inline-flex;align-items:center;" onclick="App.confirmDeleteStudent('${st.id}')" title="${currentLang === 'uz' ? 'O\'chirish' : 'Удалить'}"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg></button>` : ''}
        </div>

        <div class="att-actions-grid">
          <button type="button" class="att-btn present ${st.status === 'present' ? 'active' : ''}" onclick="App.setStudentStatus('${st.id}', 'present')">
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
            <span>${t('statusPresent')}</span>
          </button>
          <button type="button" class="att-btn absent ${st.status === 'absent' ? 'active' : ''}" onclick="App.openAttendanceReasonModal('${st.id}', 'absent')">
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
            <span>${t('statusAbsent')}</span>
          </button>
          <button type="button" class="att-btn late ${st.status === 'late' ? 'active' : ''}" onclick="App.openAttendanceReasonModal('${st.id}', 'late')">
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
            <span>${t('statusLate')}</span>
          </button>
          <button type="button" class="att-btn excused ${st.status === 'excused' ? 'active' : ''}" onclick="App.openAttendanceReasonModal('${st.id}', 'excused')">
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
            <span>${t('statusExcused')}</span>
          </button>
        </div>

        ${st.reason ? `<div style="font-size:11px; color:var(--text-muted); font-weight:700; margin-top:4px;">
          ${st.status === 'late' ? '⏰ Kechikish sababi:' : '🟡 Sababi:'} <span style="color:var(--text-main); font-weight:800;">${st.reason}</span> ${st.note ? '(' + st.note + ')' : ''}
        </div>` : ''}
      `;
      container.appendChild(card);
    });
  }

  function setStudentStatus(studentId, status, reason = '', note = '') {
    const dateStr = getDateString(currentDayOffset);
    AttendanceManager.setStudentStatus(currentSchool.code, selectedClassId, studentId, dateStr, status, reason, note);
    renderJournal();
    showToast(t('toastSaved'));
  }

  function markAllPresent() {
    const dateStr = getDateString(currentDayOffset);
    AttendanceManager.markAllPresent(currentSchool.code, selectedClassId, dateStr);
    renderJournal();
    showToast(t('toastSaved'));
  }

  function shiftDate(delta) {
    currentDayOffset += delta;
    renderJournal();
  }

  function openJournalFromDirector(classId) {
    selectedClassId = classId;
    switchScreen('screen-journal');
    renderJournal();
  }

  function returnToDirectorDashboard() {
    switchScreen('screen-director');
    renderDirectorDashboard();
  }

  // Reason Modal & Status Handler (Late, Absent, Excused)
  let activeStudentForAttendance = null;
  let activeStatusForReason = 'absent';

  function openAttendanceReasonModal(studentId, status = 'absent') {
    activeStudentForAttendance = studentId;
    activeStatusForReason = status;
    activeStudentForReason = studentId;

    const modal = document.getElementById('modal-attendance-reason') || document.getElementById('modal-reason');
    if (!modal) return;

    const st = DB.getStudents().find(s => s.id === studentId);
    const nameDisp = document.getElementById('reason-modal-student-name');
    if (nameDisp && st) {
      nameDisp.textContent = `${currentLang === 'uz' ? 'O\'quvchi' : 'Ученик'}: ${st.lastName} ${st.firstName}`;
    }

    const titleDisp = document.getElementById('reason-modal-title');
    if (titleDisp) {
      if (status === 'late') {
        titleDisp.textContent = currentLang === 'uz' ? '⏰ Darsga kechikish sababi' : '⏰ Причина опоздания на урок';
      } else {
        titleDisp.textContent = currentLang === 'uz' ? '❌ Dars qoldirish sababi' : '❌ Причина отсутствия';
      }
    }

    const inp = document.getElementById('inp-reason-text');
    if (inp) inp.value = '';

    document.querySelectorAll('.reason-chip').forEach(c => c.classList.remove('selected'));
    modal.classList.add('open');
  }

  function selectReasonChip(el, text) {
    document.querySelectorAll('.reason-chip').forEach(c => c.classList.remove('selected'));
    if (el) el.classList.add('selected');
    const inp = document.getElementById('inp-reason-text');
    if (inp) inp.value = text;
  }

  function saveAttendanceReason() {
    if (!activeStudentForAttendance) return;
    const inp = document.getElementById('inp-reason-text');
    const reasonText = (inp ? inp.value : '').trim() || (activeStatusForReason === 'late' 
      ? (currentLang === 'uz' ? 'Kechikdi' : 'Опоздал') 
      : (currentLang === 'uz' ? 'Kelmadi' : 'Не пришел'));

    setStudentStatus(activeStudentForAttendance, activeStatusForReason, reasonText);
    closeReasonModal();
  }

  function openReasonModal(studentId) {
    openAttendanceReasonModal(studentId, 'excused');
  }

  function closeReasonModal() {
    const modal1 = document.getElementById('modal-attendance-reason');
    if (modal1) modal1.classList.remove('open');
    const modal2 = document.getElementById('modal-reason');
    if (modal2) modal2.classList.remove('open');
    activeStudentForAttendance = null;
    activeStudentForReason = null;
  }

  function saveReason() {
    saveAttendanceReason();
  }

  // Add Student Modal (with Student Phone & Parent Phone)
  function openAddStudentModal() {
    const last = document.getElementById('inp-std-lastname') || document.getElementById('inp-std-last');
    const first = document.getElementById('inp-std-firstname') || document.getElementById('inp-std-first');
    const phone = document.getElementById('inp-std-phone');
    const parentPhone = document.getElementById('inp-std-parent-phone');

    if (last) last.value = '';
    if (first) first.value = '';
    if (phone) phone.value = '';
    if (parentPhone) parentPhone.value = '';

    const modal = document.getElementById('modal-add-student-phone') || document.getElementById('modal-add-student');
    if (modal) modal.classList.add('open');
  }

  function closeAddStudentModal() {
    const modal1 = document.getElementById('modal-add-student-phone');
    if (modal1) modal1.classList.remove('open');
    const modal2 = document.getElementById('modal-add-student');
    if (modal2) modal2.classList.remove('open');
  }

  function saveNewStudentFromModal() {
    const last = (document.getElementById('inp-std-lastname')?.value || document.getElementById('inp-std-last')?.value || '').trim();
    const first = (document.getElementById('inp-std-firstname')?.value || document.getElementById('inp-std-first')?.value || '').trim();
    const phone = (document.getElementById('inp-std-phone')?.value || '').trim();
    const parentPhone = (document.getElementById('inp-std-parent-phone')?.value || '').trim();

    if (!last || !first) {
      alert(currentLang === 'uz' ? 'Iltimos, o\'quvchining familiyasi va ismini kiriting!' : 'Пожалуйста, укажите фамилию и имя ученика!');
      return;
    }

    try {
      AttendanceManager.addStudent(currentSchool.code, selectedClassId, last, first, phone, parentPhone);
      closeAddStudentModal();
      if (currentSession && currentSession.role === 'director') {
        renderSelectedClassCard();
      } else {
        renderJournal();
      }
      showToast(t('toastStudentAdded'));
    } catch (e) {
      alert(e.message);
    }
  }

  function submitAddStudent() {
    saveNewStudentFromModal();
  }

  // iPhone PWA Guide Modal
  function openIphoneGuideModal() {
    const modal = document.getElementById('modal-iphone-guide');
    if (modal) modal.classList.add('open');
  }

  function closeIphoneGuideModal() {
    const modal = document.getElementById('modal-iphone-guide');
    if (modal) modal.classList.remove('open');
  }

  function confirmDeleteStudent(studentId) {
    if (confirm(t('confirmDeleteStudent'))) {
      DB.deleteStudent(studentId);
      renderJournal();
      showToast(t('toastStudentDeleted'));
    }
  }

  // Send Report
  function sendCurrentReport() {
    const dateStr = getDateString(currentDayOffset);
    const dateDisplay = getDateDisplay(currentDayOffset);
    const res = AttendanceManager.sendReport(currentSession, currentSchool, selectedClassId, dateStr, dateDisplay);
    showToast(t('toastReportSent'));
    return res;
  }

  function shareTelegram() {
    const res = sendCurrentReport();
    const url = `https://t.me/share/url?text=${encodeURIComponent(res.text)}`;
    window.open(url, '_blank');
  }

  // Add Class Modal (Director)
  function openAddClassModal() {
    document.getElementById('modal-add-class').classList.add('open');
  }

  function closeAddClassModal() {
    document.getElementById('modal-add-class').classList.remove('open');
  }

  function submitAddClass() {
    const grade = document.getElementById('inp-new-class-grade').value;
    const letter = document.getElementById('inp-new-class-letter').value;
    try {
      SchoolManager.addClass(currentSchool.code, grade, letter);
      closeAddClassModal();
      renderDirectorDashboard();
      showToast(t('toastSaved'));
    } catch (e) {
      alert(e.message);
    }
  }

  // Auth Submit Handlers
  async function handleRegisterSchool() {
    const region = document.getElementById('reg-region').value;
    const city = document.getElementById('reg-city').value;
    const number = document.getElementById('reg-number').value;
    const fullName = document.getElementById('reg-name').value;
    const directorName = document.getElementById('reg-dir-name').value;
    const directorPhone = document.getElementById('reg-dir-phone').value;
    const directorEmail = document.getElementById('reg-dir-email').value;
    const password = document.getElementById('reg-password').value;
    const passwordConfirm = document.getElementById('reg-password-confirm').value;

    try {
      const res = await Auth.registerSchool({
        region, city, number, fullName, directorName, directorPhone, directorEmail, password, passwordConfirm
      });
      currentSchool = res.school;
      currentSession = res.session;

      // Show generated code modal/banner
      document.getElementById('created-school-code').textContent = res.school.code;
      document.getElementById('modal-school-created').classList.add('open');
    } catch (e) {
      alert(e.message);
    }
  }

  function closeSchoolCreatedModal() {
    document.getElementById('modal-school-created').classList.remove('open');
    enterAuthenticatedState();
  }

  async function handleJoinSchool() {
    const schoolCode = document.getElementById('join-school-code').value;
    const role = document.getElementById('join-role').value;
    const fullName = document.getElementById('join-fullname').value;
    const phone = document.getElementById('join-phone').value;
    const email = document.getElementById('join-email').value;
    const password = document.getElementById('join-password').value;
    const classId = document.getElementById('join-class').value;

    try {
      await Auth.submitJoinRequest({
        schoolCode, role, fullName, phone, email, password, classId
      });
      alert(t('lblPendingApproval'));
      switchAuthTab('login');
      document.getElementById('login-school-code').value = schoolCode;
      document.getElementById('login-ident').value = email;
    } catch (e) {
      alert(e.message);
    }
  }

  async function handleLogin() {
    let schoolCode = (document.getElementById('login-school-code').value || '').trim();
    const ident = (document.getElementById('login-ident').value || '').trim();
    const pass = document.getElementById('login-password').value || '';

    if (!ident || !pass) {
      alert(currentLang === 'uz' ? 'Iltimos, login (email/telefon) va parolni kiriting!' : 'Пожалуйста, введите логин (email/телефон) и пароль!');
      return;
    }

    // If school code was not typed, auto-fill default school code
    if (!schoolCode) {
      const allSchools = DB.getSchools();
      schoolCode = (allSchools && allSchools.length > 0) ? allSchools[0].code : 'TERMIZ-14-7K29';
      document.getElementById('login-school-code').value = schoolCode;
    }

    try {
      const res = await Auth.login(schoolCode, ident, pass);
      currentSchool = res.school;
      currentSession = res.session;

      try {
        localStorage.setItem('jurnal_last_school_code', res.school.code);
        localStorage.setItem('jurnal_last_login_ident', ident);
      } catch (e) {}

      enterAuthenticatedState();
      showToast(currentLang === 'uz' ? `Xush kelibsiz, ${res.user.name}!` : `Добро пожаловать, ${res.user.name}!`);
    } catch (e) {
      alert(e.message);
    }
  }

  function openDirectorSetupModal() {
    const modal = document.getElementById('modal-director-setup');
    if (!modal) return;
    const sch = DB.getSchoolByCode('TERMIZ-14-7K29') || (DB.getSchools()[0]);
    const dirUser = DB.getUsers().find(u => u.role === 'director' && (!sch || u.schoolCode === sch.code));
    
    const inpName = document.getElementById('dir-setup-name');
    if (inpName) inpName.value = (sch && sch.directorName) || (dirUser && dirUser.name) || '';
    
    const inpEmail = document.getElementById('dir-setup-email');
    if (inpEmail) inpEmail.value = (sch && sch.directorEmail) || (dirUser && dirUser.email) || '';

    const inpPhone = document.getElementById('dir-setup-phone');
    if (inpPhone) inpPhone.value = (sch && sch.directorPhone) || (dirUser && dirUser.phone) || '';

    const inpPass = document.getElementById('dir-setup-password');
    if (inpPass) inpPass.value = '';

    const inpSch = document.getElementById('dir-setup-school-name');
    if (inpSch && sch) inpSch.value = sch.name || '14-sonli umumiy o\'rta ta\'lim maktabi';

    modal.classList.add('open');
  }

  function closeDirectorSetupModal() {
    const modal = document.getElementById('modal-director-setup');
    if (modal) modal.classList.remove('open');
  }

  async function submitDirectorSetup() {
    const name = (document.getElementById('dir-setup-name').value || '').trim();
    const email = (document.getElementById('dir-setup-email').value || '').trim();
    const phone = (document.getElementById('dir-setup-phone').value || '').trim();
    const password = document.getElementById('dir-setup-password').value || '';
    const schoolName = (document.getElementById('dir-setup-school-name').value || '').trim();

    if (!name) {
      alert(currentLang === 'uz' ? 'Iltimos, ism va familiyangizni kiriting!' : 'Пожалуйста, введите имя и фамилию!');
      return;
    }
    if (password && password.length < 6) {
      alert(t('errPasswordTooShort'));
      return;
    }

    try {
      let school = DB.getSchoolByCode('TERMIZ-14-7K29') || DB.getSchools()[0];
      if (!school) {
        await DB.init();
        school = DB.getSchoolByCode('TERMIZ-14-7K29');
      }

      if (school) {
        if (schoolName) school.name = schoolName;
        school.directorName = name;
        if (email) school.directorEmail = email;
        if (phone) school.directorPhone = phone;
        DB.saveSchool(school);
      }

      const users = DB.getUsers();
      let dirUser = users.find(u => u.role === 'director' && u.schoolCode === school.code);
      if (!dirUser) {
        dirUser = {
          id: 'dir_' + Date.now(),
          schoolCode: school.code,
          role: 'director',
          name: name,
          email: email || 'director@14maktab.uz',
          phone: phone || '+998901234567',
          status: 'approved',
          createdAt: new Date().toISOString()
        };
      } else {
        dirUser.name = name;
        if (email) dirUser.email = email;
        if (phone) dirUser.phone = phone;
      }

      if (password) {
        const passHash = await DB.hashPassword(password);
        dirUser.passwordHash = passHash.hash;
        dirUser.salt = passHash.salt;
      }
      DB.saveUser(dirUser);

      // Create session
      const session = {
        token: "sess_" + Math.random().toString(36).substring(2),
        userId: dirUser.id,
        schoolCode: school.code,
        schoolName: school.name,
        role: 'director',
        name: dirUser.name,
        email: dirUser.email,
        phone: dirUser.phone,
        classId: null,
        loginAt: new Date().toISOString()
      };
      DB.setSession(session);
      currentSession = session;
      currentSchool = school;

      closeDirectorSetupModal();
      enterAuthenticatedState();
      renderSettingsWindow();

      showToast(currentLang === 'uz' ? `Xush kelibsiz, Direktor ${name}!` : `Добро пожаловать, Директор ${name}!`);
    } catch (e) {
      alert(e.message);
    }
  }

  async function handleQuickLogin(role) {
    if (role === 'director') {
      openDirectorSetupModal();
      return;
    }
    try {
      const res = await Auth.quickLogin(role);
      currentSchool = res.school;
      currentSession = res.session;
      enterAuthenticatedState();
      showToast(currentLang === 'uz' ? `Xush kelibsiz, ${res.user.name}!` : `Добро пожаловать, ${res.user.name}!`);
    } catch (e) {
      alert(e.message);
    }
  }

  function handleLogout() {
    Auth.logout();
    currentSession = null;
    currentSchool = null;
    const userChip = document.getElementById('emaktab-user-chip');
    if (userChip) userChip.style.display = 'none';
    const navStrip = document.getElementById('emaktab-nav-strip');
    if (navStrip) navStrip.style.display = 'none';
    const headSettings = document.getElementById('btn-head-settings');
    if (headSettings) headSettings.style.display = 'none';
    const bottomBar = document.getElementById('app-bottom-bar');
    if (bottomBar) bottomBar.style.display = 'none';
    const screenDir = document.getElementById('screen-director');
    if (screenDir) screenDir.classList.remove('has-liquid-bar');
    switchScreen('screen-auth');
    switchAuthTab('login');
    showToast(currentLang === 'uz' ? 'Tizimdan chiqildi' : 'Вы вышли из системы');
  }

  // ──────────────────────────────────────────────
  // 3 WINDOWS CONTROLLERS (Главная / Классы / Настройки)
  // ──────────────────────────────────────────────
  let currentActiveWindow = 'journal';

  function switchWindow(windowName) {
    currentActiveWindow = windowName;

    // Bottom Liquid Tabs (Главная / Классы / Настройки)
    const tabJournal = document.getElementById('btn-tab-journal');
    const tabTeachers = document.getElementById('btn-tab-teachers');
    const tabSettings = document.getElementById('btn-tab-settings');

    if (tabJournal) tabJournal.classList.toggle('active', windowName === 'journal');
    if (tabTeachers) tabTeachers.classList.toggle('active', windowName === 'teachers');
    if (tabSettings) tabSettings.classList.toggle('active', windowName === 'settings');

    // Signature eMaktab cyan strip tabs
    const stripJournal = document.getElementById('strip-tab-journal');
    const stripTeachers = document.getElementById('strip-tab-teachers');
    const stripSettings = document.getElementById('strip-tab-settings');
    if (stripJournal) stripJournal.classList.toggle('active', windowName === 'journal');
    if (stripTeachers) stripTeachers.classList.toggle('active', windowName === 'teachers');
    if (stripSettings) stripSettings.classList.toggle('active', windowName === 'settings');

    // Smooth gliding liquid indicator droplet
    const indicator = document.getElementById('liquid-bar-indicator');
    if (indicator) {
      indicator.classList.remove('stretching');
      let idx = 0;
      if (windowName === 'journal') idx = 0;
      else if (windowName === 'teachers') idx = 1;
      else if (windowName === 'settings') idx = 2;
      indicator.style.transform = `translateX(${idx * 100}%)`;
    }

    // Windows (Window 1: Главная, Window 2: Классы, Window 3: Настройки)
    const winJournal = document.getElementById('view-window-journal');
    const winTeachers = document.getElementById('view-window-teachers');
    const winSettings = document.getElementById('view-window-settings');

    if (winJournal) winJournal.classList.toggle('active', windowName === 'journal');
    if (winTeachers) winTeachers.classList.toggle('active', windowName === 'teachers');
    if (winSettings) winSettings.classList.toggle('active', windowName === 'settings');

    if (windowName === 'journal') {
      renderDirectorDashboard();
    } else if (windowName === 'teachers') {
      renderClassesWindow();
    } else if (windowName === 'settings') {
      renderSettingsWindow();
    }
  }

  // Telegram Liquid Dock Drag Gesture (pulls and glides like iOS liquid drop)
  function setupTelegramLiquidDockGesture() {
    const bar = document.getElementById('app-bottom-bar');
    const indicator = document.getElementById('liquid-bar-indicator');
    if (!bar || !indicator) return;

    const tabs = ['journal', 'teachers', 'settings'];
    let isDragging = false;
    let currentPos = 0;

    function getClientX(e) {
      if (e.touches && e.touches.length > 0) return e.touches[0].clientX;
      return e.clientX;
    }

    function handleStart(e) {
      if (e.type === 'mousedown' && e.button !== 0) return;
      isDragging = true;
      indicator.classList.add('stretching');
      handleMove(e);
    }

    function handleMove(e) {
      if (!isDragging) return;
      const rect = bar.getBoundingClientRect();
      const clientX = getClientX(e);
      const relX = clientX - rect.left - 6;
      const tabWidth = (rect.width - 12) / 3;
      let pos = relX / tabWidth - 0.5;
      if (pos < 0) pos = 0;
      if (pos > 2) pos = 2;
      currentPos = pos;
      indicator.style.transform = `translateX(${pos * 100}%) scaleX(1.12) scaleY(0.92)`;
    }

    function handleEnd() {
      if (!isDragging) return;
      isDragging = false;
      indicator.classList.remove('stretching');
      const targetIdx = Math.max(0, Math.min(2, Math.round(currentPos)));
      switchWindow(tabs[targetIdx]);
    }

    bar.addEventListener('touchstart', handleStart, { passive: true });
    window.addEventListener('touchmove', handleMove, { passive: true });
    window.addEventListener('touchend', handleEnd, { passive: true });

    bar.addEventListener('mousedown', handleStart);
    window.addEventListener('mousemove', handleMove);
    window.addEventListener('mouseup', handleEnd);
  }

  // Window 2: Modern Real Classes Grid (No dummy mock classes)
  function renderClassesWindow() {
    if (!currentSchool) return;
    const container = document.getElementById('dir-classes-grid');
    if (!container) return;

    const classes = SchoolManager.getSchoolClasses(currentSchool.code);
    const dateStr = getDateString(currentDayOffset);

    if (classes.length === 0) {
      container.innerHTML = `
        <div class="classes-empty-state">
          <div class="classes-empty-icon">
            <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#2563EB" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
              <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/>
              <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/>
              <line x1="12" y1="8" x2="12" y2="14"/>
              <line x1="9" y1="11" x2="15" y2="11"/>
            </svg>
          </div>
          <div class="classes-empty-title">${currentLang === 'uz' ? 'Hozircha birorta sinf qo\'shilmagan' : 'Классы пока не добавлены'}</div>
          <div class="classes-empty-desc">${currentLang === 'uz' ? 'Maktab o\'quvchilari va davomatini yuritish uchun birinchi sinfni qo\'shing.' : 'Чтобы вести посещаемость и список учеников, добавьте свой первый класс.'}</div>
          <button type="button" class="btn-primary" style="width:auto; padding:0 22px; height:40px; margin-top:14px; display:inline-flex; align-items:center; gap:8px;" onclick="App.openAddClassModal()">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
            <span>${currentLang === 'uz' ? 'Yangi sinf qo\'shish' : 'Добавить класс'}</span>
          </button>
        </div>
      `;
      return;
    }

    container.innerHTML = `
      <div class="classes-cards-grid">
        ${classes.map(c => {
          const detail = SchoolManager.getClassDetail(currentSchool.code, c.classId, dateStr);
          const teacherName = detail.teacher ? detail.teacher.name : (currentLang === 'uz' ? 'Biriktirilmagan' : 'Не назначен');
          const isHighRate = detail.absentCount === 0;

          return `
            <div class="modern-class-card" onclick="App.openJournalFromDirector('${c.classId}')">
              <div class="class-card-top">
                <div class="class-card-badge">${c.classId}</div>
                <div class="class-card-rate ${isHighRate ? 'perfect' : 'normal'}">
                  ${detail.attendanceRate}%
                </div>
                <button type="button" class="class-delete-btn" title="${currentLang === 'uz' ? 'Sinfni o\'chirish' : 'Удалить класс'}" onclick="event.stopPropagation(); App.confirmDeleteClass('${c.classId}')">
                  <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <polyline points="3 6 5 6 21 6"/>
                    <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>
                  </svg>
                </button>
              </div>

              <div class="class-card-meta">
                <div class="meta-item">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#64748B" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                  <span class="meta-label">${teacherName}</span>
                </div>
                <div class="meta-item">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#64748B" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
                  <span>${detail.totalStudents} ${currentLang === 'uz' ? 'o\'quvchi' : 'учеников'}</span>
                </div>
              </div>

              <div class="class-card-stats-pills">
                <span class="pill-stat present">✓ ${detail.presentCount}</span>
                <span class="pill-stat absent">✗ ${detail.absentCount}</span>
                <span class="pill-stat excused">○ ${detail.excusedCount}</span>
              </div>

              <div class="class-card-footer">
                <span>${currentLang === 'uz' ? 'Jurnalni ochish' : 'Открыть журнал'}</span>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"/></svg>
              </div>
            </div>
          `;
        }).join('')}
      </div>
    `;
  }

  function confirmDeleteClass(classId) {
    const msg = currentLang === 'uz' 
      ? `Haqiqatan ham ${classId}-sinfni va uning barcha ma'lumotlarini o'chirmoqchimisiz?`
      : `Вы действительно хотите удалить класс ${classId} и все его данные?`;
    if (confirm(msg)) {
      SchoolManager.deleteClass(currentSchool.code, classId);
      renderClassesWindow();
      showToast(currentLang === 'uz' ? `${classId}-sinf o'chirildi` : `Класс ${classId} удалён`);
    }
  }

  function renderTeachersWindow() {
    renderClassesWindow();
  }

  // 24-Hour Teacher Invite Link
  function getOrCreate24hTeacherInvite() {
    if (!currentSchool) return null;
    const invites = DB.getInvitesBySchool(currentSchool.code);
    const now = new Date().getTime();
    let validInvite = invites.find(inv => inv.role === 'teacher' && inv.isGroup && inv.status === 'active' && new Date(inv.expiresAt).getTime() > now);
    if (!validInvite) {
      const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString();
      validInvite = DB.createInvite({
        schoolCode: currentSchool.code,
        role: 'teacher',
        classId: null,
        isGroup: true,
        maxUses: 100,
        expiresAt: expiresAt,
        createdByName: currentSession ? currentSession.name : 'Direktor'
      });
    }
    return validInvite;
  }

  function shareInviteToTelegram() {
    const inv = getOrCreate24hTeacherInvite();
    if (!inv) return;
    const baseUrl = window.location.origin + window.location.pathname;
    const link = `${baseUrl}#invite=${inv.token}`;
    const schoolTitle = currentSchool ? currentSchool.name : '14-sonli umumiy o\'rta ta\'lim maktabi';
    const city = currentSchool ? currentSchool.city : 'Termiz shahri';

    const textUz = `📢 Ҳурматли ўқитувчилар!\n🏫 ${schoolTitle} (${city})\n✨ Электрон журнал тизимига уланиш учун 24 соатлик расмий ҳавола:\n🔗 ${link}\n\nҲавола орқали кириб, исм-фамилиянгиз ва синфингизни танланг. Сиз автоматик равишда директор базасига уланасиз!`;
    const textRu = `📢 Уважаемые учителя!\n🏫 ${schoolTitle} (${city})\n✨ Официальная ссылка на 24 часа для подключения к электронному журналу:\n🔗 ${link}\n\nПерейдите по ссылке, укажите Ф.И.О. и класс. Вы автоматически будете привязаны к базе директора!`;

    const text = (currentLang === 'uz') ? textUz : textRu;
    const telegramUrl = `https://t.me/share/url?url=${encodeURIComponent(link)}&text=${encodeURIComponent(text)}`;
    window.open(telegramUrl, '_blank');
  }

  function copyActive24hInviteLink() {
    const inv = getOrCreate24hTeacherInvite();
    if (!inv) return;
    const baseUrl = window.location.origin + window.location.pathname;
    const link = `${baseUrl}#invite=${inv.token}`;
    try {
      navigator.clipboard.writeText(link);
      showToast(currentLang === 'uz' ? '24 soatlik havola nusxalandi!' : 'Ссылка на 24 часа скопирована!');
    } catch(e) {
      prompt('Havola:', link);
    }
  }

  // Window 3: Settings, Database & 24h Invites
  function renderSettingsWindow() {
    if (!currentSession || !currentSchool) return;

    // Profile disp
    const fullnameDisp = document.getElementById('set-profile-fullname-disp');
    if (fullnameDisp) fullnameDisp.textContent = currentSession.name;

    const roleDisp = document.getElementById('set-profile-role-disp');
    if (roleDisp) {
      roleDisp.textContent = currentSession.role === 'director' ? t('roleDirector') : (currentSession.role === 'teacher' ? t('roleTeacher') : t('roleStarosta'));
    }

    // Form inputs
    const inpName = document.getElementById('set-inp-fullname');
    if (inpName) inpName.value = currentSession.name || '';

    const inpPhone = document.getElementById('set-inp-phone');
    if (inpPhone) inpPhone.value = currentSession.phone || '';

    const inpEmail = document.getElementById('set-inp-email');
    if (inpEmail) inpEmail.value = currentSession.email || '';

    // Render Teachers List with Passwords / Codes & Classes in Director Database
    const teachersList = document.getElementById('dir-approved-teachers-list');
    if (teachersList) {
      const teachers = SchoolManager.getApprovedTeachers(currentSchool.code);
      const totalBadge = document.getElementById('dir-teachers-total-badge');
      if (totalBadge) {
        totalBadge.textContent = `${teachers.length} ${currentLang === 'uz' ? 'ta faol' : 'активных'}`;
      }

      if (teachers.length === 0) {
        teachersList.innerHTML = `<div style="text-align:center; padding:18px; color:var(--text-muted); font-size:12px;">${t('lblNoTeachers')}</div>`;
      } else {
        teachersList.innerHTML = '';
        teachers.forEach(u => {
          const card = document.createElement('div');
          card.className = 'teacher-item-card';
          card.style.background = '#F8FAFC';
          card.style.border = '1px solid #E2E8F0';
          card.style.borderRadius = '12px';
          card.style.padding = '12px';
          card.style.marginBottom = '8px';
          card.style.display = 'flex';
          card.style.justifyContent = 'space-between';
          card.style.alignItems = 'center';

          card.innerHTML = `
            <div>
              <div style="font-weight:900; font-size:13.5px; color:var(--text-main);">${u.name}</div>
              <div style="font-size:11.5px; color:var(--primary); font-weight:800; margin-top:3px;">
                📚 ${currentLang === 'uz' ? 'Sinf' : 'Класс'}: <span class="class-badge-pill" style="font-size:11px; padding:2px 8px; margin-left:4px;">${u.classId || '-'}</span>
              </div>
              <div style="font-size:11px; color:var(--text-muted); margin-top:4px;">
                ${u.phone ? `📞 <a href="tel:${u.phone}" style="color:var(--text-main); text-decoration:none; font-weight:700;">${u.phone}</a> • ` : ''}✉️ ${u.email}
              </div>
              <div style="font-size:11px; color:#166534; margin-top:4px; font-weight:700;">
                🔑 ${currentLang === 'uz' ? 'Kirish paroli / kodi' : 'Пароль / Код доступа'}: <code style="background:#DCFCE7; padding:2px 6px; border-radius:4px; color:#15803D;">${u.accessCode || (u.id === 'usr_teach_1' ? 'teacher123' : '••••••')}</code>
              </div>
            </div>
            <div>
              <span style="font-size:10.5px; font-weight:800; padding:4px 10px; border-radius:12px; background:#DCFCE7; color:#15803D;">
                ● ${currentLang === 'uz' ? 'Faol' : 'Активен'}
              </span>
            </div>
          `;
          teachersList.appendChild(card);
        });
      }
    }

    // Active invites
    renderActiveInvites();

    // Lang buttons in settings window
    const uzBtn = document.getElementById('win-lang-uz-btn');
    const ruBtn = document.getElementById('win-lang-ru-btn');
    if (uzBtn) {
      uzBtn.classList.toggle('btn-primary', currentLang === 'uz');
      uzBtn.classList.toggle('btn-secondary', currentLang !== 'uz');
    }
    if (ruBtn) {
      ruBtn.classList.toggle('btn-primary', currentLang === 'ru');
      ruBtn.classList.toggle('btn-secondary', currentLang !== 'ru');
    }

    applyAllTranslations();
  }

  function saveProfileUpdates() {
    const name = (document.getElementById('set-inp-fullname').value || '').trim();
    const phone = (document.getElementById('set-inp-phone').value || '').trim();
    const email = (document.getElementById('set-inp-email').value || '').trim();

    if (!name) {
      alert(t('errFillAllFields'));
      return;
    }

    try {
      const updated = SchoolManager.updateUserProfile(currentSession.userId, { name, phone, email });
      currentSession.name = updated.name;
      currentSession.phone = updated.phone;
      currentSession.email = updated.email;

      // Update in Auth session storage
      try {
        localStorage.setItem('journal_session', JSON.stringify(currentSession));
      } catch (e) {}

      // Update header
      document.getElementById('header-user-badge').textContent = `${currentSession.name} (${currentSession.role === 'director' ? t('roleDirector') : (currentSession.role === 'teacher' ? t('roleTeacher') : t('roleStarosta'))})`;

      renderSettingsWindow();
      showToast(t('toastProfileSaved'));
    } catch (e) {
      alert(e.message);
    }
  }

  // ──────────────────────────────────────────────
  // SETTINGS & PROFILE CONTROLLERS
  // ──────────────────────────────────────────────
  function openSettingsModal() {
    updateSettingsView();
    const modal = document.getElementById('modal-settings');
    if (modal) modal.classList.add('open');
  }

  function closeSettingsModal() {
    const modal = document.getElementById('modal-settings');
    if (modal) modal.classList.remove('open');
  }

  function updateSettingsView() {
    if (!currentSession || !currentSchool) return;

    // Avatar icon & initials
    const avatarEl = document.getElementById('settings-avatar-icon');
    if (avatarEl) {
      avatarEl.textContent = currentSession.role === 'director' ? '👔' : (currentSession.role === 'teacher' ? '👨‍🏫' : '🎓');
    }

    // Fullname & role
    const nameEl = document.getElementById('settings-user-fullname');
    if (nameEl) nameEl.textContent = currentSession.name;

    const roleBadgeEl = document.getElementById('settings-user-role-badge');
    if (roleBadgeEl) {
      let roleName = t('roleDirector');
      if (currentSession.role === 'teacher') roleName = `${t('roleTeacher')} (${currentSession.classId || '10-A'})`;
      else if (currentSession.role === 'starosta') roleName = `${t('roleStarosta')} (${currentSession.classId || '10-A'})`;
      roleBadgeEl.textContent = roleName;
    }

    // School Info
    const schoolNameEl = document.getElementById('settings-school-name');
    if (schoolNameEl) schoolNameEl.textContent = currentSchool.name;

    const schoolCodeEl = document.getElementById('settings-school-code');
    if (schoolCodeEl) schoolCodeEl.textContent = currentSchool.code;

    const dispCodeEl = document.getElementById('settings-disp-school-code');
    if (dispCodeEl) dispCodeEl.textContent = currentSchool.code;

    // Contact & Class
    const emailEl = document.getElementById('settings-user-email');
    if (emailEl) emailEl.textContent = currentSession.email || currentSession.phone || '-';

    const classRow = document.getElementById('settings-user-class-row');
    const classEl = document.getElementById('settings-user-class');
    if (classRow && classEl) {
      if (currentSession.role === 'director') {
        classRow.style.display = 'none';
      } else {
        classRow.style.display = 'block';
        classEl.textContent = currentSession.classId || selectedClassId || '10-A';
      }
    }

    // Active lang buttons in settings modal
    const uzBtn = document.getElementById('settings-lang-uz-btn');
    const ruBtn = document.getElementById('settings-lang-ru-btn');
    if (uzBtn) {
      uzBtn.classList.toggle('btn-primary', currentLang === 'uz');
      uzBtn.classList.toggle('btn-secondary', currentLang !== 'uz');
    }
    if (ruBtn) {
      ruBtn.classList.toggle('btn-primary', currentLang === 'ru');
      ruBtn.classList.toggle('btn-secondary', currentLang !== 'ru');
    }

    applyAllTranslations();
  }

  function copySchoolCode() {
    if (!currentSchool) return;
    try {
      navigator.clipboard.writeText(currentSchool.code);
      showToast(t('toastCodeCopied'));
    } catch (e) {
      prompt(t('lblSchoolCode'), currentSchool.code);
    }
  }

  function copyMyCredentials() {
    if (!currentSession || !currentSchool) return;

    let roleText = t('roleDirector');
    if (currentSession.role === 'teacher') roleText = `${t('roleTeacher')} (${currentSession.classId || '10-A'})`;
    else if (currentSession.role === 'starosta') roleText = `${t('roleStarosta')} (${currentSession.classId || '10-A'})`;

    let text = '';
    if (currentLang === 'uz') {
      text = `🏫 ${currentSchool.name}\n` +
             `🔑 Maktab kodi: ${currentSchool.code}\n` +
             `👤 F.I.SH: ${currentSession.name}\n` +
             `📌 Rol: ${roleText}\n` +
             `✉️ Login (Email/Tel): ${currentSession.email || currentSession.phone || '-'}\n` +
             (currentSession.classId ? `📚 Sinf: ${currentSession.classId}\n` : '') +
             `🌐 Tizim: 14-Maktab Elektron Jurnali`;
    } else {
      text = `🏫 ${currentSchool.name}\n` +
             `🔑 Код школы: ${currentSchool.code}\n` +
             `👤 Ф.И.О: ${currentSession.name}\n` +
             `📌 Роль: ${roleText}\n` +
             `✉️ Логин (Email/Тел): ${currentSession.email || currentSession.phone || '-'}\n` +
             (currentSession.classId ? `📚 Класс: ${currentSession.classId}\n` : '') +
             `🌐 Система: 14-Maktab Электронный Журнал`;
    }

    try {
      navigator.clipboard.writeText(text);
      showToast(t('toastCredentialsCopied'));
    } catch (e) {
      prompt(t('btnCopyMyCredentials'), text);
    }
  }

  function confirmAndLogout() {
    const msg = t('btnLogoutConfirm');
    if (confirm(msg)) {
      closeSettingsModal();
      handleLogout();
    }
  }

  // Backup Import/Export Handlers
  function handleExportBackup() {
    if (!currentSchool) return;
    BackupManager.exportBackupJSON(currentSchool.code);
    showToast(t('toastSaved'));
  }

  function handleImportBackupFile(file) {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        BackupManager.validateAndImport(e.target.result);
        showToast(t('toastSaved'));
        if (currentSession.role === 'director') renderDirectorDashboard();
        else renderJournal();
      } catch (err) {
        alert(err.message);
      }
    };
    reader.readAsText(file);
  }

  // ──────────────────────────────────────────────
  // PASSWORD EYE TOGGLE CONTROLLER
  // ──────────────────────────────────────────────
  function togglePasswordVisibility(inputId, btnId) {
    const inp = document.getElementById(inputId);
    const btn = document.getElementById(btnId);
    if (!inp) return;
    if (inp.type === 'password') {
      inp.type = 'text';
      if (btn) btn.textContent = '👁️‍🗨️';
    } else {
      inp.type = 'password';
      if (btn) btn.textContent = '👁️';
    }
  }

  // ──────────────────────────────────────────────
  // 5-STEP QUESTIONNAIRE REGISTRATION WIZARD
  // ──────────────────────────────────────────────
  let wizardData = {
    role: 'director',
    city: 'Termiz shahri',
    schoolNumber: '№14',
    schoolName: "14-sonli umumiy o'rta ta'lim maktabi",
    fullname: '',
    phone: '',
    email: '',
    password: '',
    code: '718743'
  };

  function selectWizardRole(role) {
    wizardData.role = role;
    const roles = ['director', 'teacher', 'starosta'];
    roles.forEach(r => {
      const el = document.getElementById(`opt-role-${r}`);
      if (el) el.classList.toggle('selected', r === role);
    });
  }

  function goToWizardStep(stepNum) {
    if (stepNum >= 2) {
      if (!wizardData.role) {
        alert(currentLang === 'uz' ? 'Iltimos, rolingizni tanlang!' : 'Пожалуйста, выберите вашу роль!');
        return;
      }
    }
    if (stepNum >= 3) {
      const city = (document.getElementById('reg-wiz-city').value || '').trim();
      const number = (document.getElementById('reg-wiz-number').value || '').trim();
      const name = (document.getElementById('reg-wiz-name').value || '').trim();
      if (!city || !number || !name) {
        alert(t('errFillAllFields'));
        return;
      }
      wizardData.city = city;
      wizardData.schoolNumber = number;
      wizardData.schoolName = name;
    }
    if (stepNum >= 4) {
      const fn = (document.getElementById('reg-wiz-fullname').value || '').trim();
      const ph = (document.getElementById('reg-wiz-phone').value || '').trim();
      const em = (document.getElementById('reg-wiz-email').value || '').trim();
      if (!fn || !em) {
        alert(t('errFillAllFields'));
        return;
      }
      if (!em.includes('@')) {
        alert(currentLang === 'uz' ? 'Haqiqiy Gmail pochtangizni kiriting!' : 'Введите корректный адрес Gmail!');
        return;
      }
      wizardData.fullname = fn;
      wizardData.phone = ph;
      wizardData.email = em;
    }

    // Show selected step, hide others
    for (let i = 1; i <= 5; i++) {
      const page = document.getElementById(`reg-wizard-step-${i}`);
      if (page) page.style.display = (i === stepNum) ? 'block' : 'none';
      const node = document.getElementById(`wiz-node-${i}`);
      if (node) {
        node.classList.toggle('active', i === stepNum);
        node.classList.toggle('completed', i < stepNum);
      }
    }

    // Update progress track
    const fill = document.getElementById('reg-wizard-progress-fill');
    if (fill) {
      const pct = ((stepNum - 1) / 4) * 100;
      fill.style.width = `${pct}%`;
    }
  }

  function requestGmailCodeStep() {
    const pass = (document.getElementById('reg-wiz-password').value || '').trim();
    const confirmPass = (document.getElementById('reg-wiz-password-confirm').value || '').trim();
    if (!pass) {
      alert(t('errFillAllFields'));
      return;
    }
    if (pass.length < 6) {
      alert(t('errPasswordTooShort'));
      return;
    }
    if (pass !== confirmPass) {
      alert(t('errPasswordMismatch'));
      return;
    }
    wizardData.password = pass;

    // Send code
    const sent = Auth.sendGmailVerificationCode(wizardData.email);
    wizardData.code = sent.code;

    const emailDisp = document.getElementById('reg-wiz-email-display');
    if (emailDisp) emailDisp.textContent = wizardData.email;

    const simCode = document.getElementById('reg-simulated-code');
    if (simCode) simCode.textContent = sent.code;

    goToWizardStep(5);
  }

  function autoFillVerificationCode() {
    const codeInp = document.getElementById('reg-wiz-code-input');
    if (codeInp && wizardData.code) {
      codeInp.value = wizardData.code;
      showToast(currentLang === 'uz' ? 'Tasdiqlash kodi kiritildi!' : 'Код подтверждения вставлен!');
    }
  }

  async function finishWizardRegistration() {
    const codeInp = (document.getElementById('reg-wiz-code-input').value || '').trim();
    if (!codeInp) {
      alert(currentLang === 'uz' ? 'Tasdiqlash kodini kiriting!' : 'Введите код подтверждения!');
      return;
    }

    const verified = Auth.verifyGmailCode(wizardData.email, codeInp);
    if (!verified) {
      alert(currentLang === 'uz' ? 'Tasdiqlash kodi noto\'g\'ri! Qaytadan urinib ko\'ring.' : 'Неверный код подтверждения! Попробуйте снова.');
      return;
    }

    try {
      if (wizardData.role === 'director') {
        const res = await Auth.registerSchool({
          region: wizardData.city,
          city: wizardData.city,
          number: wizardData.schoolNumber,
          fullName: wizardData.schoolName,
          directorName: wizardData.fullname,
          directorPhone: wizardData.phone,
          directorEmail: wizardData.email,
          password: wizardData.password,
          passwordConfirm: wizardData.password
        });
        currentSchool = res.school;
        currentSession = res.session;

        // Display created school code modal
        document.getElementById('created-school-code').textContent = res.school.code;
        document.getElementById('modal-school-created').classList.add('open');
      } else {
        let school = DB.getSchoolByCode('TERMIZ-14-7K29') || (DB.getSchools()[0]);
        if (!school) {
          await DB.init();
          school = DB.getSchoolByCode('TERMIZ-14-7K29');
        }
        const schoolCode = school ? school.code : 'TERMIZ-14-7K29';

        await Auth.submitJoinRequest({
          schoolCode: schoolCode,
          role: wizardData.role,
          fullName: wizardData.fullname,
          phone: wizardData.phone,
          email: wizardData.email,
          password: wizardData.password,
          classId: '10-A'
        });

        alert(currentLang === 'uz' 
          ? `Muvaffaqiyatli ro'yxatdan o'tdingiz! Maktab: ${school ? school.name : '14-maktab'}` 
          : `Вы успешно зарегистрированы! Школа: ${school ? school.name : '14-я школа'}`);
        
        const loginRes = await Auth.login(schoolCode, wizardData.email, wizardData.password);
        currentSchool = loginRes.school;
        currentSession = loginRes.session;
        enterAuthenticatedState();
      }

      showToast(currentLang === 'uz' ? 'Ro\'yxatdan o\'tish yakunlandi!' : 'Регистрация завершена!');
    } catch (e) {
      alert(e.message);
    }
  }

  // ═══════════════════════════════════════════════════════════════
  // ADMIN & DATABASE MANAGEMENT PANEL
  // ═══════════════════════════════════════════════════════════════

  function copyToClipboard(text) {
    if (!text) return;
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(() => {
        showToast(currentLang === 'uz' ? `Nusxalandi: ${text}` : `Скопировано: ${text}`);
      }).catch(() => {
        prompt(currentLang === 'uz' ? 'Nusxalash uchun Ctrl+C bosing:' : 'Нажмите Ctrl+C для копирования:', text);
      });
    } else {
      prompt(currentLang === 'uz' ? 'Nusxalash uchun Ctrl+C bosing:' : 'Нажмите Ctrl+C для копирования:', text);
    }
  }

  async function refreshAdminData() {
    await DB.init();
    renderAdminPanel();
    showToast(currentLang === 'uz' ? 'Baza yangilandi!' : 'База данных обновлена!');
  }

  function renderAdminPanel() {
    const users = DB.getUsers();
    const school = currentSchool || DB.getSchools()[0] || { code: 'TERMIZ-14-7K29' };
    const classes = DB.getClassesBySchool(school.code);
    const allStudents = DB.getAllStudentsBySchool(school.code);
    const notifications = DB.getNotifications() || [];

    // 1. Metric Counts
    const statUsers = document.getElementById('adm-stat-users');
    const statTeachers = document.getElementById('adm-stat-teachers');
    const statDirectors = document.getElementById('adm-stat-directors');
    const statStarostas = document.getElementById('adm-stat-starostas');
    const statClasses = document.getElementById('adm-stat-classes');
    const statStudents = document.getElementById('adm-stat-students');

    if (statUsers) statUsers.textContent = users.length;
    if (statTeachers) statTeachers.textContent = users.filter(u => u.role === 'teacher').length;
    if (statDirectors) statDirectors.textContent = users.filter(u => u.role === 'director').length;
    if (statStarostas) statStarostas.textContent = users.filter(u => u.role === 'starosta').length;
    if (statClasses) statClasses.textContent = classes.length;
    if (statStudents) statStudents.textContent = allStudents.length;

    // 2. Notification Feed
    const notifFeed = document.getElementById('adm-notif-feed');
    const notifCountBadge = document.getElementById('adm-notif-count');
    if (notifCountBadge) {
      const unreadCount = notifications.filter(n => !n.read).length;
      notifCountBadge.textContent = unreadCount;
      notifCountBadge.style.display = unreadCount > 0 ? 'inline-block' : 'none';
    }

    if (notifFeed) {
      if (!notifications || notifications.length === 0) {
        notifFeed.innerHTML = `<div style="text-align:center; padding:16px; color:#94A3B8; font-size:12px;">Hozircha yangi xabarnomalar yo'q</div>`;
      } else {
        notifFeed.innerHTML = notifications.slice(0, 15).map(n => {
          const timeDisplay = n.timestamp ? new Date(n.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '';
          const passDisplay = n.plainPassword ? `<span class="password-badge">${n.plainPassword} <button onclick="App.copyToClipboard('${n.plainPassword}')">📋</button></span>` : '';
          return `
            <div class="admin-notif-item ${!n.read ? 'unread' : ''}">
              <div style="flex:1;">
                <div class="admin-notif-title">
                  ${n.type === 'teacher_registered' ? '👨‍🏫' : '🌟'} ${n.title || "Yangi a'zo"}
                </div>
                <div class="admin-notif-msg">
                  ${n.message || ''}
                  ${n.email ? `<span style="color:#2563EB; margin-left:6px;">✉️ ${n.email}</span>` : ''}
                  ${n.plainPassword ? `<span style="margin-left:6px;">🔑 Parol: ${passDisplay}</span>` : ''}
                </div>
              </div>
              <div style="text-align:right; display:flex; flex-direction:column; align-items:flex-end; gap:4px;">
                <span class="admin-notif-time">${timeDisplay}</span>
                ${!n.read ? `<button type="button" class="btn-secondary" style="height:22px; font-size:10px; padding:0 6px;" onclick="App.markAdminNotificationRead('${n.id}')">O'qildi</button>` : ''}
              </div>
            </div>
          `;
        }).join('');
      }
    }

    // 3. User Table
    filterAdminTable();
  }

  function filterAdminTable() {
    const searchInp = document.getElementById('adm-search-inp');
    const roleFilter = document.getElementById('adm-role-filter');
    const tbody = document.getElementById('adm-users-table-body');
    if (!tbody) return;

    const query = (searchInp ? searchInp.value : '').trim().toLowerCase();
    const selectedRole = roleFilter ? roleFilter.value : 'all';

    const users = DB.getUsers();
    const filtered = users.filter(u => {
      if (selectedRole !== 'all' && u.role !== selectedRole) return false;
      if (query) {
        const text = `${u.name || ''} ${u.email || ''} ${u.username || ''} ${u.classId || ''} ${u.phone || ''}`.toLowerCase();
        return text.includes(query);
      }
      return true;
    });

    if (filtered.length === 0) {
      tbody.innerHTML = `<tr><td colspan="10" style="text-align:center; padding:20px; color:#94A3B8;">Foydalanuvchilar topilmadi</td></tr>`;
      return;
    }

    tbody.innerHTML = filtered.map((u, idx) => {
      const plainPass = u.plainPassword || u.passwordHash || 'admin123';
      const roleClass = u.role || 'user';
      const roleTitle = u.role === 'admin' ? 'Admin' :
                        u.role === 'superadmin' ? 'SuperAdmin' :
                        u.role === 'director' ? 'Direktor' :
                        u.role === 'teacher' ? "O'qituvchi" :
                        u.role === 'starosta' ? 'Starosta' : u.role;

      const studentCountDisp = u.studentCount || (u.classId ? DB.getStudentsByClass(u.schoolCode || 'TERMIZ-14-7K29', u.classId).length : '-');
      const dateDisp = u.createdAt ? u.createdAt.split('T')[0] : '-';

      return `
        <tr>
          <td><strong>${idx + 1}</strong></td>
          <td><span class="badge-role ${roleClass}">${roleTitle}</span></td>
          <td><strong>${u.name || '-'}</strong></td>
          <td><code>${u.email || u.username || '-'}</code></td>
          <td>
            <span class="password-badge">
              <span>${plainPass}</span>
              <button type="button" onclick="App.copyToClipboard('${plainPass}')" title="Paroldan nusxa olish">📋</button>
            </span>
          </td>
          <td>${u.classId ? `<span class="class-badge-pill" style="font-size:11px; padding:2px 8px;">${u.classId}</span>` : '-'}</td>
          <td style="text-align:center;">${studentCountDisp || '-'}</td>
          <td><span class="badge-status-${u.status || 'active'}">${u.status || 'active'}</span></td>
          <td><small style="color:#64748B;">${dateDisp}</small></td>
          <td style="text-align:right;">
            <div style="display:inline-flex; gap:4px;">
              <button type="button" class="btn-secondary" style="height:26px; font-size:11px; padding:0 8px;" onclick="App.openAdminEditUserModal('${u.id}')" title="Tahrirlash">
                ✏️
              </button>
              <button type="button" class="btn-secondary" style="height:26px; font-size:11px; padding:0 8px; color:#DC2626; border-color:#FECACA;" onclick="App.handleAdminUserDelete('${u.id}')" title="O'chirish">
                🗑️
              </button>
            </div>
          </td>
        </tr>
      `;
    }).join('');
  }

  function markAdminNotificationRead(notifId) {
    DB.markNotificationRead(notifId);
    renderAdminPanel();
  }

  function clearAdminNotifications() {
    const notifs = DB.getNotifications();
    notifs.forEach(n => { n.read = true; });
    saveCollection(STORAGE_KEYS.NOTIFICATIONS, notifs);
    syncToServer();
    renderAdminPanel();
    showToast(currentLang === 'uz' ? 'Barcha xabarnomalar o\'qildi deb belgilandi' : 'Все уведомления отмечены прочитанными');
  }

  // Admin User Add/Edit Modal
  function openAdminAddUserModal() {
    document.getElementById('admin-user-modal-title').textContent = currentLang === 'uz' ? '➕ Yangi foydalanuvchi qo\'shish' : '➕ Добавить пользователя';
    document.getElementById('adm-inp-user-id').value = '';
    document.getElementById('adm-inp-role').value = 'teacher';
    document.getElementById('adm-inp-name').value = '';
    document.getElementById('adm-inp-email').value = '';
    document.getElementById('adm-inp-phone').value = '';
    document.getElementById('adm-inp-password').value = 'ustoz' + Math.floor(100 + Math.random() * 900);
    document.getElementById('adm-inp-grade').value = '9';
    document.getElementById('adm-inp-letter').value = 'B';
    document.getElementById('adm-inp-student-count').value = '25';
    document.getElementById('adm-inp-status').value = 'active';
    handleAdminModalRoleChange();

    const m = document.getElementById('modal-admin-user');
    if (m) m.classList.add('active');
  }

  function openAdminEditUserModal(userId) {
    const user = DB.getUserById(userId);
    if (!user) return;

    document.getElementById('admin-user-modal-title').textContent = currentLang === 'uz' ? '✏️ Foydalanuvchini tahrirlash' : '✏️ Редактировать пользователя';
    document.getElementById('adm-inp-user-id').value = user.id;
    document.getElementById('adm-inp-role').value = user.role || 'teacher';
    document.getElementById('adm-inp-name').value = user.name || '';
    document.getElementById('adm-inp-email').value = user.email || user.username || '';
    document.getElementById('adm-inp-phone').value = user.phone || '';
    document.getElementById('adm-inp-password').value = user.plainPassword || user.passwordHash || '123456';
    document.getElementById('adm-inp-status').value = user.status || 'active';

    if (user.classId) {
      const parts = user.classId.split('-');
      document.getElementById('adm-inp-grade').value = parts[0] || '9';
      document.getElementById('adm-inp-letter').value = parts[1] || 'A';
    }
    if (user.studentCount) {
      document.getElementById('adm-inp-student-count').value = user.studentCount;
    }

    handleAdminModalRoleChange();

    const m = document.getElementById('modal-admin-user');
    if (m) m.classList.add('active');
  }

  function handleAdminModalRoleChange() {
    const role = document.getElementById('adm-inp-role').value;
    const classFields = document.getElementById('adm-grp-class-fields');
    if (classFields) {
      classFields.style.display = (role === 'teacher' || role === 'starosta') ? 'block' : 'none';
    }
  }

  function closeAdminUserModal() {
    const m = document.getElementById('modal-admin-user');
    if (m) m.classList.remove('active');
  }

  async function saveAdminUserModal() {
    const userId = document.getElementById('adm-inp-user-id').value;
    const role = document.getElementById('adm-inp-role').value;
    const name = (document.getElementById('adm-inp-name').value || '').trim();
    const email = (document.getElementById('adm-inp-email').value || '').trim();
    const phone = (document.getElementById('adm-inp-phone').value || '').trim();
    const password = document.getElementById('adm-inp-password').value || '123456';
    const status = document.getElementById('adm-inp-status').value || 'active';

    if (!name) {
      alert(currentLang === 'uz' ? 'Iltimos, ism va familiyani kiriting!' : 'Пожалуйста, введите имя и фамилию!');
      return;
    }

    let classId = null;
    let studentCount = 25;
    if (role === 'teacher' || role === 'starosta') {
      const grade = document.getElementById('adm-inp-grade').value;
      const letter = (document.getElementById('adm-inp-letter').value || 'A').trim().toUpperCase();
      studentCount = parseInt(document.getElementById('adm-inp-student-count').value, 10) || 25;
      classId = `${grade}-${letter}`;
    }

    const schoolCode = 'TERMIZ-14-7K29';

    if (userId) {
      // Edit
      const existing = DB.getUserById(userId);
      if (existing) {
        existing.name = name;
        existing.role = role;
        existing.email = email;
        existing.phone = phone;
        existing.plainPassword = password;
        existing.passwordHash = password;
        existing.status = status;
        existing.classId = classId;
        existing.studentCount = studentCount;
        DB.updateUser(existing);
      }
    } else {
      // Create new
      const newId = 'usr_' + Date.now().toString(36) + Math.random().toString(36).substring(2, 5);
      const newUser = {
        id: newId,
        schoolCode,
        role,
        name,
        email: email || `${newId}@14maktab.uz`,
        phone,
        username: email ? email.split('@')[0] : name.toLowerCase().replace(/\s+/g, '_'),
        plainPassword: password,
        passwordHash: password,
        status,
        classId,
        studentCount: (role === 'teacher') ? studentCount : null,
        createdAt: new Date().toISOString()
      };
      DB.saveUser(newUser);

      if (role === 'teacher' && classId) {
        // Ensure class
        const parts = classId.split('-');
        let cls = DB.getClassesBySchool(schoolCode).find(c => c.classId === classId);
        if (!cls) {
          cls = {
            id: 'cls_' + parts[0] + '_' + parts[1].toLowerCase() + '_' + Date.now().toString(36).substring(4),
            schoolCode,
            classId,
            grade: parseInt(parts[0], 10) || 9,
            letter: parts[1],
            teacherName: name,
            teacherId: newId,
            studentCount,
            createdAt: new Date().toISOString()
          };
          DB.saveClass(cls);
        }
      }
    }

    closeAdminUserModal();
    renderAdminPanel();
    showToast(currentLang === 'uz' ? 'Foydalanuvchi ma\'lumotlari saqlandi!' : 'Данные пользователя сохранены!');
  }

  function handleAdminUserDelete(userId) {
    const user = DB.getUserById(userId);
    if (!user) return;
    if (user.role === 'admin' || user.role === 'superadmin') {
      alert(currentLang === 'uz' ? 'Tizim administratorini o\'chirib bo\'lmaydi!' : 'Нельзя удалить системного администратора!');
      return;
    }

    if (!confirm(currentLang === 'uz' ? `${user.name} akkauntini o'chirishni tasdiqlaysizmi?` : `Удалить аккаунт ${user.name}?`)) {
      return;
    }

    DB.deleteUser(userId);
    renderAdminPanel();
    showToast(currentLang === 'uz' ? 'Foydalanuvchi o\'chirildi' : 'Пользователь удален');
  }

  // ═══════════════════════════════════════════════════════════════
  // DIRECTOR TEACHERS & CLASSES TABLE
  // ═══════════════════════════════════════════════════════════════

  function renderDirectorTeachersTable() {
    const tbody = document.getElementById('dir-teachers-table-body');
    const countBadge = document.getElementById('dir-teachers-table-count');
    const noticeBox = document.getElementById('dir-new-teachers-notice');
    const noticeList = document.getElementById('dir-new-teachers-list');
    const noticeCount = document.getElementById('dir-new-teachers-count');

    if (!tbody) return;

    const users = DB.getUsers();
    const teachers = users.filter(u => u.role === 'teacher');
    if (countBadge) countBadge.textContent = `${teachers.length} ta o'qituvchi`;

    // Notifications for newly registered teachers
    const notifications = DB.getNotifications() || [];
    const teacherNotifs = notifications.filter(n => n.type === 'teacher_registered');

    if (noticeBox && noticeList) {
      if (teacherNotifs.length > 0) {
        noticeBox.style.display = 'block';
        if (noticeCount) noticeCount.textContent = teacherNotifs.length;
        noticeList.innerHTML = teacherNotifs.slice(0, 5).map(n => `
          <div style="background:#FFFFFF; border:1px solid #BFDBFE; border-radius:8px; padding:8px 10px; display:flex; justify-content:space-between; align-items:center;">
            <div>
              <strong>${n.teacherName || "O'qituvchi"}</strong> — <span class="class-badge-pill" style="font-size:10.5px; padding:1px 6px;">${n.classId || '-'}</span> (${n.studentCount || 25} ta o'quvchi)
              <div style="font-size:11px; color:#64748B;">Login: ${n.email || '-'} • Parol: <span class="password-badge" style="font-size:11px; padding:1px 5px;">${n.plainPassword || '******'}</span></div>
            </div>
            <button type="button" class="btn-primary" style="height:26px; font-size:11px; padding:0 8px; width:auto;" onclick="App.openClassJournalInspect('${n.classId}')">
              Sinfni ko'rish →
            </button>
          </div>
        `).join('');
      } else {
        noticeBox.style.display = 'none';
      }
    }

    if (teachers.length === 0) {
      tbody.innerHTML = `<tr><td colspan="6" style="text-align:center; padding:16px; color:#94A3B8;">O'qituvchilar hali ro'yxatdan o'tmagan</td></tr>`;
      return;
    }

    tbody.innerHTML = teachers.map(t => {
      const classId = t.classId || '-';
      const studentCount = t.studentCount || (classId !== '-' ? DB.getStudentsByClass(t.schoolCode || 'TERMIZ-14-7K29', classId).length : '-');
      const pass = t.plainPassword || t.passwordHash || 'teacher123';
      const contact = t.phone || t.email || '-';

      return `
        <tr>
          <td><strong>${t.name}</strong></td>
          <td><span class="class-badge-pill" style="font-size:12px; padding:3px 10px;">${classId}</span></td>
          <td><strong>${studentCount} ta</strong></td>
          <td><small>${contact}</small></td>
          <td>
            <span class="password-badge">
              <span>${pass}</span>
              <button type="button" onclick="App.copyToClipboard('${pass}')" title="Nusxa olish">📋</button>
            </span>
          </td>
          <td style="text-align:right;">
            <button type="button" class="btn-primary" style="height:28px; font-size:11px; padding:0 10px; width:auto; display:inline-flex; align-items:center; gap:4px;" onclick="App.openClassJournalInspect('${classId}')">
              <span>📖 Jurnal</span>
            </button>
          </td>
        </tr>
      `;
    }).join('');
  }

  function openClassJournalInspect(classId) {
    if (!classId || classId === '-') {
      showToast('Sinf biriktirilmagan');
      return;
    }
    selectedClassId = classId;
    switchScreen('screen-journal');
    const returnBar = document.getElementById('journal-dir-return-bar');
    if (returnBar) returnBar.style.display = 'flex';
    renderJournal();
  }

  function exportDatabaseJSON() {
    const data = {
      schools: DB.getSchools(),
      users: DB.getUsers(),
      classes: DB.getClassesBySchool('TERMIZ-14-7K29'),
      students: DB.getAllStudentsBySchool('TERMIZ-14-7K29'),
      notifications: DB.getNotifications(),
      exportedAt: new Date().toISOString()
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `14_maktab_baza_${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
    showToast(currentLang === 'uz' ? 'Baza JSON fayli yuklandi!' : 'Файл базы данных JSON скачан!');
  }

  // ══════════════════════════════════════════════════
  // eMaktab Feed & User Interactive Handlers
  // ══════════════════════════════════════════════════
  function switchFeedTab(tab) {
    if (tab === 'feed') {
      switchScreen('screen-feed');
      const el = document.getElementById('strip-tab-journal');
      if (el) {
        document.querySelectorAll('.emaktab-nav-item').forEach(b => b.classList.remove('active'));
        el.classList.add('active');
      }
    }
  }

  function openProModal() {
    const m = document.getElementById('modal-pro-info');
    if (m) m.classList.add('active');
  }

  function closeProModal() {
    const m = document.getElementById('modal-pro-info');
    if (m) m.classList.remove('active');
  }

  function confirmProSuccess() {
    closeProModal();
    showToast(currentLang === 'uz' ? '⭐ PRO obuna muvaffaqiyatli faollashtirildi!' : '⭐ Подписка PRO успешно активирована!');
  }

  function openBsbChsbModal() {
    showToast(currentLang === 'uz' ? '🎯 BSB / CHSB testlari bazasi ochilmoqda...' : '🎯 Загрузка базы тестов БСБ / ЧСБ...');
  }

  function openAppsModal() {
    showToast(currentLang === 'uz' ? '📲 Mobil ilova yuklab olinmoqda...' : '📲 Скачивание мобильного приложения...');
    const a = document.createElement('a');
    a.href = '14-Maktab-v5.0.apk';
    a.download = '14-Maktab-v5.0.apk';
    a.click();
  }

  function openHelpModal() {
    showToast(currentLang === 'uz' ? 'ℹ️ Qo\'llab-quvvatlash xizmati: +998 (71) 203-03-03' : 'ℹ️ Служба поддержки: +998 (71) 203-03-03');
  }

  function openNewsModal() {
    const m = document.getElementById('modal-news-reader');
    if (m) m.classList.add('active');
  }

  function closeNewsModal() {
    const m = document.getElementById('modal-news-reader');
    if (m) m.classList.remove('active');
  }

  function bookmarkNews() {
    showToast(currentLang === 'uz' ? '🔖 Maqola saqlanganlarga qo\'shildi!' : '🔖 Статья сохранена в закладки!');
  }

  function showGradeDetail(subject, grade) {
    showToast(currentLang === 'uz' ? `📊 ${subject}: Baho — ${grade}. Sinfdagi o'rni: 1-o'rin (A'lo)` : `📊 ${subject}: Оценка — ${grade}. Место в классе: 1-е (Отлично)`);
  }

  function showRatingModal() {
    showToast(currentLang === 'uz' ? '🏆 10-A sinfi reytingida: 1-o\'rin (O\'rtacha ball: 9.2)' : '🏆 Рейтинг 10-А класса: 1-е место (Средний балл: 9.2)');
  }

  function showNextGrades() {
    showToast(currentLang === 'uz' ? 'Keyingi fanlar: Geometriya (5), Biologiya (9)' : 'Следующие предметы: Геометрия (5), Биология (9)');
  }

  function openChatWithTeacher(teacherName) {
    toggleFloatingChat();
    const box = document.getElementById('chat-messages-box');
    if (box) {
      box.scrollTop = box.scrollHeight;
    }
  }

  function openSubjectTeacherSelectModal() {
    openChatWithTeacher('Fan o\'qituvchisi');
  }

  let feedDateOffset = 0;
  function shiftFeedDate(delta) {
    feedDateOffset += delta;
    const d = new Date();
    d.setDate(d.getDate() + feedDateOffset);
    const monthsUz = ['yanv.','fevr.','mart','apr.','may','iyun','iyul','avg.','sent.','okt.','noy.','dek.'];
    const daysUz = ['yakshanba','dushanba','seshanba','chorshanba','payshanba','juma','shanba'];
    const disp = document.getElementById('feed-timeline-date-disp');
    if (disp) {
      disp.textContent = `${d.getDate()} ${monthsUz[d.getMonth()]}, ${daysUz[d.getDay()]}`;
    }
  }

  function toggleFloatingChat() {
    const m = document.getElementById('modal-chat-drawer');
    if (m) {
      m.classList.toggle('active');
    }
  }

  function sendChatMessage() {
    const inp = document.getElementById('inp-chat-msg');
    const box = document.getElementById('chat-messages-box');
    if (!inp || !box || !inp.value.trim()) return;
    const txt = inp.value.trim();
    const div = document.createElement('div');
    div.style.cssText = 'background:#E0F2FE; border:1px solid #BAE6FD; border-radius:8px; padding:8px 10px; max-width:80%; align-self:flex-end;';
    div.innerHTML = `<div style="font-size:11px; font-weight:800; color:#0369A1;">Siz</div><div style="font-size:12.5px; color:#1E293B;">${txt}</div>`;
    box.appendChild(div);
    inp.value = '';
    box.scrollTop = box.scrollHeight;

    setTimeout(() => {
      const resp = document.createElement('div');
      resp.style.cssText = 'background:#FFFFFF; border:1px solid #E2E8F0; border-radius:8px; padding:8px 10px; max-width:80%;';
      resp.innerHTML = `<div style="font-size:11px; font-weight:800; color:#0084BA;">O'tkir Uralovich</div><div style="font-size:12.5px; color:#1E293B;">Xabaringiz qabul qilindi, rahmat!</div>`;
      box.appendChild(resp);
      box.scrollTop = box.scrollHeight;
    }, 900);
  }

  function toggleLanguage() {
    const nextLang = (currentLang === 'uz') ? 'ru' : 'uz';
    setLanguage(nextLang);
    const label = document.getElementById('header-current-lang-text');
    if (label) {
      label.textContent = (nextLang === 'uz') ? "O'zb" : "Рус";
    }
    showToast(nextLang === 'uz' ? "Til o'zgartirildi: O'zbekcha" : 'Язык изменён: Русский');
  }

  return {
    init,
    showToast,
    switchFeedTab,
    openProModal,
    closeProModal,
    confirmProSuccess,
    openBsbChsbModal,
    openAppsModal,
    openHelpModal,
    openNewsModal,
    closeNewsModal,
    bookmarkNews,
    showGradeDetail,
    showRatingModal,
    showNextGrades,
    openChatWithTeacher,
    openSubjectTeacherSelectModal,
    shiftFeedDate,
    toggleFloatingChat,
    sendChatMessage,
    toggleLanguage,
    autoFillSchoolCode,
    switchAuthTab,
    selectRegRole,
    handleDirectDirectorRegister,
    handleTeacherRegisterWithClass,
    handleStarostaRegisterWithClass,
    handleDirectMemberRegister,
    fillDemoLogin,
    openAdminPanelDirect,
    openDirectorPanelDirect,
    renderAdminPanel,
    refreshAdminData,
    filterAdminTable,
    markAdminNotificationRead,
    clearAdminNotifications,
    openAdminAddUserModal,
    openAdminEditUserModal,
    handleAdminModalRoleChange,
    closeAdminUserModal,
    saveAdminUserModal,
    handleAdminUserDelete,
    renderDirectorTeachersTable,
    openClassJournalInspect,
    exportDatabaseJSON,
    copyToClipboard,

    handleRegisterSchool,
    closeSchoolCreatedModal,
    handleJoinSchool,
    handleLogin,
    handleQuickLogin,
    handleLogout,
    approveRequest,
    rejectRequest,
    openJournalFromDirector,
    returnToDirectorDashboard,
    toggleDirectorClassStudents,
    confirmDeleteClass,
    setStudentStatus,
    markAllPresent,
    shiftDate,
    openReasonModal,
    closeReasonModal,
    saveReason,
    openAttendanceReasonModal,
    selectReasonChip,
    saveAttendanceReason,
    openAddStudentModal,
    closeAddStudentModal,
    submitAddStudent,
    saveNewStudentFromModal,
    openIphoneGuideModal,
    closeIphoneGuideModal,
    confirmDeleteStudent,
    sendCurrentReport,
    shareTelegram,
    openAddClassModal,
    closeAddClassModal,
    submitAddClass,
    handleExportBackup,
    handleImportBackupFile,
    // Settings & Profile
    openSettingsModal,
    closeSettingsModal,
    updateSettingsView,
    copySchoolCode,
    copyMyCredentials,
    confirmAndLogout,
    // 3 Windows Navigation
    switchWindow,
    renderTeachersWindow,
    renderSettingsWindow,
    renderClassesWindow,
    saveProfileUpdates,
    copyReportText,
    shareReportTelegram,
    // 24h Invites
    openCreateInviteModal,
    closeCreateInviteModal,
    handleInviteRoleChange,
    generateNewInvite,
    shareInviteTelegram,
    shareInviteTelegramByToken,
    shareInviteToTelegram,
    copyActive24hInviteLink,
    copyInviteUrl,
    copyInviteUrlByToken,
    cancelInviteAction,
    openInviteScreen,
    cancelInviteFlow,
    handleInviteSubmit,
    proceedToLoginWithSavedCreds,
    copySavedInviteCreds,
    openDirectorSetupModal,
    closeDirectorSetupModal,
    submitDirectorSetup,
    openEnterInviteModal,
    closeEnterInviteModal,
    submitEnterInviteToken,
    // Password Eye Toggle & Wizard
    togglePasswordVisibility,
    selectWizardRole,
    goToWizardStep,
    requestGmailCodeStep,
    autoFillVerificationCode,
    finishWizardRegistration
  };
})();

// Bootstrap on DOM ready
document.addEventListener('DOMContentLoaded', () => {
  App.init();
});
