import MaktabNazoratPortal from '@/components/MaktabNazoratPortal';

export const metadata = {
  title: "Maktab Nazorat — O'zbekiston Maktab Davomat Portali",
  description: "14-sonli umumiy o'rta ta'lim maktabi elektron davomat va boshqaruv tizimi",
};

export default function Page() {
  return <MaktabNazoratPortal />;
}
