'use client';

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  GraduationCap,
  CheckCircle2,
  XCircle,
  ClockAlert,
  School,
  Bell,
  ShieldCheck,
  FileSpreadsheet,
  Users,
  ChevronRight,
  ArrowRight,
  Plus,
  Minus,
  Sparkles,
  Calendar,
  Layers,
  Search,
  Check
} from 'lucide-react';

// ─── TYPES & DATA STRUCTURES ───
type Role = 'DIRECTOR' | 'TEACHER' | 'STAROSTA';
type Lang = 'uz' | 'ru';
type AttendanceStatus = 'PRESENT' | 'ABSENT' | 'LATE';
type AbsenceReason = 'Kasallik' | 'Sababli' | 'Sababsiz';

interface Student {
  id: string;
  fullName: string;
  avatar: string;
  status: AttendanceStatus;
  reason?: AbsenceReason;
  lateMinutes?: number;
}

interface ClassItem {
  id: string;
  name: string;
  grade: number;
  totalStudents: number;
  submitted: boolean;
  attendanceRate: number;
  leaderName: string;
  starostaName: string;
}

// ─── DICTIONARY FOR BILINGUAL READINESS ───
const i18n = {
  uz: {
    brandName: 'Maktab Nazorat',
    brandSub: "14-sonli umumiy o'rta ta'lim maktabi",
    welcome: 'Xush kelibsiz',
    todayDate: 'Shanba, 19-Sentabr, 2026',
    todayAttendance: 'Bugungi davomat',
    classes: 'Sinflar',
    directorTitle: 'Direktor Boshqaruv Paneli',
    directorSub: 'Maktab bo‘yicha umumiy davomat va sinflar monitoringi',
    totalStudents: "Jami o'quvchilar",
    presentCount: 'Qatnashdi (Hozir)',
    absentCount: 'Qatnashmadi',
    lateCount: 'Kechikdi',
    rate: 'Davomat ko‘rsatkichi',
    classesOverview: 'Sinflar davomat monitoringi',
    statusSubmitted: 'Topshirildi',
    statusPending: 'Kutilmoqda',
    openJournal: 'Jurnalni ochish',
    classLeader: 'Sinf rahbari',
    starosta: 'Starosta',
    submitToDirector: 'Direktorga yuborish',
    sending: 'Yuborilmoqda...',
    submittedSuccess: 'Muvaffaqiyatli topshirildi!',
    allPresent: 'Barcha hozir',
    reset: 'Qayta tiklash',
    studentCol: 'O‘quvchi',
    statusCol: 'Holat',
    detailsCol: 'Sabab / Kechikish',
    statusPresent: 'Bor',
    statusAbsent: "Yo'q",
    statusLate: 'Kechikdi',
    reasonIllness: 'Kasallik',
    reasonExcused: 'Sababli',
    reasonUnexcused: 'Sababsiz',
    minutesSuffix: 'daq',
    roleDirector: 'Direktor',
    roleTeacher: 'Sinf rahbari',
    roleStarosta: 'Starosta',
    quickRole: 'Rolni sinash:'
  },
  ru: {
    brandName: 'Контроль Школы',
    brandSub: 'Общеобразовательная школа №14',
    welcome: 'Добро пожаловать',
    todayDate: 'Суббота, 19 сентября 2026',
    todayAttendance: 'Сегодняшняя посещаемость',
    classes: 'Классы',
    directorTitle: 'Панель Директора',
    directorSub: 'Общий мониторинг посещаемости и статуса классов',
    totalStudents: 'Всего учеников',
    presentCount: 'Присутствуют',
    absentCount: 'Отсутствуют',
    lateCount: 'Опоздали',
    rate: 'Показатель явки',
    classesOverview: 'Мониторинг классов',
    statusSubmitted: 'Сдано',
    statusPending: 'Ожидается',
    openJournal: 'Открыть журнал',
    classLeader: 'Классный руководитель',
    starosta: 'Староста',
    submitToDirector: 'Отправить директору',
    sending: 'Отправка...',
    submittedSuccess: 'Успешно отправлено!',
    allPresent: 'Все присутствуют',
    reset: 'Сбросить',
    studentCol: 'Ученик',
    statusCol: 'Статус',
    detailsCol: 'Причина / Опоздание',
    statusPresent: 'Присутствует',
    statusAbsent: 'Отсутствует',
    statusLate: 'Опоздал',
    reasonIllness: 'Болезнь',
    reasonExcused: 'Уважительная',
    reasonUnexcused: 'Без уважительной',
    minutesSuffix: 'мин',
    roleDirector: 'Директор',
    roleTeacher: 'Классный руководитель',
    roleStarosta: 'Староста',
    quickRole: 'Переключить роль:'
  }
};

// ─── TRADITIONAL CENTRAL ASIAN GIRIH SVG WATERMARK ───
const GirihWatermark = ({ className = '' }: { className?: string }) => (
  <svg
    viewBox="0 0 100 100"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={`pointer-events-none absolute select-none ${className}`}
  >
    <path
      d="M50 0L65.45 20.61L90.45 9.55L79.39 34.55L100 50L79.39 65.45L90.45 90.45L65.45 79.39L50 100L34.55 79.39L9.55 90.45L20.61 65.45L0 50L20.61 34.55L9.55 9.55L34.55 20.61L50 0Z"
      stroke="currentColor"
      strokeWidth="1.2"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    <circle cx="50" cy="50" r="28" stroke="currentColor" strokeWidth="1" strokeDasharray="3 3" />
    <path
      d="M50 25L67.68 37.86L60.92 58.69H39.08L32.32 37.86L50 25Z"
      stroke="currentColor"
      strokeWidth="0.8"
    />
  </svg>
);

export default function MaktabNazoratPortal() {
  const [lang, setLang] = useState<Lang>('uz');
  const [role, setRole] = useState<Role>('DIRECTOR');
  const [activeClassModal, setActiveClassModal] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmittedSuccess, setIsSubmittedSuccess] = useState(false);
  const [notifCount, setNotifCount] = useState(3);

  const t = i18n[lang];

  // Sample classes
  const [classes, setClasses] = useState<ClassItem[]>([
    {
      id: '10-A',
      name: '10-A',
      grade: 10,
      totalStudents: 32,
      submitted: true,
      attendanceRate: 94,
      leaderName: 'Nigora Karimova',
      starostaName: 'Amal Rustamov'
    },
    {
      id: '10-B',
      name: '10-B',
      grade: 10,
      totalStudents: 30,
      submitted: false,
      attendanceRate: 86,
      leaderName: 'Dilshod Ergashev',
      starostaName: 'Jasur Aliyev'
    },
    {
      id: '11-A',
      name: '11-A',
      grade: 11,
      totalStudents: 28,
      submitted: true,
      attendanceRate: 96,
      leaderName: 'Madina Usmonova',
      starostaName: 'Shahzod Bekzodov'
    }
  ]);

  // Sample students for active modal class
  const [students, setStudents] = useState<Student[]>([
    { id: '1', fullName: 'Aliyev Jasur Anvar o‘g‘li', avatar: 'JA', status: 'PRESENT' },
    { id: '2', fullName: 'Rustamov Amal Alisherovich', avatar: 'AR', status: 'PRESENT' },
    { id: '3', fullName: 'Karimova Ziyoda Botir qizi', avatar: 'ZK', status: 'ABSENT', reason: 'Kasallik' },
    { id: '4', fullName: 'Nazarov Bekzod G‘ayrat o‘g‘li', avatar: 'BN', status: 'LATE', lateMinutes: 15 },
    { id: '5', fullName: 'Yusupova Madina Ilhom qizi', avatar: 'MY', status: 'PRESENT' },
    { id: '6', fullName: 'Tursunov Sardor Rustam o‘g‘li', avatar: 'ST', status: 'PRESENT' }
  ]);

  // Calculate live statistics
  const totalStudentsCount = classes.reduce((sum, c) => sum + c.totalStudents, 0);
  const totalPresent = 82;
  const totalAbsent = 4;
  const totalLate = 4;
  const overallRate = Math.round((totalPresent / (totalPresent + totalAbsent)) * 100);

  // Student status toggles
  const handleStatusChange = (studentId: string, newStatus: AttendanceStatus) => {
    setStudents((prev) =>
      prev.map((s) => {
        if (s.id === studentId) {
          return {
            ...s,
            status: newStatus,
            reason: newStatus === 'ABSENT' ? (s.reason || 'Kasallik') : undefined,
            lateMinutes: newStatus === 'LATE' ? (s.lateMinutes || 10) : undefined
          };
        }
        return s;
      })
    );
  };

  const handleReasonChange = (studentId: string, reason: AbsenceReason) => {
    setStudents((prev) =>
      prev.map((s) => (s.id === studentId ? { ...s, reason } : s))
    );
  };

  const handleLateMinutesChange = (studentId: string, delta: number) => {
    setStudents((prev) =>
      prev.map((s) => {
        if (s.id === studentId) {
          const current = s.lateMinutes || 10;
          const next = Math.max(5, Math.min(120, current + delta));
          return { ...s, lateMinutes: next };
        }
        return s;
      })
    );
  };

  const markAllPresent = () => {
    setStudents((prev) =>
      prev.map((s) => ({ ...s, status: 'PRESENT', reason: undefined, lateMinutes: undefined }))
    );
  };

  const handleAttendanceSubmit = () => {
    setIsSubmitting(true);
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSubmittedSuccess(true);
      // Mark active class as submitted in state
      if (activeClassModal) {
        setClasses((prev) =>
          prev.map((c) => (c.id === activeClassModal ? { ...c, submitted: true } : c))
        );
      }
      setNotifCount((prev) => prev + 1);
      setTimeout(() => {
        setIsSubmittedSuccess(false);
        setActiveClassModal(null);
      }, 1400);
    }, 900);
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 selection:bg-emerald-800 selection:text-white font-sans antialiased relative">
      
      {/* ══════════════════════════════════════════════════
           1. TOP HEADER & BILINGUAL APP BAR
           ══════════════════════════════════════════════════ */}
      <header className="sticky top-0 z-40 w-full border-b border-slate-200/80 bg-white/90 backdrop-blur-md shadow-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-18 flex items-center justify-between gap-4">
          
          {/* Brand Identity with Emblem */}
          <div className="flex items-center gap-3.5">
            <div className="relative flex items-center justify-center w-11 h-11 rounded-2xl bg-gradient-to-br from-[#0F5132] to-[#00A896] text-white shadow-md shadow-emerald-950/15 border border-emerald-700/40">
              <School className="w-5 h-5 text-emerald-100" />
              <div className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-amber-400 rounded-full border-2 border-white flex items-center justify-center">
                <Sparkles className="w-2 h-2 text-emerald-950" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-lg font-black tracking-tight text-emerald-950 font-display">
                  {t.brandName}
                </span>
                <span className="hidden sm:inline-flex text-[10px] uppercase font-bold tracking-widest px-2 py-0.5 rounded-full bg-emerald-50 text-[#0F5132] border border-emerald-200">
                  ONLINE
                </span>
              </div>
              <p className="text-xs font-medium text-slate-500 line-clamp-1">{t.brandSub}</p>
            </div>
          </div>

          {/* Center: Date & Bilingual switch */}
          <div className="hidden md:flex items-center gap-4">
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-100/80 border border-slate-200 text-xs font-semibold text-slate-600">
              <Calendar className="w-3.5 h-3.5 text-emerald-800" />
              <span>{t.todayDate}</span>
            </div>

            {/* Language Switcher */}
            <div className="flex p-0.5 rounded-xl bg-slate-100 border border-slate-200 text-xs font-bold">
              <button
                onClick={() => setLang('uz')}
                className={`px-2.5 py-1 rounded-lg transition-all ${
                  lang === 'uz'
                    ? 'bg-white text-emerald-950 shadow-xs'
                    : 'text-slate-500 hover:text-slate-800'
                }`}
              >
                O‘zb
              </button>
              <button
                onClick={() => setLang('ru')}
                className={`px-2.5 py-1 rounded-lg transition-all ${
                  lang === 'ru'
                    ? 'bg-white text-emerald-950 shadow-xs'
                    : 'text-slate-500 hover:text-slate-800'
                }`}
              >
                Рус
              </button>
            </div>
          </div>

          {/* Right Actions: Notifications & User Profile */}
          <div className="flex items-center gap-3">
            
            {/* Notification Bell with animated pulse badge */}
            <button
              className="relative p-2 rounded-xl text-slate-600 hover:text-emerald-900 hover:bg-slate-100 transition-colors border border-transparent hover:border-slate-200"
              title="Bildirishnomalar"
            >
              <Bell className="w-5 h-5" />
              {notifCount > 0 && (
                <span className="absolute top-1 right-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-rose-600 px-1 text-[10px] font-black text-white shadow-xs">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-60"></span>
                  {notifCount}
                </span>
              )}
            </button>

            {/* User Profile Pill */}
            <div className="flex items-center gap-2.5 pl-2 pr-3.5 py-1.5 rounded-full bg-white border border-slate-200/90 shadow-xs">
              <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-[#0F5132] to-[#00A896] text-white flex items-center justify-center font-bold text-xs shadow-xs">
                {role === 'DIRECTOR' ? 'BO' : role === 'TEACHER' ? 'NR' : 'AR'}
              </div>
              <div className="flex flex-col text-left">
                <span className="text-xs font-bold text-slate-800 line-clamp-1">
                  {role === 'DIRECTOR' ? 'Bobur Olimov' : role === 'TEACHER' ? 'Nigora Rahimova' : 'Amal Rustamov'}
                </span>
                <span className="text-[10px] font-semibold text-emerald-800">
                  {role === 'DIRECTOR' ? t.roleDirector : role === 'TEACHER' ? t.roleTeacher : t.roleStarosta}
                </span>
              </div>
            </div>

          </div>

        </div>

        {/* Dynamic Quick Role Switcher Banner */}
        <div className="bg-emerald-950 text-white px-4 py-1.5 text-xs flex items-center justify-between border-t border-emerald-900/60">
          <div className="max-w-7xl mx-auto w-full flex items-center justify-between">
            <span className="font-semibold text-emerald-300 flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
              <span>{t.quickRole}</span>
            </span>
            <div className="flex items-center gap-1">
              {(['DIRECTOR', 'TEACHER', 'STAROSTA'] as Role[]).map((r) => (
                <button
                  key={r}
                  onClick={() => setRole(r)}
                  className={`px-3 py-0.5 rounded-md text-[11px] font-bold tracking-wide transition-all ${
                    role === r
                      ? 'bg-amber-400 text-emerald-950 shadow-xs'
                      : 'text-emerald-200/80 hover:text-white hover:bg-emerald-900/60'
                  }`}
                >
                  {r === 'DIRECTOR' ? t.roleDirector : r === 'TEACHER' ? t.roleTeacher : t.roleStarosta}
                </button>
              ))}
            </div>
          </div>
        </div>
      </header>

      {/* ══════════════════════════════════════════════════
           2. MAIN DASHBOARD CONTENT
           ══════════════════════════════════════════════════ */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">

        {/* Hero Welcome & Executive Banner */}
        <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-[#0F5132] via-[#0E492D] to-[#00A896] p-7 md:p-9 text-white shadow-xl shadow-emerald-950/15 border border-emerald-700/50">
          <GirihWatermark className="right-[-20px] top-[-30px] w-80 h-80 text-white opacity-5" />
          <GirihWatermark className="left-[-40px] bottom-[-40px] w-64 h-64 text-amber-300 opacity-5" />

          <div className="relative z-10 max-w-2xl space-y-2.5">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 backdrop-blur-md border border-white/20 text-xs font-semibold text-amber-300">
              <Sparkles className="w-3.5 h-3.5" />
              <span>2026/2027 o‘quv yili • Milliy Ta’lim Standarti</span>
            </div>
            <h1 className="text-2xl md:text-3xl font-black tracking-tight font-display text-white">
              {role === 'DIRECTOR'
                ? t.directorTitle
                : role === 'TEACHER'
                ? '10-A Sinf Rahbari Jurnali'
                : '10-A Sinf Starostasi Davomati'}
            </h1>
            <p className="text-emerald-100 text-sm md:text-base leading-relaxed">
              {role === 'DIRECTOR'
                ? t.directorSub
                : "Har kungi darslar boshlanishidan oldin o'quvchilar davomatini to'liq belgilab, direktorga yuboring."}
            </p>
          </div>
        </div>

        {/* 4 Stat Cards with Entry Stagger Animation */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-5">
          
          {/* Card 1: Total Students */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.35, delay: 0.05 }}
            className="group relative overflow-hidden rounded-2xl bg-white p-5 border border-slate-200/80 shadow-xs hover:shadow-md hover:-translate-y-1 transition-all"
          >
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
                {t.totalStudents}
              </span>
              <div className="p-2.5 rounded-xl bg-emerald-50 text-[#0F5132] group-hover:scale-110 transition-transform">
                <Users className="w-5 h-5" />
              </div>
            </div>
            <div className="text-3xl font-black text-slate-900 tracking-tight">{totalStudentsCount}</div>
            <p className="text-xs font-medium text-slate-500 mt-1.5 flex items-center gap-1">
              <span>🏫 3 faol sinf kesimida</span>
            </p>
          </motion.div>

          {/* Card 2: Present (Green Badge) */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.35, delay: 0.1 }}
            className="group relative overflow-hidden rounded-2xl bg-white p-5 border border-slate-200/80 shadow-xs hover:shadow-md hover:-translate-y-1 transition-all"
          >
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
                {t.presentCount}
              </span>
              <div className="p-2.5 rounded-xl bg-emerald-50 text-emerald-600 group-hover:scale-110 transition-transform">
                <CheckCircle2 className="w-5 h-5" />
              </div>
            </div>
            <div className="text-3xl font-black text-emerald-700 tracking-tight">{totalPresent}</div>
            <p className="text-xs font-semibold text-emerald-600 mt-1.5 flex items-center gap-1">
              <span>✓ 95.3% davomat ko‘rsatkichi</span>
            </p>
          </motion.div>

          {/* Card 3: Absent (Red Badge) */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.35, delay: 0.15 }}
            className="group relative overflow-hidden rounded-2xl bg-white p-5 border border-slate-200/80 shadow-xs hover:shadow-md hover:-translate-y-1 transition-all"
          >
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
                {t.absentCount}
              </span>
              <div className="p-2.5 rounded-xl bg-rose-50 text-rose-600 group-hover:scale-110 transition-transform">
                <XCircle className="w-5 h-5" />
              </div>
            </div>
            <div className="text-3xl font-black text-rose-600 tracking-tight">{totalAbsent}</div>
            <p className="text-xs font-medium text-slate-500 mt-1.5 flex items-center gap-1">
              <span>3 kasallik, 1 sababli</span>
            </p>
          </motion.div>

          {/* Card 4: Late (Amber Badge) */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.35, delay: 0.2 }}
            className="group relative overflow-hidden rounded-2xl bg-white p-5 border border-slate-200/80 shadow-xs hover:shadow-md hover:-translate-y-1 transition-all"
          >
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
                {t.lateCount}
              </span>
              <div className="p-2.5 rounded-xl bg-amber-50 text-amber-600 group-hover:scale-110 transition-transform">
                <ClockAlert className="w-5 h-5" />
              </div>
            </div>
            <div className="text-3xl font-black text-amber-600 tracking-tight">{totalLate}</div>
            <p className="text-xs font-medium text-slate-500 mt-1.5 flex items-center gap-1">
              <span>O‘rtacha 12 daqiqa</span>
            </p>
          </motion.div>

        </div>

        {/* Quick Class Grid & Director Overview */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-lg font-black tracking-tight text-slate-900 font-display">
                {t.classesOverview}
              </h2>
              <p className="text-xs text-slate-500">Bugungi hisobotlar topshirilish holati</p>
            </div>
            {role !== 'DIRECTOR' && (
              <button
                onClick={() => setActiveClassModal('10-A')}
                className="px-4 py-2 rounded-xl bg-[#0F5132] text-white text-xs font-bold hover:bg-[#0E492D] transition-all shadow-xs flex items-center gap-2"
              >
                <FileSpreadsheet className="w-4 h-4 text-amber-300" />
                <span>Mening sinfim davomati (10-A)</span>
              </button>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {classes.map((cls, idx) => (
              <motion.div
                key={cls.id}
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: idx * 0.08 }}
                onClick={() => setActiveClassModal(cls.id)}
                className="group relative cursor-pointer overflow-hidden rounded-2xl bg-white p-6 border border-slate-200/80 shadow-xs hover:shadow-lg hover:-translate-y-1 transition-all"
              >
                {/* Status Pill Badge */}
                <div className="flex items-center justify-between mb-4">
                  <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-[#0F5132] font-black text-base flex items-center justify-center border border-emerald-200/60 font-display">
                    {cls.name}
                  </div>
                  <span
                    className={`inline-flex items-center gap-1.5 text-xs font-bold px-3 py-1 rounded-full border ${
                      cls.submitted
                        ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                        : 'bg-amber-50 text-amber-700 border-amber-200'
                    }`}
                  >
                    {cls.submitted ? (
                      <>
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                        <span>{t.statusSubmitted}</span>
                      </>
                    ) : (
                      <>
                        <ClockAlert className="w-3.5 h-3.5 text-amber-600" />
                        <span>{t.statusPending}</span>
                      </>
                    )}
                  </span>
                </div>

                {/* Progress bar */}
                <div className="space-y-1.5 mb-5">
                  <div className="flex justify-between text-xs font-bold">
                    <span className="text-slate-600">{t.rate}</span>
                    <span className="text-[#0F5132]">{cls.attendanceRate}%</span>
                  </div>
                  <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-[#0F5132] to-[#00A896] rounded-full transition-all duration-500"
                      style={{ width: `${cls.attendanceRate}%` }}
                    ></div>
                  </div>
                </div>

                {/* Details Footer */}
                <div className="pt-4 border-t border-slate-100 space-y-1 text-xs">
                  <div className="flex justify-between text-slate-500">
                    <span>{t.classLeader}:</span>
                    <span className="font-semibold text-slate-800">{cls.leaderName}</span>
                  </div>
                  <div className="flex justify-between text-slate-500">
                    <span>{t.starosta}:</span>
                    <span className="font-semibold text-slate-800">{cls.starostaName}</span>
                  </div>
                </div>

                <div className="mt-4 flex items-center justify-end text-xs font-bold text-[#0F5132] group-hover:text-emerald-950 transition-colors">
                  <span>{t.openJournal}</span>
                  <ChevronRight className="w-4 h-4 ml-0.5 group-hover:translate-x-1 transition-transform" />
                </div>
              </motion.div>
            ))}
          </div>
        </div>

      </main>

      {/* ══════════════════════════════════════════════════
           3. STAROSTA & TEACHER QUICK-ACTION MODAL
           ══════════════════════════════════════════════════ */}
      <AnimatePresence>
        {activeClassModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/50 backdrop-blur-xs">
            
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setActiveClassModal(null)}
              className="absolute inset-0"
            />

            {/* Modal Dialog */}
            <motion.div
              initial={{ scale: 0.94, opacity: 0, y: 15 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.94, opacity: 0, y: 15 }}
              transition={{ type: 'spring', damping: 24, stiffness: 300 }}
              className="relative z-10 w-full max-w-3xl max-h-[90vh] flex flex-col bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden"
            >
              
              {/* Modal Header */}
              <div className="px-6 py-5 border-b border-slate-100 flex items-center justify-between bg-gradient-to-r from-slate-50 to-white">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-emerald-50 text-[#0F5132] font-black text-sm flex items-center justify-center border border-emerald-200">
                    {activeClassModal}
                  </div>
                  <div>
                    <h3 className="text-base font-black text-slate-900 font-display">
                      {activeClassModal} Sinf Davomati Jurnali
                    </h3>
                    <p className="text-xs text-slate-500">19-Sentabr, 2026 • 6 ta o‘quvchi ro‘yxati</p>
                  </div>
                </div>

                <button
                  onClick={() => setActiveClassModal(null)}
                  className="p-2 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
                >
                  <XCircle className="w-5 h-5" />
                </button>
              </div>

              {/* Quick Actions Bar */}
              <div className="px-6 py-3 bg-slate-50/80 border-b border-slate-100 flex items-center justify-between flex-wrap gap-2 text-xs">
                <span className="font-semibold text-slate-600">
                  O‘quvchilar holatini tanlang yoki barchani belgilang:
                </span>
                <div className="flex items-center gap-2">
                  <button
                    onClick={markAllPresent}
                    className="px-3 py-1.5 rounded-lg bg-emerald-100 text-[#0F5132] font-bold hover:bg-emerald-200 transition-colors"
                  >
                    ✓ {t.allPresent}
                  </button>
                </div>
              </div>

              {/* Attendance Table (Scrollable, mobile-optimized) */}
              <div className="flex-1 overflow-y-auto px-4 sm:px-6 py-3 divide-y divide-slate-100">
                {students.map((student, index) => (
                  <div
                    key={student.id}
                    className="py-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-slate-50/60 rounded-xl px-2 transition-colors"
                  >
                    {/* Left: Avatar & Name */}
                    <div className="flex items-center gap-3 min-w-0 flex-1">
                      <div className="w-9 h-9 shrink-0 rounded-full bg-slate-100 border border-slate-200 text-emerald-950 font-bold text-xs flex items-center justify-center">
                        {student.avatar}
                      </div>
                      <div className="min-w-0">
                        <div className="text-xs sm:text-sm font-bold text-slate-900 truncate">
                          {student.fullName}
                        </div>
                        <div className="text-[11px] text-slate-400">№ {index + 1}</div>
                      </div>
                    </div>

                    {/* Middle: Interactive Status Toggles [Bor] [Yo'q] [Kechikdi] */}
                    <div className="flex items-center gap-1.5 shrink-0">
                      <button
                        type="button"
                        onClick={() => handleStatusChange(student.id, 'PRESENT')}
                        className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1 border ${
                          student.status === 'PRESENT'
                            ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                            : 'bg-white text-slate-600 border-slate-200 hover:border-slate-300'
                        }`}
                      >
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>{t.statusPresent}</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => handleStatusChange(student.id, 'ABSENT')}
                        className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1 border ${
                          student.status === 'ABSENT'
                            ? 'bg-rose-600 text-white border-rose-600 shadow-xs'
                            : 'bg-white text-slate-600 border-slate-200 hover:border-slate-300'
                        }`}
                      >
                        <XCircle className="w-3.5 h-3.5" />
                        <span>{t.statusAbsent}</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => handleStatusChange(student.id, 'LATE')}
                        className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1 border ${
                          student.status === 'LATE'
                            ? 'bg-amber-500 text-white border-amber-500 shadow-xs'
                            : 'bg-white text-slate-600 border-slate-200 hover:border-slate-300'
                        }`}
                      >
                        <ClockAlert className="w-3.5 h-3.5" />
                        <span>{t.statusLate}</span>
                      </button>
                    </div>

                    {/* Right: Conditional Micro-Inputs (Dropdown if Absent, Stepper if Late) */}
                    <div className="sm:w-44 flex items-center justify-end shrink-0">
                      {student.status === 'ABSENT' && (
                        <select
                          value={student.reason || 'Kasallik'}
                          onChange={(e) => handleReasonChange(student.id, e.target.value as AbsenceReason)}
                          className="w-full text-xs font-bold py-1.5 px-2.5 rounded-xl border border-rose-200 bg-rose-50 text-rose-800 outline-none focus:ring-2 focus:ring-rose-500/20"
                        >
                          <option value="Kasallik">🤒 {t.reasonIllness}</option>
                          <option value="Sababli">📄 {t.reasonExcused}</option>
                          <option value="Sababsiz">⚠️ {t.reasonUnexcused}</option>
                        </select>
                      )}

                      {student.status === 'LATE' && (
                        <div className="flex items-center gap-1.5 bg-amber-50 border border-amber-200 px-2 py-1 rounded-xl text-amber-900">
                          <button
                            type="button"
                            onClick={() => handleLateMinutesChange(student.id, -5)}
                            className="p-1 hover:bg-amber-200 rounded-md transition-colors"
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="text-xs font-black min-w-8 text-center">
                            {student.lateMinutes || 10} {t.minutesSuffix}
                          </span>
                          <button
                            type="button"
                            onClick={() => handleLateMinutesChange(student.id, 5)}
                            className="p-1 hover:bg-amber-200 rounded-md transition-colors"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>
                      )}

                      {student.status === 'PRESENT' && (
                        <span className="text-[11px] font-semibold text-slate-400">
                          To‘liq qatnashmoqda
                        </span>
                      )}
                    </div>
                  </div>
                ))}
              </div>

              {/* Modal Footer with Primary Action Button */}
              <div className="px-6 py-4 bg-slate-50 border-t border-slate-100 flex items-center justify-between">
                <button
                  type="button"
                  onClick={() => setActiveClassModal(null)}
                  className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-200/70 transition-colors"
                >
                  Bekor qilish
                </button>

                <button
                  type="button"
                  disabled={isSubmitting || isSubmittedSuccess}
                  onClick={handleAttendanceSubmit}
                  className={`relative overflow-hidden px-6 py-2.5 rounded-2xl text-xs font-black text-white shadow-md transition-all flex items-center gap-2 ${
                    isSubmittedSuccess
                      ? 'bg-emerald-600 hover:bg-emerald-700'
                      : 'bg-gradient-to-r from-[#0F5132] to-[#00A896] hover:shadow-lg hover:brightness-105 active:scale-95'
                  }`}
                >
                  {isSubmitting ? (
                    <span>{t.sending}</span>
                  ) : isSubmittedSuccess ? (
                    <motion.span
                      initial={{ scale: 0.5, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      className="flex items-center gap-1.5 text-white"
                    >
                      <Check className="w-4 h-4 stroke-[3]" />
                      <span>{t.submittedSuccess}</span>
                    </motion.span>
                  ) : (
                    <>
                      <span>{t.submitToDirector}</span>
                      <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>
              </div>

            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
